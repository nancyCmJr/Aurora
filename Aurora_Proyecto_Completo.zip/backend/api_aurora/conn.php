<?php
// Utiliza variables de entorno si están disponibles. Valores locales XAMPP como respaldo.
// En producción establecer AURORA_DB_HOST, AURORA_DB_USER, AURORA_DB_PASSWORD, AURORA_DB_NAME.
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli(
        getenv('AURORA_DB_HOST') ?: 'localhost',
        getenv('AURORA_DB_USER') ?: 'root',
        getenv('AURORA_DB_PASSWORD') !== false ? getenv('AURORA_DB_PASSWORD') : '',
        getenv('AURORA_DB_NAME') ?: 'aurora'
    );
    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    error_log('Aurora DB connection: ' . $e->getMessage());
    header('Content-Type: application/json; charset=UTF-8');
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'No se pudo conectar a la base de datos'], JSON_UNESCAPED_UNICODE);
    exit;
}
