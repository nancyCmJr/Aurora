<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'grupos', 'listar');

// Listado histórico de grupos. Todos los filtros son opcionales.
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
function responder($codigo, $mensaje, $extra = []) {
    http_response_code($codigo);
    echo json_encode(array_merge(['success' => $codigo >= 200 && $codigo < 300, 'message' => $mensaje], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'GET') responder(405, 'Método no permitido');

$tipos = '';
$valores = [];
$condiciones = [];
if (isset($_GET['periodo'])) {
    if (!is_string($_GET['periodo']) || ($periodo = trim($_GET['periodo'])) === '' || mb_strlen($periodo, 'UTF-8') > 20) responder(400, 'Periodo inválido');
    $condiciones[] = 'g.periodo = ?'; $tipos .= 's'; $valores[] = $periodo;
}
if (isset($_GET['anio'])) {
    $anio = filter_var($_GET['anio'], FILTER_VALIDATE_INT);
    if ($anio === false || $anio < 1901 || $anio > 2155) responder(400, 'Año inválido');
    $condiciones[] = 'g.anio = ?'; $tipos .= 'i'; $valores[] = $anio;
}
if (isset($_GET['estado'])) {
    $estado = $_GET['estado'];
    if (!is_string($estado) || !in_array($estado, ['Planeado','Abierto','Cerrado','Cancelado'], true)) responder(400, 'Estado de grupo inválido');
    $condiciones[] = 'g.estado = ?'; $tipos .= 's'; $valores[] = $estado;
}
foreach (['id_docente', 'id_materia'] as $campo) {
    if (!isset($_GET[$campo])) continue;
    $id = filter_var($_GET[$campo], FILTER_VALIDATE_INT);
    if ($id === false || $id <= 0) responder(400, "$campo inválido");
    $condiciones[] = "g.$campo = ?"; $tipos .= 'i'; $valores[] = $id;
}
require_once __DIR__ . '/../conn.php';
try {
    $sql = "SELECT
        g.id_grupo, g.clave_grupo, g.capacidad, g.semestre, g.periodo, g.anio,
        g.id_materia, m.clave_materia, m.nombre AS nombre_materia, m.estado AS estado_materia,
        g.id_docente, d.codigo AS codigo_docente, d.nombre AS nombre_docente,
        d.seg_nombre AS segundo_nombre_docente, d.apellidos AS apellidos_docente,
        d.estado AS estado_docente, g.modalidad, g.estado,
        (SELECT COUNT(*) FROM kardex k WHERE k.id_grupo = g.id_grupo AND k.estado = 'Cursando') AS alumnos_cursando,
        (SELECT COUNT(*) FROM kardex k WHERE k.id_grupo = g.id_grupo AND k.estado <> 'Baja') AS alumnos_ocupando,
        (SELECT COUNT(*) FROM horarios h WHERE h.id_grupo = g.id_grupo) AS total_horarios,
        (SELECT COUNT(*) FROM horarios h WHERE h.id_grupo = g.id_grupo AND h.estado = 'Activo') AS horarios_activos,
        (SELECT MIN(s.capacidad) FROM horarios h JOIN salones s ON s.id_salon = h.id_salon
         WHERE h.id_grupo = g.id_grupo AND h.estado = 'Activo') AS capacidad_minima_salon,
        CASE WHEN m.estado = 'Activa' AND d.estado = 'Activo' THEN 1 ELSE 0 END AS referencias_activas
        FROM grupos g JOIN docentes d ON d.id_docente = g.id_docente
        JOIN materias m ON m.id_materia = g.id_materia";
    if ($condiciones) $sql .= ' WHERE ' . implode(' AND ', $condiciones);
    $sql .= ' ORDER BY g.anio DESC, g.periodo DESC, g.id_grupo DESC';
    $stmt = $conn->prepare($sql);
    if ($tipos !== '') $stmt->bind_param($tipos, ...$valores);
    $stmt->execute();
    $result = $stmt->get_result();
    $grupos = [];
    while ($fila = $result->fetch_assoc()) {
        foreach (['id_grupo','capacidad','semestre','anio','id_materia','id_docente','alumnos_cursando','alumnos_ocupando','total_horarios','horarios_activos'] as $campo) {
            $fila[$campo] = (int)$fila[$campo];
        }
        $fila['referencias_activas'] = (bool)$fila['referencias_activas'];
        $fila['lugares_disponibles'] = max(0, $fila['capacidad'] - $fila['alumnos_ocupando']);
        $fila['capacidad_minima_salon'] = $fila['capacidad_minima_salon'] === null ? null : (int)$fila['capacidad_minima_salon'];
        $fila['capacidad_compatible_salones'] = $fila['capacidad_minima_salon'] === null ? null : $fila['capacidad'] <= $fila['capacidad_minima_salon'];
        $fila['puede_abrirse'] = $fila['estado'] === 'Planeado' && $fila['referencias_activas'] && $fila['capacidad_compatible_salones'] !== false;
        $grupos[] = $fila;
    }
    $stmt->close();
    responder(200, 'Grupos consultados correctamente', ['total' => count($grupos), 'grupos' => $grupos]);
} catch (Throwable $e) {
    error_log('grupos/listar: ' . $e->getMessage());
    responder(500, 'No fue posible consultar los grupos');
} finally {
    $conn->close();
}
