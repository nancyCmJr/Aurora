<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'grupos', 'registrar');


header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

/* ==========================================
   1. VALIDAR MÉTODO
========================================== */

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ], JSON_UNESCAPED_UNICODE);
    exit();
}

require_once __DIR__ . "/../conn.php";

/* ==========================================
   2. FUNCIONES
========================================== */

function responder($codigo, $mensaje, $datos = []) {

    http_response_code($codigo);

    echo json_encode(
        array_merge([
            "success" => $codigo >= 200 && $codigo < 300,
            "message" => $mensaje
        ], $datos),
        JSON_UNESCAPED_UNICODE
    );

    exit();
}

function validarEnteroPositivo($valor) {

    if (is_int($valor)) {
        return $valor > 0 ? $valor : false;
    }

    if (
        is_string($valor) &&
        ctype_digit($valor) &&
        filter_var($valor, FILTER_VALIDATE_INT) !== false &&
        (int)$valor > 0
    ) {
        return (int)$valor;
    }

    return false;
}

/* ==========================================
   3. RECIBIR Y VALIDAR JSON
========================================== */

$data = json_decode(file_get_contents("php://input"));

if (!is_object($data)) {
    responder(400, "El contenido JSON no es válido");
}

/* ==========================================
   4. OBTENER DATOS
========================================== */

$clave = (
    isset($data->clave_grupo) &&
    is_string($data->clave_grupo)
)
    ? trim($data->clave_grupo)
    : "";

$capacidad = validarEnteroPositivo(
    $data->capacidad ?? null
);

$semestre = validarEnteroPositivo(
    $data->semestre ?? null
);

$id_materia = validarEnteroPositivo(
    $data->id_materia ?? null
);

$id_docente = validarEnteroPositivo(
    $data->id_docente ?? null
);

// Identificador del ciclo escolar (obligatorio en el esquema nuevo).
$periodo = (isset($data->periodo) && is_string($data->periodo))
    ? trim($data->periodo) : "";
$anio = validarEnteroPositivo($data->anio ?? null);

$modalidad = $data->modalidad ?? "Entre semana";
$estado = $data->estado ?? "Planeado";

/* ==========================================
   5. VALIDAR CAMPOS OBLIGATORIOS
========================================== */

if (
    $clave === "" ||
    $capacidad === false ||
    $semestre === false ||
    $id_materia === false ||
    $id_docente === false ||
    $periodo === "" ||
    mb_strlen($periodo, 'UTF-8') > 20 ||
    $anio === false ||
    $anio < 1901 ||
    $anio > 2155
) {
    responder(
        400,
        "Todos los campos obligatorios deben ser válidos"
    );
}

/* ==========================================
   6. VALIDAR LONGITUD DE CLAVE
========================================== */

if (mb_strlen($clave, "UTF-8") > 20) {
    responder(
        400,
        "La clave del grupo no debe superar los 20 caracteres"
    );
}

/* ==========================================
   7. VALIDAR SEMESTRE
========================================== */

if ($semestre < 1 || $semestre > 20) {
    responder(
        400,
        "El semestre debe estar entre 1 y 20"
    );
}

/* ==========================================
   8. VALIDAR MODALIDAD
========================================== */

$modalidades = [
    "Entre semana",
    "Sabado"
];

if (
    !is_string($modalidad) ||
    !in_array($modalidad, $modalidades, true)
) {
    responder(400, "La modalidad del grupo no es válida");
}

/* ==========================================
   9. VALIDAR ESTADO
========================================== */

$estados = [
    "Planeado",
    "Abierto",
    "Cerrado",
    "Cancelado"
];

if (
    !is_string($estado) ||
    !in_array($estado, $estados, true)
) {
    responder(400, "El estado del grupo no es válido");
}

/*
   Planeado y Abierto son estados operativos.
   Cerrado y Cancelado son estados históricos.

   Se conserva la regla del módulo:
   los estados operativos requieren relaciones activas.
*/

$requiereRelacionesActivas = in_array(
    $estado,
    ["Planeado", "Abierto"],
    true
);

/* ==========================================
   10. VARIABLES DE CONTROL
========================================== */

$stmt = null;
$transaccionIniciada = false;

try {

    /* ======================================
       11. INICIAR TRANSACCIÓN
    ====================================== */

    $conn->begin_transaction();
    $transaccionIniciada = true;

    /* ======================================
       12. BLOQUEAR DOCENTE
    ====================================== */

    $stmt = $conn->prepare("
        SELECT
            id_docente,
            estado
        FROM docentes
        WHERE id_docente = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_docente);
    $stmt->execute();

    $docente = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$docente) {
        throw new DomainException(
            "El docente seleccionado no existe",
            404
        );
    }

    if (
        $requiereRelacionesActivas &&
        $docente["estado"] !== "Activo"
    ) {
        throw new DomainException(
            "No se puede registrar un grupo planeado o abierto con un docente inactivo o dado de baja.",
            409
        );
    }

    /* ======================================
       13. BLOQUEAR MATERIA
    ====================================== */

    $stmt = $conn->prepare("
        SELECT
            id_materia,
            estado
        FROM materias
        WHERE id_materia = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_materia);
    $stmt->execute();

    $materia = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$materia) {
        throw new DomainException(
            "La materia seleccionada no existe",
            404
        );
    }

    if (
        $requiereRelacionesActivas &&
        $materia["estado"] !== "Activa"
    ) {
        throw new DomainException(
            "No se puede registrar un grupo planeado o abierto con una materia inactiva.",
            409
        );
    }

    /* ======================================
       14. VERIFICAR CLAVE DUPLICADA
    ====================================== */

    $stmt = $conn->prepare("
        SELECT id_grupo
        FROM grupos
        WHERE clave_grupo = ? AND periodo = ? AND anio = ?
        LIMIT 1
    ");

    $stmt->bind_param("ssi", $clave, $periodo, $anio);
    $stmt->execute();

    $duplicado = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if ($duplicado) {
        throw new DomainException(
            "La clave del grupo ya está registrada",
            409
        );
    }

    /* ======================================
       15. REGISTRAR GRUPO
    ====================================== */

    $stmt = $conn->prepare("
        INSERT INTO grupos (
            clave_grupo,
            capacidad,
            semestre,
            id_materia,
            id_docente,
            periodo,
            anio,
            modalidad,
            estado
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "siiiisiss",
        $clave,
        $capacidad,
        $semestre,
        $id_materia,
        $id_docente,
        $periodo,
        $anio,
        $modalidad,
        $estado
    );

    $stmt->execute();

    $id_nuevo = $conn->insert_id;

    $stmt->close();
    $stmt = null;

    /* ======================================
       16. CONFIRMAR TRANSACCIÓN
    ====================================== */

    $conn->commit();
    $transaccionIniciada = false;

    responder(
        201,
        "Grupo registrado correctamente",
        [
            "data" => [
                "id_grupo" => $id_nuevo,
                "clave_grupo" => $clave,
                "capacidad" => $capacidad,
                "semestre" => $semestre,
                "id_materia" => $id_materia,
                "id_docente" => $id_docente,
                "periodo" => $periodo,
                "anio" => $anio,
                "modalidad" => $modalidad,
                "estado" => $estado
            ]
        ]
    );

} catch (mysqli_sql_exception $e) {

    if ($transaccionIniciada) {
        try {
            $conn->rollback();
        } catch (Throwable $ignored) {
        }

        $transaccionIniciada = false;
    }

    error_log(
        "Error SQL grupos/registrar.php: " .
        $e->getMessage()
    );

    $codigoSQL = (int)$e->getCode();

    if ($codigoSQL === 1062) {

        responder(
            409,
            "La clave del grupo ya está registrada"
        );

    } elseif ($codigoSQL === 1452) {

        responder(
            409,
            "No se puede registrar el grupo porque la materia o el docente ya no existen."
        );

    } elseif ($codigoSQL === 3819) {

        responder(
            400,
            "Los datos del grupo no cumplen las restricciones de la base de datos."
        );

    } elseif (
        $codigoSQL === 1213 ||
        $codigoSQL === 1205
    ) {

        responder(
            409,
            "La operación tuvo un conflicto con otra actualización. Intenta nuevamente."
        );

    } else {

        responder(
            500,
            "Error de base de datos al registrar el grupo"
        );
    }

} catch (DomainException $e) {

    if ($transaccionIniciada) {
        try {
            $conn->rollback();
        } catch (Throwable $ignored) {
        }

        $transaccionIniciada = false;
    }

    $codigo = (int)$e->getCode();

    if ($codigo < 400 || $codigo > 599) {
        $codigo = 400;
    }

    responder($codigo, $e->getMessage());

} catch (Throwable $e) {

    if ($transaccionIniciada) {
        try {
            $conn->rollback();
        } catch (Throwable $ignored) {
        }

        $transaccionIniciada = false;
    }

    error_log(
        "Error inesperado grupos/registrar.php: " .
        $e->getMessage()
    );

    responder(
        500,
        "Ocurrió un error inesperado al registrar el grupo"
    );

} finally {

    if ($stmt !== null) {
        $stmt->close();
    }

    $conn->close();
}

?>
