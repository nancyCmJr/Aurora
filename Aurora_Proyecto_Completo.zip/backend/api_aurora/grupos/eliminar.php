<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'grupos', 'eliminar');

// Eliminar = CANCELAR LÓGICAMENTE. Nunca ejecuta DELETE sobre grupos/horarios.
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
function responder($codigo, $mensaje, $extra = []) {
    http_response_code($codigo);
    echo json_encode(array_merge(['success' => $codigo >= 200 && $codigo < 300, 'message' => $mensaje], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(405, 'Método no permitido');
$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) responder(400, 'JSON inválido');
$id_grupo = filter_var($data['id_grupo'] ?? null, FILTER_VALIDATE_INT);
if (!$id_grupo || $id_grupo <= 0) responder(400, 'ID de grupo inválido');
require_once __DIR__ . '/../conn.php';
$enTransaccion = false;
try {
    $conn->begin_transaction(); $enTransaccion = true;
    $stmt = $conn->prepare('SELECT id_grupo, clave_grupo, periodo, anio, estado FROM grupos WHERE id_grupo = ? FOR UPDATE');
    $stmt->bind_param('i', $id_grupo); $stmt->execute();
    $grupo = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$grupo) throw new DomainException('El grupo no existe', 404);
    if ($grupo['estado'] === 'Cancelado') {
        $conn->commit(); $enTransaccion = false;
        responder(200, 'El grupo ya está cancelado', ['data' => [
            'id_grupo' => (int)$id_grupo, 'clave_grupo' => $grupo['clave_grupo'],
            'periodo' => $grupo['periodo'], 'anio' => (int)$grupo['anio'], 'estado' => 'Cancelado'
        ]]);
    }
    // Si un alumno cursó o aprobó/reprobó, cancelar el grupo falsearía su historia.
    $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM kardex WHERE id_grupo = ? AND estado <> 'Baja'");
    $stmt->bind_param('i', $id_grupo); $stmt->execute();
    $registros = (int)$stmt->get_result()->fetch_assoc()['total']; $stmt->close();
    if ($registros > 0) throw new DomainException('El grupo tiene registros de kardex vigentes o calificados. No puede cancelarse; usa Cerrado cuando termine el curso', 409);

    // Los horarios se conservan, pero dejan de ocupar el salón y docente.
    $stmt = $conn->prepare("UPDATE horarios SET estado = 'Cancelado' WHERE id_grupo = ? AND estado = 'Activo'");
    $stmt->bind_param('i', $id_grupo); $stmt->execute();
    $horariosCancelados = $stmt->affected_rows; $stmt->close();

    $stmt = $conn->prepare("UPDATE grupos SET estado = 'Cancelado' WHERE id_grupo = ?");
    $stmt->bind_param('i', $id_grupo); $stmt->execute(); $stmt->close();
    $conn->commit(); $enTransaccion = false;
    responder(200, 'Grupo cancelado sin borrar su historial', ['data' => [
        'id_grupo' => (int)$id_grupo, 'clave_grupo' => $grupo['clave_grupo'],
        'periodo' => $grupo['periodo'], 'anio' => (int)$grupo['anio'],
        'estado_anterior' => $grupo['estado'], 'estado' => 'Cancelado',
        'horarios_cancelados' => (int)$horariosCancelados
    ]]);
} catch (DomainException $e) {
    if ($enTransaccion) $conn->rollback();
    responder(in_array((int)$e->getCode(), [404,409], true) ? (int)$e->getCode() : 400, $e->getMessage());
} catch (mysqli_sql_exception $e) {
    if ($enTransaccion) $conn->rollback();
    error_log('grupos/eliminar: ' . $e->getMessage());
    if (in_array((int)$e->getCode(), [1205,1213,1644], true)) responder(409, 'Conflicto o restricción de integridad al cancelar el grupo');
    responder(500, 'Error de base de datos al cancelar el grupo');
} catch (Throwable $e) {
    if ($enTransaccion) $conn->rollback();
    error_log('grupos/eliminar inesperado: ' . $e->getMessage());
    responder(500, 'Error inesperado al cancelar el grupo');
} finally {
    $conn->close();
}
