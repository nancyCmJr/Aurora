<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'grupos', 'actualizar');

// Aurora - actualización transaccional de grupos compatible con el historial.
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
function responder($codigo, $mensaje, $extra = []) {
    http_response_code($codigo);
    echo json_encode(array_merge(['success' => $codigo >= 200 && $codigo < 300, 'message' => $mensaje], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}
function enteroPositivo($valor) {
    if (is_int($valor) && $valor > 0) return $valor;
    if (is_string($valor) && ctype_digit($valor) && filter_var($valor, FILTER_VALIDATE_INT) !== false && (int)$valor > 0) return (int)$valor;
    return false;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(405, 'Método no permitido');
$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data) || !$data) responder(400, 'Envía un objeto JSON válido');
$id_grupo = enteroPositivo($data['id_grupo'] ?? null);
if ($id_grupo === false) responder(400, 'ID de grupo inválido');
require_once __DIR__ . '/../conn.php';

$enTransaccion = false;
try {
    $conn->begin_transaction();
    $enTransaccion = true;
    $stmt = $conn->prepare('SELECT id_grupo, clave_grupo, capacidad, semestre, id_materia, id_docente, periodo, anio, modalidad, estado FROM grupos WHERE id_grupo = ? FOR UPDATE');
    $stmt->bind_param('i', $id_grupo);
    $stmt->execute();
    $actual = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$actual) throw new DomainException('Grupo no encontrado', 404);

    // PATCH compatible: los campos omitidos conservan el valor original.
    $nuevo = $actual;
    foreach (['clave_grupo', 'capacidad', 'semestre', 'id_materia', 'id_docente', 'periodo', 'anio', 'modalidad', 'estado'] as $campo) {
        if (array_key_exists($campo, $data)) $nuevo[$campo] = $data[$campo];
    }
    foreach (['capacidad', 'semestre', 'id_materia', 'id_docente', 'anio'] as $campo) {
        $nuevo[$campo] = enteroPositivo($nuevo[$campo]);
        if ($nuevo[$campo] === false) throw new DomainException("$campo debe ser un entero positivo", 400);
    }
    if ($nuevo['semestre'] > 20) throw new DomainException('Semestre fuera de rango (1 a 20)', 400);
    if ($nuevo['anio'] < 1901 || $nuevo['anio'] > 2155) throw new DomainException('Año fuera de rango (1901 a 2155)', 400);
    foreach (['clave_grupo', 'periodo'] as $campo) {
        if (!is_string($nuevo[$campo])) throw new DomainException("$campo debe ser texto", 400);
        $nuevo[$campo] = trim($nuevo[$campo]);
        if ($nuevo[$campo] === '' || mb_strlen($nuevo[$campo], 'UTF-8') > 20) {
            throw new DomainException("$campo es obligatorio y admite hasta 20 caracteres", 400);
        }
    }
    if (!is_string($nuevo['modalidad']) || !in_array($nuevo['modalidad'], ['Entre semana', 'Sabado'], true)) {
        throw new DomainException('Modalidad inválida', 400);
    }
    $transiciones = [
        'Planeado' => ['Planeado', 'Abierto', 'Cancelado'],
        'Abierto' => ['Abierto', 'Cerrado', 'Cancelado'],
        'Cerrado' => ['Cerrado', 'Cancelado'],
        'Cancelado' => ['Cancelado']
    ];
    if (!is_string($nuevo['estado']) || !in_array($nuevo['estado'], $transiciones[$actual['estado']], true)) {
        throw new DomainException('Transición de estado no permitida', 409);
    }

    // Se preserva toda relación académica/histórica: NO cambiar su identidad.
    $stmt = $conn->prepare('SELECT (SELECT COUNT(*) FROM horarios WHERE id_grupo = ?) AS horarios, (SELECT COUNT(*) FROM kardex WHERE id_grupo = ?) AS kardex, (SELECT COUNT(*) FROM kardex WHERE id_grupo = ? AND estado = \'Cursando\') AS cursando, (SELECT COUNT(*) FROM kardex WHERE id_grupo = ? AND estado <> \'Baja\') AS ocupados');
    $stmt->bind_param('iiii', $id_grupo, $id_grupo, $id_grupo, $id_grupo);
    $stmt->execute();
    $conteos = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    $hayHistorial = ((int)$conteos['horarios'] > 0 || (int)$conteos['kardex'] > 0);
    $identidad = ['clave_grupo', 'semestre', 'id_materia', 'id_docente', 'periodo', 'anio', 'modalidad'];
    foreach ($identidad as $campo) {
        if ((string)$nuevo[$campo] !== (string)$actual[$campo] &&
            ($hayHistorial || in_array($actual['estado'], ['Cerrado', 'Cancelado'], true))) {
            throw new DomainException('No se pueden cambiar los datos académicos de un grupo con historial o cerrado; crea un grupo para el nuevo ciclo', 409);
        }
    }
    if (in_array($actual['estado'], ['Cerrado', 'Cancelado'], true) && (int)$nuevo['capacidad'] !== (int)$actual['capacidad']) {
        throw new DomainException('La capacidad de un grupo histórico no puede modificarse', 409);
    }
    if ($nuevo['capacidad'] < (int)$conteos['ocupados']) {
        throw new DomainException('Capacidad menor que los alumnos registrados en el kardex', 409);
    }
    if ($nuevo['estado'] === 'Cerrado' && (int)$conteos['cursando'] > 0) {
        throw new DomainException('Califica o da de baja a los alumnos cursando antes de cerrar el grupo', 409);
    }
    if ($nuevo['estado'] === 'Cancelado' && (int)$conteos['ocupados'] > 0) {
        throw new DomainException('No se puede cancelar un grupo con registros académicos distintos de Baja', 409);
    }

    // Docente y materia activos para grupos planeados/abiertos; FKs hacen el resto.
    if (in_array($nuevo['estado'], ['Planeado', 'Abierto'], true)) {
        $stmt = $conn->prepare("SELECT estado FROM docentes WHERE id_docente = ? FOR UPDATE");
        $stmt->bind_param('i', $nuevo['id_docente']); $stmt->execute();
        $docente = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if (!$docente || $docente['estado'] !== 'Activo') throw new DomainException('El docente no existe o está inactivo', 409);
        $stmt = $conn->prepare('SELECT estado FROM materias WHERE id_materia = ? FOR UPDATE');
        $stmt->bind_param('i', $nuevo['id_materia']); $stmt->execute();
        $materia = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if (!$materia || $materia['estado'] !== 'Activa') throw new DomainException('La materia no existe o está inactiva', 409);
    }
    if ($nuevo['estado'] !== 'Cancelado') {
        $stmt = $conn->prepare("SELECT MIN(s.capacidad) AS minima FROM horarios h JOIN salones s ON h.id_salon = s.id_salon WHERE h.id_grupo = ? AND h.estado = 'Activo'");
        $stmt->bind_param('i', $id_grupo); $stmt->execute();
        $limiteSalon = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ($limiteSalon['minima'] !== null && $nuevo['capacidad'] > (int)$limiteSalon['minima']) {
            throw new DomainException('La nueva capacidad supera la de un salón con horario activo', 409);
        }
    }

    // Cancelar también los horarios activos. El historial queda físicamente intacto.
    if ($actual['estado'] !== 'Cancelado' && $nuevo['estado'] === 'Cancelado') {
        $stmt = $conn->prepare("UPDATE horarios SET estado = 'Cancelado' WHERE id_grupo = ? AND estado = 'Activo'");
        $stmt->bind_param('i', $id_grupo); $stmt->execute(); $stmt->close();
    }
    $stmt = $conn->prepare('UPDATE grupos SET clave_grupo = ?, capacidad = ?, semestre = ?, id_materia = ?, id_docente = ?, periodo = ?, anio = ?, modalidad = ?, estado = ? WHERE id_grupo = ?');
    $stmt->bind_param('siiiisissi', $nuevo['clave_grupo'], $nuevo['capacidad'], $nuevo['semestre'], $nuevo['id_materia'], $nuevo['id_docente'], $nuevo['periodo'], $nuevo['anio'], $nuevo['modalidad'], $nuevo['estado'], $id_grupo);
    $stmt->execute(); $stmt->close();
    $conn->commit(); $enTransaccion = false;

    foreach (['capacidad', 'semestre', 'id_materia', 'id_docente', 'anio'] as $campo) $nuevo[$campo] = (int)$nuevo[$campo];
    responder(200, 'Grupo actualizado correctamente', ['data' => array_merge($nuevo, [
        'alumnos_cursando' => (int)$conteos['cursando'],
        'alumnos_ocupando' => (int)$conteos['ocupados'],
        'lugares_disponibles' => max(0, $nuevo['capacidad'] - (int)$conteos['ocupados'])
    ])]);
} catch (DomainException $e) {
    if ($enTransaccion) $conn->rollback();
    responder(in_array((int)$e->getCode(), [400, 404, 409], true) ? (int)$e->getCode() : 400, $e->getMessage());
} catch (mysqli_sql_exception $e) {
    if ($enTransaccion) $conn->rollback();
    error_log('grupos/actualizar: ' . $e->getMessage());
    $code = (int)$e->getCode();
    if ($code === 1062) responder(409, 'Ya existe un grupo con esa clave en el mismo periodo y año');
    if (in_array($code, [1451, 1452, 1644], true)) responder(409, 'La operación viola una relación o una regla de integridad de la base de datos');
    if ($code === 3819) responder(400, 'Los valores incumplen una restricción de la base de datos');
    if (in_array($code, [1213, 1205], true)) responder(409, 'Conflicto concurrente; vuelve a intentar');
    responder(500, 'No fue posible actualizar el grupo');
} catch (Throwable $e) {
    if ($enTransaccion) $conn->rollback();
    error_log('grupos/actualizar inesperado: ' . $e->getMessage());
    responder(500, 'Error inesperado al actualizar el grupo');
} finally {
    $conn->close();
}
