<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'grupos', 'consultar');

// Consulta detallada de un grupo de cualquier periodo histórico.
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
function responder($codigo, $mensaje, $extra = []) {
    http_response_code($codigo);
    echo json_encode(array_merge(['success' => $codigo >= 200 && $codigo < 300, 'message' => $mensaje], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'GET') responder(405, 'Método no permitido');
$id_grupo = filter_input(INPUT_GET, 'id_grupo', FILTER_VALIDATE_INT);
if (!$id_grupo || $id_grupo <= 0) responder(400, 'ID de grupo inválido');
require_once __DIR__ . '/../conn.php';
try {
    $sql = "SELECT
        g.id_grupo, g.clave_grupo, g.capacidad, g.semestre, g.periodo, g.anio,
        g.id_materia, m.clave_materia, m.nombre AS nombre_materia,
        m.creditos AS creditos_materia, m.horas_teoricas, m.horas_practicas,
        m.estado AS estado_materia,
        g.id_docente, d.codigo AS codigo_docente, d.nombre AS nombre_docente,
        d.seg_nombre AS segundo_nombre_docente, d.apellidos AS apellidos_docente,
        d.titulo_academico, d.estado AS estado_docente, g.modalidad, g.estado,
        (SELECT COUNT(*) FROM kardex k WHERE k.id_grupo = g.id_grupo AND k.estado = 'Cursando') AS alumnos_cursando,
        (SELECT COUNT(*) FROM kardex k WHERE k.id_grupo = g.id_grupo AND k.estado <> 'Baja') AS alumnos_ocupando,
        (SELECT COUNT(*) FROM horarios h WHERE h.id_grupo = g.id_grupo) AS total_horarios,
        (SELECT COUNT(*) FROM horarios h WHERE h.id_grupo = g.id_grupo AND h.estado = 'Activo') AS horarios_activos,
        (SELECT MIN(s.capacidad) FROM horarios h JOIN salones s ON s.id_salon = h.id_salon
         WHERE h.id_grupo = g.id_grupo AND h.estado = 'Activo') AS capacidad_minima_salon,
        CASE WHEN m.estado = 'Activa' AND d.estado = 'Activo' THEN 1 ELSE 0 END AS referencias_activas
        FROM grupos g JOIN materias m ON m.id_materia = g.id_materia
        JOIN docentes d ON d.id_docente = g.id_docente WHERE g.id_grupo = ? LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $id_grupo); $stmt->execute();
    $grupo = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$grupo) responder(404, 'Grupo no encontrado');
    foreach (['id_grupo','capacidad','semestre','anio','id_materia','creditos_materia','horas_teoricas','horas_practicas','id_docente','alumnos_cursando','alumnos_ocupando','total_horarios','horarios_activos'] as $campo) {
        $grupo[$campo] = (int)$grupo[$campo];
    }
    $grupo['referencias_activas'] = (bool)$grupo['referencias_activas'];
    $grupo['lugares_disponibles'] = max(0, $grupo['capacidad'] - $grupo['alumnos_ocupando']);
    $grupo['capacidad_minima_salon'] = $grupo['capacidad_minima_salon'] === null ? null : (int)$grupo['capacidad_minima_salon'];
    $grupo['capacidad_compatible_salones'] = $grupo['capacidad_minima_salon'] === null ? null : $grupo['capacidad'] <= $grupo['capacidad_minima_salon'];
    $grupo['puede_abrirse'] = $grupo['estado'] === 'Planeado' && $grupo['referencias_activas'] && $grupo['capacidad_compatible_salones'] !== false;
    responder(200, 'Grupo consultado correctamente', ['grupo' => $grupo]);
} catch (Throwable $e) {
    error_log('grupos/consultar: ' . $e->getMessage());
    responder(500, 'No fue posible consultar el grupo');
} finally {
    $conn->close();
}
