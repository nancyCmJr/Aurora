<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'edificios', 'actualizar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if (
    !isset($data->id_edificio) ||
    !isset($data->nombre) ||
    !isset($data->estado) ||
    !is_numeric($data->id_edificio) ||
    (int)$data->id_edificio <= 0 ||
    trim($data->nombre) === ''
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Todos los campos son obligatorios"
    ]);
    exit();
}

$id_edificio = (int)$data->id_edificio;
$nombre = trim($data->nombre);
$estado = $data->estado;

if (mb_strlen($nombre, 'UTF-8') > 30) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El nombre no puede superar los 30 caracteres"
    ]);
    exit();
}

if (!in_array($estado, ["Activo", "Inactivo"], true)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El estado del edificio no es válido"
    ]);
    exit();
}

// Verificar que el edificio exista.
$sqlConsulta = "SELECT id_edificio
                FROM edificios
                WHERE id_edificio = ?";

$stmtConsulta = $conn->prepare($sqlConsulta);
$stmtConsulta->bind_param("i", $id_edificio);
$stmtConsulta->execute();

if ($stmtConsulta->get_result()->num_rows === 0) {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "El edificio que intenta actualizar no existe"
    ]);

    $stmtConsulta->close();
    $conn->close();
    exit();
}

$stmtConsulta->close();

// Actualizar edificio.
$sql = "UPDATE edificios
        SET nombre = ?, estado = ?
        WHERE id_edificio = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $nombre, $estado, $id_edificio);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Edificio actualizado correctamente"
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "No fue posible actualizar el edificio"
    ]);
}

$stmt->close();
$conn->close();

?>
