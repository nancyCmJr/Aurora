<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'edificios', 'registrar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if (
    !isset($data->nombre) ||
    trim($data->nombre) === ''
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El nombre del edificio es obligatorio"
    ]);
    exit();
}

$nombre = trim($data->nombre);
$estado = isset($data->estado) ? $data->estado : "Activo";

if (strlen($nombre) > 30) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El nombre no puede superar los 30 caracteres"
    ]);
    exit();
}

if (!in_array($estado, ["Activo", "Inactivo"], true)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El estado del edificio no es válido"
    ]);
    exit();
}

$sql = "INSERT INTO edificios (nombre, estado)
        VALUES (?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $nombre, $estado);

if ($stmt->execute()) {
    http_response_code(201);

    echo json_encode([
        "success" => true,
        "message" => "Edificio registrado correctamente",
        "id_edificio" => $conn->insert_id
    ]);
} else {
    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "No fue posible registrar el edificio"
    ]);
}

$stmt->close();
$conn->close();

?>
