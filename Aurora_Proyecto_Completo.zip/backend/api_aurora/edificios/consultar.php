<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'edificios', 'consultar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

if (
    !isset($_GET['id_edificio']) ||
    !ctype_digit($_GET['id_edificio']) ||
    (int)$_GET['id_edificio'] <= 0
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El identificador del edificio es obligatorio"
    ]);
    exit();
}

$id_edificio = (int)$_GET['id_edificio'];

$sql = "SELECT id_edificio, nombre, estado
        FROM edificios
        WHERE id_edificio = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_edificio);
$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "El edificio no existe"
    ]);
} else {
    echo json_encode([
        "success" => true,
        "edificio" => $resultado->fetch_assoc()
    ]);
}

$stmt->close();
$conn->close();

?>
