<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'edificios', 'eliminar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if (
    !isset($data->id_edificio) ||
    !is_numeric($data->id_edificio) ||
    (int)$data->id_edificio <= 0
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El identificador del edificio es obligatorio"
    ]);
    exit();
}

$id_edificio = (int)$data->id_edificio;

$sql = "UPDATE edificios
        SET estado = 'Inactivo'
        WHERE id_edificio = ?
        AND estado = 'Activo'";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_edificio);
$stmt->execute();

if ($stmt->affected_rows > 0) {

    echo json_encode([
        "success" => true,
        "message" => "Edificio desactivado correctamente"
    ]);

} else {

    // Comprobar si el edificio existe.
    $sqlConsulta = "SELECT estado
                    FROM edificios
                    WHERE id_edificio = ?";

    $stmtConsulta = $conn->prepare($sqlConsulta);
    $stmtConsulta->bind_param("i", $id_edificio);
    $stmtConsulta->execute();

    $resultado = $stmtConsulta->get_result();

    if ($resultado->num_rows === 0) {

        http_response_code(404);

        echo json_encode([
            "success" => false,
            "message" => "El edificio no existe"
        ]);

    } else {

        echo json_encode([
            "success" => false,
            "message" => "El edificio ya se encuentra inactivo"
        ]);
    }

    $stmtConsulta->close();
}

$stmt->close();
$conn->close();

?>
