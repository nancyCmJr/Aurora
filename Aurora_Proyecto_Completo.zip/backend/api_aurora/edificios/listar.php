<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'edificios', 'listar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$sql = "SELECT id_edificio, nombre, estado
        FROM edificios
        ORDER BY nombre ASC";

$resultado = $conn->query($sql);

if ($resultado) {

    $edificios = [];

    while ($fila = $resultado->fetch_assoc()) {
        $edificios[] = $fila;
    }

    echo json_encode([
        "success" => true,
        "total" => count($edificios),
        "edificios" => $edificios
    ]);

} else {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error al consultar los edificios"
    ]);
}

$conn->close();

?>
