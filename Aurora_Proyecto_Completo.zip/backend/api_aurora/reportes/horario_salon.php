<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reportes', 'horario_salon');
require_once __DIR__ . '/../lib/academico.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') auroraResponder(405,'Método no permitido');
$id=auroraId($_GET['id_salon'] ?? null,'id_salon');
$sql='SELECT * FROM vw_horario_grupo WHERE id_salon=?';$params=[$id];
if (isset($_GET['dia_semana']) && $_GET['dia_semana']!=='') {
 $sql.=' AND dia_semana=?';$params[]=auroraEnum($_GET['dia_semana'],['Lunes','Martes','Miercoles','Jueves','Viernes','Sabado'],'dia_semana');
}
if (isset($_GET['periodo']) && $_GET['periodo']!=='') {$sql.=' AND periodo=?';$params[]=$_GET['periodo'];}
if (isset($_GET['anio']) && $_GET['anio']!=='') {$sql.=' AND anio=?';$params[]=auroraId($_GET['anio'],'anio');}
if (isset($_GET['estado_horario']) && $_GET['estado_horario']!=='') {
 $sql.=' AND estado_horario=?';$params[]=auroraEnum($_GET['estado_horario'],['Activo','Cancelado'],'estado_horario');
}
$sql.=" ORDER BY anio DESC, periodo,FIELD(dia_semana,'Lunes','Martes','Miercoles','Jueves','Viernes','Sabado'),hora_inicio";
try {$rows=auroraFilas($conn,$sql,$params); auroraResponder(200,'Reporte de salón',['total'=>count($rows),'reporte'=>$rows]);}
catch(Throwable $e){auroraFallo($e,$conn);}
