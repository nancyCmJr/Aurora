<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reportes', 'kardex_alumno');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Método no permitido"]);
    exit();
}

require_once __DIR__ . "/../conn.php";

$numero_control = trim($_GET["numero_control"] ?? "");
$periodo = $_GET["periodo"] ?? null;
$estado_kardex = $_GET["estado_kardex"] ?? null;
$anio = null;

if (isset($_GET["anio"])) {
    $anio = filter_var($_GET["anio"], FILTER_VALIDATE_INT);

    if (!$anio || $anio < 1901 || $anio > 2155) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "Año no válido"]);
        exit();
    }
}

$estados = ["Cursando", "Aprobada", "Reprobada", "Baja"];

if (
    $estado_kardex !== null &&
    !in_array($estado_kardex, $estados, true)
) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Estado de kardex no válido"]);
    exit();
}

if ($periodo !== null && trim($periodo) === "") {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "El periodo no puede estar vacío"]);
    exit();
}

try {
    $sql = "SELECT * FROM vw_kardex_alumno WHERE 1 = 1";

    $tipos = "";
    $parametros = [];

    if ($numero_control !== "") {
        $sql .= " AND numero_control = ?";
        $tipos .= "s";
        $parametros[] = $numero_control;
    }

    if ($periodo !== null) {
        $sql .= " AND periodo = ?";
        $tipos .= "s";
        $parametros[] = $periodo;
    }

    if ($anio !== null) {
        $sql .= " AND anio = ?";
        $tipos .= "i";
        $parametros[] = $anio;
    }

    if ($estado_kardex !== null) {
        $sql .= " AND estado_kardex = ?";
        $tipos .= "s";
        $parametros[] = $estado_kardex;
    }

    $sql .= " ORDER BY numero_control ASC, anio DESC, periodo ASC, materia ASC";

    $stmt = $conn->prepare($sql);

    if ($tipos !== "") {
        $stmt->bind_param($tipos, ...$parametros);
    }

    $stmt->execute();
    $resultado = $stmt->get_result();

    $datos = [];

    while ($fila = $resultado->fetch_assoc()) {
        $datos[] = $fila;
    }

    echo json_encode([
        "success" => true,
        "total" => count($datos),
        "reporte" => $datos
    ]);

    $stmt->close();

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error al generar el reporte de kardex"
    ]);
}

$conn->close();
?>
