<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reportes', 'horario_docente');
require_once __DIR__ . '/../lib/academico.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') auroraResponder(405,'Método no permitido');
$id = isset($_GET['id_docente']) ? auroraId($_GET['id_docente'],'id_docente') : null;
$nombre = trim((string)($_GET['docente'] ?? ''));
if ($id === null && $nombre === '') auroraResponder(400,'Proporciona id_docente o docente');
if ($usuarioSesion['rol']==='Docente' && $id !== (int)$usuarioSesion['id_docente'])
    auroraResponder(403,'Solo puedes consultar tu propio horario por id_docente');
$sql="SELECT v.* FROM vw_horario_grupo v JOIN grupos g ON g.id_grupo=v.id_grupo WHERE 1=1";
$params=[];
if ($id!==null) {$sql.=' AND g.id_docente=?';$params[]=$id;}
else {$sql.=' AND v.docente LIKE ?';$params[]='%'.$nombre.'%';}
if (isset($_GET['periodo']) && $_GET['periodo']!=='') {$sql.=' AND v.periodo=?';$params[]=$_GET['periodo'];}
if (isset($_GET['anio']) && $_GET['anio']!=='') {$sql.=' AND v.anio=?';$params[]=auroraId($_GET['anio'],'anio');}
if (isset($_GET['estado_horario']) && $_GET['estado_horario']!=='') {
 $sql.=' AND v.estado_horario=?';$params[]=auroraEnum($_GET['estado_horario'],['Activo','Cancelado'],'estado_horario');
}
$sql.=" ORDER BY v.anio DESC, v.periodo, FIELD(v.dia_semana,'Lunes','Martes','Miercoles','Jueves','Viernes','Sabado'),v.hora_inicio";
try {$datos=auroraFilas($conn,$sql,$params);
 auroraResponder(200,'Horario del docente',['total'=>count($datos),'reporte'=>$datos]);
} catch(Throwable $e){auroraFallo($e,$conn);}
