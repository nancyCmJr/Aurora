<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reportes', 'alumnos_inscritos');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    http_response_code(405);
    echo json_encode(["success" => false, "message" => "Método no permitido"]);
    exit();
}

require_once __DIR__ . "/../conn.php";

$id_carrera = null;

if (isset($_GET["id_carrera"])) {
    $id_carrera = filter_var($_GET["id_carrera"], FILTER_VALIDATE_INT);

    if (!$id_carrera || $id_carrera <= 0) {
        http_response_code(400);
        echo json_encode(["success" => false, "message" => "ID de carrera no válido"]);
        exit();
    }
}

$estado_inscripcion = $_GET["estado_inscripcion"] ?? null;
$estado_alumno = $_GET["estado_alumno"] ?? null;

$estadosInscripcion = ["Finalizada", "En curso", "Cancelada"];
$estadosAlumno = [
    "Activo",
    "Baja temporal",
    "Baja definitiva",
    "Egresado",
    "Titulado"
];

if (
    $estado_inscripcion !== null &&
    !in_array($estado_inscripcion, $estadosInscripcion, true)
) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Estado de inscripción no válido"]);
    exit();
}

if (
    $estado_alumno !== null &&
    !in_array($estado_alumno, $estadosAlumno, true)
) {
    http_response_code(400);
    echo json_encode(["success" => false, "message" => "Estado de alumno no válido"]);
    exit();
}

try {
    $sql = "SELECT * FROM vw_alumnos_inscritos WHERE 1 = 1";

    $tipos = "";
    $parametros = [];

    if ($id_carrera !== null) {
        $sql .= " AND id_carrera = ?";
        $tipos .= "i";
        $parametros[] = $id_carrera;
    }

    if ($estado_inscripcion !== null) {
        $sql .= " AND estado_inscripcion = ?";
        $tipos .= "s";
        $parametros[] = $estado_inscripcion;
    }

    if ($estado_alumno !== null) {
        $sql .= " AND estado_alumno = ?";
        $tipos .= "s";
        $parametros[] = $estado_alumno;
    }

    $sql .= " ORDER BY carrera ASC, semestre ASC, alumno ASC";

    $stmt = $conn->prepare($sql);

    if ($tipos !== "") {
        $stmt->bind_param($tipos, ...$parametros);
    }

    $stmt->execute();
    $resultado = $stmt->get_result();

    $datos = [];

    while ($fila = $resultado->fetch_assoc()) {
        $datos[] = $fila;
    }

    echo json_encode([
        "success" => true,
        "total" => count($datos),
        "reporte" => $datos
    ]);

    $stmt->close();

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Error al generar el reporte de alumnos inscritos"
    ]);
}

$conn->close();
?>
