<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reportes', 'horario_grupo');
require_once __DIR__ . '/../lib/academico.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') auroraResponder(405,'Método no permitido');
$sql='SELECT * FROM vw_horario_grupo WHERE 1=1';$params=[];
foreach (['id_grupo'=>'id_grupo','periodo'=>'periodo','anio'=>'anio','estado_horario'=>'estado_horario'] as $key=>$column) {
 if (!isset($_GET[$key])||$_GET[$key]==='') continue;
 $v=$_GET[$key];
 if (in_array($key,['id_grupo','anio'],true)) $v=auroraId($v,$key);
 if ($key==='estado_horario') $v=auroraEnum($v,['Activo','Cancelado'],'estado_horario');
 $sql.=' AND '.$column.'=?';$params[]=$v;
}
$sql.=" ORDER BY anio DESC,periodo,id_grupo,FIELD(dia_semana,'Lunes','Martes','Miercoles','Jueves','Viernes','Sabado'),hora_inicio";
try {$rows=auroraFilas($conn,$sql,$params);auroraResponder(200,'Horarios por grupo',['total'=>count($rows),'reporte'=>$rows]);}
catch(Throwable $e){auroraFallo($e,$conn);}
