<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reportes', 'avance_academico');
require_once __DIR__ . '/../lib/academico.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') auroraResponder(405,'Método no permitido');
$numero=trim((string)($_GET['numero_control'] ?? ''));
if ($numero==='' || mb_strlen($numero)>20) auroraResponder(400,'Se requiere numero_control válido');
try {
 $al=auroraFila($conn,'SELECT numero_control,nombre,seg_nombre,apellidos,semestre,estado FROM alumnos WHERE numero_control=?',[$numero]);
 if(!$al) throw new DomainException('Alumno inexistente',404);
 if (isset($_GET['id_inscripciones']) && $_GET['id_inscripciones']!=='') {
    $id=auroraId($_GET['id_inscripciones'],'id_inscripciones');
    $ins=auroraFila($conn,'SELECT i.*,c.nombre AS carrera,c.total_creditos FROM inscripciones i
        JOIN carreras c ON c.id_carrera=i.id_carrera WHERE i.numero_control=? AND i.id_inscripciones=?',[$numero,$id]);
 } else {
    $ins=auroraFila($conn,"SELECT i.*,c.nombre AS carrera,c.total_creditos FROM inscripciones i
      JOIN carreras c ON c.id_carrera=i.id_carrera WHERE i.numero_control=?
      ORDER BY (i.estado='En curso') DESC,i.anio DESC,i.id_inscripciones DESC LIMIT 1",[$numero]);
 }
 if(!$ins) throw new DomainException('El alumno no tiene inscripción en la carrera solicitada',404);
 $ret=auroraFila($conn,"SELECT id_reticula,anio FROM reticulas WHERE id_carrera=? AND estado='Vigente' LIMIT 1",[(int)$ins['id_carrera']]);
 if(!$ret) throw new DomainException('No existe una retícula vigente para la carrera',404);
 $sql="SELECT rm.id_materia,rm.semestre,m.clave_materia,m.nombre AS materia,m.creditos,
 CASE WHEN EXISTS (SELECT 1 FROM kardex k JOIN grupos g ON g.id_grupo=k.id_grupo
       WHERE k.numero_control=? AND g.id_materia=m.id_materia AND k.estado='Aprobada') THEN 'Aprobada'
      WHEN EXISTS (SELECT 1 FROM kardex k JOIN grupos g ON g.id_grupo=k.id_grupo
       WHERE k.numero_control=? AND g.id_materia=m.id_materia AND k.estado='Cursando') THEN 'Cursando'
      WHEN EXISTS (SELECT 1 FROM kardex k JOIN grupos g ON g.id_grupo=k.id_grupo
       WHERE k.numero_control=? AND g.id_materia=m.id_materia AND k.estado='Reprobada') THEN 'Reprobada'
      ELSE 'Pendiente' END AS situacion
 FROM reticula_materia rm JOIN materias m ON m.id_materia=rm.id_materia
 WHERE rm.id_reticula=? ORDER BY rm.semestre,m.nombre";
 $materias=auroraFilas($conn,$sql,[$numero,$numero,$numero,(int)$ret['id_reticula']]);
 $por=[]; $credTot=0;$credApr=0;$apr=0;$cur=0;$pend=0;$repr=0;
 foreach($materias as $m){$sem=(int)$m['semestre'];$cr=(int)$m['creditos'];$situ=$m['situacion'];
  $credTot+=$cr; if(!isset($por[$sem])) $por[$sem]=['semestre'=>$sem,'total_materias'=>0,'aprobadas'=>0,'cursando'=>0,'reprobadas'=>0,'pendientes'=>0,'creditos_totales'=>0,'creditos_aprobados'=>0];
  $por[$sem]['total_materias']++;$por[$sem]['creditos_totales']+=$cr;
  if($situ==='Aprobada'){$apr++;$credApr+=$cr;$por[$sem]['aprobadas']++;$por[$sem]['creditos_aprobados']+=$cr;}
  elseif($situ==='Cursando'){$cur++;$por[$sem]['cursando']++;}
  elseif($situ==='Reprobada'){$repr++;$por[$sem]['reprobadas']++;}
  else{$pend++;$por[$sem]['pendientes']++;}
 }
 auroraResponder(200,'Avance académico de la retícula vigente',[
   'alumno'=>['numero_control'=>$numero,'nombre'=>trim($al['nombre'].' '.($al['seg_nombre']??'').' '.$al['apellidos']),
      'semestre_actual'=>(int)$al['semestre'],'estado'=>$al['estado']],
   'carrera'=>['id_carrera'=>(int)$ins['id_carrera'],'nombre'=>$ins['carrera'],
      'total_creditos_carrera'=>(int)$ins['total_creditos']],
   'inscripcion'=>['id_inscripciones'=>(int)$ins['id_inscripciones'],'periodo'=>$ins['periodo'],'anio'=>(int)$ins['anio']],
   'reticula'=>$ret,
   'resumen'=>['total_materias'=>count($materias),'materias_aprobadas'=>$apr,'materias_cursando'=>$cur,
      'materias_reprobadas'=>$repr,'materias_pendientes'=>$pend,'creditos_totales_reticula'=>$credTot,
      'creditos_aprobados'=>$credApr,'porcentaje_avance'=>$credTot>0?round($credApr/$credTot*100,2):0],
   'avance_por_semestre'=>array_values($por),'materias'=>$materias,
   'nota'=>'Se utiliza la retícula vigente; el esquema no fija una versión histórica de retícula por alumno']);
} catch(Throwable $e){auroraFallo($e,$conn);}
