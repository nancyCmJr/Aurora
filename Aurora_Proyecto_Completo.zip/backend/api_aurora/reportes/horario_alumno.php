<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reportes', 'horario_alumno');
require_once __DIR__ . '/../lib/academico.php';
if ($_SERVER['REQUEST_METHOD'] !== 'GET') auroraResponder(405,'Método no permitido');
$numero=trim((string)($_GET['numero_control'] ?? ''));
if ($numero==='' || mb_strlen($numero)>20) auroraResponder(400,'Número de control inválido');
$sql="SELECT k.numero_control,k.estado AS estado_kardex,k.periodo,k.anio,
 g.id_grupo,g.clave_grupo,g.estado AS estado_grupo,g.modalidad,
 m.id_materia,m.clave_materia,m.nombre AS materia,
 d.id_docente,d.nombre AS nombre_docente,d.apellidos AS apellidos_docente,
 h.id_horario,h.dia_semana,h.hora_inicio,h.hora_fin,h.estado AS estado_horario,
 h.id_salon,s.nombre AS salon,s.id_edificio
 FROM kardex k JOIN grupos g ON g.id_grupo=k.id_grupo
 JOIN horarios h ON h.id_grupo=g.id_grupo
 JOIN salones s ON s.id_salon=h.id_salon
 JOIN materias m ON m.id_materia=g.id_materia
 JOIN docentes d ON d.id_docente=g.id_docente
 WHERE k.numero_control=?";
$params=[$numero];
if (isset($_GET['periodo']) && $_GET['periodo']!=='') {$sql.=' AND k.periodo=?';$params[]=$_GET['periodo'];}
if (isset($_GET['anio']) && $_GET['anio']!=='') {$sql.=' AND k.anio=?';$params[]=auroraId($_GET['anio'],'anio');}
if (($_GET['incluir_cancelados'] ?? '0') !== '1') $sql.=" AND h.estado='Activo' AND k.estado<>'Baja'";
$sql.=" ORDER BY k.anio DESC,k.periodo,FIELD(h.dia_semana,'Lunes','Martes','Miercoles','Jueves','Viernes','Sabado'),h.hora_inicio";
try {
    $rows=auroraFilas($conn,$sql,$params);
    auroraResponder(200,'Horario académico del alumno',['numero_control'=>$numero,'total'=>count($rows),'reporte'=>$rows]);
} catch(Throwable $e){auroraFallo($e,$conn);}
