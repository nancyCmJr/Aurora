<?php
/** Ejecutar solo por consola: php scripts/crear_admin_inicial.php */
if (PHP_SAPI !== 'cli') { http_response_code(403); exit('Acceso denegado'); }
require_once __DIR__ . '/../conn.php';
$previo = $conn->query("SELECT COUNT(*) total FROM usuarios WHERE rol='Admin'")->fetch_assoc();
if ((int)$previo['total'] > 0) { fwrite(STDERR,"Ya existe un administrador. No se crean administradores con este script.\n");exit(1); }
function pedir(string $mensaje): string {
    fwrite(STDOUT,$mensaje);
    $s=fgets(STDIN);
    if ($s === false) { fwrite(STDERR,"Entrada cancelada\n");exit(1); }
    return trim($s);
}
$codigo=pedir('Código del administrador (máx 30): ');
$nombre=pedir('Nombre de usuario (máx 50): ');
$correo=pedir('Correo: ');
$password=pedir('Contraseña de al menos 12 caracteres (visible al escribir): ');
if (!$codigo || mb_strlen($codigo)>30 || !$nombre || mb_strlen($nombre)>50
    || !filter_var($correo,FILTER_VALIDATE_EMAIL) || mb_strlen($correo)>100 || strlen($password)<12) {
    fwrite(STDERR,"Datos inválidos. No se creó ninguna cuenta.\n");exit(1);
}
try {
    $hash=password_hash($password,PASSWORD_DEFAULT);
    $stmt=$conn->prepare("INSERT INTO usuarios (codigo,nombre_usuario,rol,correo,password,estado)
       VALUES (?,?,'Admin',?,?,'Activo')");
    $stmt->bind_param('ssss',$codigo,$nombre,$correo,$hash);
    $stmt->execute();$stmt->close();
    fwrite(STDOUT,"Administrador inicial creado correctamente.\n");
} catch(Throwable $e) {
    fwrite(STDERR,"No se creó el administrador. Verifica que no haya duplicados ni errores de conexión.\n");exit(1);
}
