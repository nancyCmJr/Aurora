<?php
/**
 * Configuración de sesiones PHP SIN JWT.
 * Definir AURORA_ALLOWED_ORIGINS con los orígenes confiables separados por coma.
 * Ejemplo: http://localhost:8100,https://miapp.ejemplo.mx
 * Para orígenes de terceros HTTPS que requieran cookies: configurar
 * AURORA_COOKIE_SAMESITE=None y HTTPS habilitado.
 */
function auroraResponder(int $codigo, string $mensaje, array $adicionales = []): never
{
    http_response_code($codigo);
    echo json_encode(array_merge([
        'success' => $codigo >= 200 && $codigo < 300,
        'message' => $mensaje
    ], $adicionales), JSON_UNESCAPED_UNICODE);
    exit;
}

function auroraIniciarSesion(): void
{
    header('Content-Type: application/json; charset=UTF-8');
    header('Cache-Control: no-store');

    $origen = $_SERVER['HTTP_ORIGIN'] ?? '';
    $config = getenv('AURORA_ALLOWED_ORIGINS') ?: 'http://localhost:8100,http://localhost:8101,http://localhost:8102,http://localhost:4200,http://localhost,http://127.0.0.1:8100';
    $permitidos = array_map('trim', explode(',', $config));

    if ($origen !== '') {
        if (!in_array($origen, $permitidos, true)) {
            auroraResponder(403, 'Origen no autorizado');
        }
        header('Access-Control-Allow-Origin: ' . $origen);
        header('Access-Control-Allow-Credentials: true');
        header('Vary: Origin');
    }
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');

    if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
        http_response_code(204);
        exit;
    }

    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $sameSite = getenv('AURORA_COOKIE_SAMESITE') ?: 'Lax';
    if (!in_array($sameSite, ['Lax', 'Strict', 'None'], true)) {
        auroraResponder(500, 'Configuración de cookies inválida');
    }
    if ($sameSite === 'None' && !$https) {
        auroraResponder(500, 'SameSite=None requiere HTTPS');
    }

    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_name('AURORASESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $https,
        'httponly' => true,
        'samesite' => $sameSite
    ]);
    session_start();
}

/**
 * Debe llamarse dentro de cada endpoint protegido, tras cargar conn.php.
 * Las comprobaciones de propiedad de datos (alumno/docente) son adicionales.
 */
function auroraExigirSesion(mysqli $conn, array $roles = []): array
{
    $codigo = $_SESSION['codigo'] ?? null;
    if (!is_string($codigo) || $codigo === '') {
        auroraResponder(401, 'Debes iniciar sesión');
    }

    $stmt = $conn->prepare(
        'SELECT codigo, nombre_usuario, rol, correo, numero_control, id_docente, estado
         FROM usuarios WHERE codigo = ? LIMIT 1'
    );
    $stmt->bind_param('s', $codigo);
    $stmt->execute();
    $usuario = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$usuario || $usuario['estado'] !== 'Activo') {
        $_SESSION = [];
        auroraResponder(401, 'Sesión no válida o cuenta desactivada');
    }
    if ($roles !== [] && !in_array($usuario['rol'], $roles, true)) {
        auroraResponder(403, 'No tienes permiso para realizar esta operación');
    }
    return $usuario;
}
