<?php
require_once __DIR__ . '/session_config.php';
auroraIniciarSesion();
if ($_SERVER['REQUEST_METHOD']!=='POST') auroraResponder(405,'Método no permitido');
require_once __DIR__ . '/../conn.php';
$usuario=auroraExigirSesion($conn);
$data=json_decode(file_get_contents('php://input'),true);
if (!is_array($data) || !is_string($data['password_actual']??null) || !is_string($data['password_nueva']??null)
    || strlen($data['password_nueva'])<12 || strlen($data['password_nueva'])>128) {
    auroraResponder(400,'Es necesario enviar password_actual y password_nueva (12 a 128 caracteres)');
}
try {
    $stmt=$conn->prepare('SELECT password FROM usuarios WHERE codigo=? AND estado=\'Activo\'');
    $stmt->bind_param('s',$usuario['codigo']);$stmt->execute();
    $row=$stmt->get_result()->fetch_assoc();$stmt->close();
    if (!$row || !password_verify($data['password_actual'],$row['password']))
        auroraResponder(403,'Contraseña actual incorrecta');
    if (hash_equals($data['password_actual'],$data['password_nueva']))
        auroraResponder(400,'La contraseña nueva debe ser diferente');
    $hash=password_hash($data['password_nueva'],PASSWORD_DEFAULT);
    $stmt=$conn->prepare('UPDATE usuarios SET password=? WHERE codigo=?');
    $stmt->bind_param('ss',$hash,$usuario['codigo']);$stmt->execute();$stmt->close();
    session_regenerate_id(true);
    auroraResponder(200,'Contraseña actualizada correctamente');
} catch(Throwable $e) {error_log('Aurora cambio password: '.$e->getMessage()); auroraResponder(500,'No se pudo cambiar la contraseña');}
