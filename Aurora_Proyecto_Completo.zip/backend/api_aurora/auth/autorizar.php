<?php
require_once __DIR__ . '/session_config.php';

function auroraAutorizarEndpoint(mysqli $conn, string $modulo, string $accion): array
{
    $esLectura = in_array($accion, ['listar', 'consultar', 'listar_materias', 'validar', 'validar_requisito', 'validar_grupo'], true)
        || $modulo === 'reportes';
    $roles = ['Admin'];
    if ($esLectura && in_array($modulo, ['edificios','areas','salones','carreras','materias','reticulas','grupos','horarios'], true)) {
        $roles = ['Admin', 'Docente', 'Alumno'];
    }
    if ($esLectura && in_array($modulo, ['alumnos','docentes'], true) && $accion === 'consultar') {
        $roles = ['Admin', 'Docente', 'Alumno'];
    }
    if ($modulo === 'kardex' && $accion === 'actualizar') {
        $roles = ['Admin','Docente'];
    }
    if ($modulo === 'kardex' && $accion === 'por_grupo') {
        $roles = ['Admin','Docente'];
    }
    if ($modulo === 'reportes') {
        $roles = match ($accion) {
            'horario_grupo','horario_salon' => ['Admin','Docente','Alumno'],
            'horario_docente' => ['Admin','Docente'],
            'horario_alumno' => ['Admin','Alumno'],
            'kardex_alumno','avance_academico' => ['Admin','Alumno'],
            default => ['Admin']
        };
    }
    $usuario = auroraExigirSesion($conn, $roles);
    if ($usuario['rol'] === 'Admin') return $usuario;

    if ($modulo === 'alumnos' && $accion === 'consultar') {
        $solicitado = (string) ($_GET['numero_control'] ?? '');
        if ($usuario['rol'] !== 'Alumno' || $solicitado === '' || $solicitado !== (string)$usuario['numero_control']) {
            auroraResponder(403, 'Solo puedes consultar tu ficha personal');
        }
    }
    if ($modulo === 'docentes' && $accion === 'consultar') {
        $solicitado = filter_var($_GET['id_docente'] ?? null, FILTER_VALIDATE_INT);
        if ($usuario['rol'] !== 'Docente' || $solicitado !== (int)$usuario['id_docente']) {
            auroraResponder(403, 'Solo puedes consultar tu ficha personal');
        }
    }
    if ($modulo === 'reportes' && in_array($accion, ['kardex_alumno','avance_academico'], true)) {
        if ($usuario['rol'] !== 'Alumno') auroraResponder(403, 'No autorizado');
        if (($_GET['numero_control'] ?? '') !== $usuario['numero_control']) {
            auroraResponder(403, 'Solo puedes consultar tu propio historial');
        }
    }
    if ($modulo === 'reportes' && $accion === 'horario_alumno') {
        if ($usuario['rol'] !== 'Alumno' || ($_GET['numero_control'] ?? '') !== $usuario['numero_control']) {
            auroraResponder(403, 'Solo puedes consultar tu propio horario');
        }
    }
    if ($modulo === 'reportes' && $accion === 'horario_docente') {
        if ($usuario['rol'] !== 'Docente' ||
            (int)filter_var($_GET['id_docente'] ?? null, FILTER_VALIDATE_INT) !== (int)$usuario['id_docente']) {
            auroraResponder(403, 'Solo puedes consultar tu propio horario');
        }
    }
    return $usuario;
}
