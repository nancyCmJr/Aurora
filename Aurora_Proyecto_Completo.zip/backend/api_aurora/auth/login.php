<?php
require_once __DIR__ . '/session_config.php';
auroraIniciarSesion();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST, OPTIONS');
    auroraResponder(405, 'Método no permitido');
}

$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) {
    auroraResponder(400, 'Formato JSON inválido');
}
$correo = isset($data['correo']) && is_string($data['correo']) ? trim($data['correo']) : '';
$contra = $data['contra'] ?? null;
if (
    $correo === '' || strlen($correo) > 100 ||
    !filter_var($correo, FILTER_VALIDATE_EMAIL) ||
    !is_string($contra) || $contra === ''
) {
    auroraResponder(400, 'Proporciona un correo y una contraseña válidos');
}

require_once __DIR__ . '/../conn.php';

try {
    $stmt = $conn->prepare(
        'SELECT codigo, nombre_usuario, rol, correo, password,
                numero_control, id_docente, estado
         FROM usuarios WHERE correo = ? LIMIT 1'
    );
    $stmt->bind_param('s', $correo);
    $stmt->execute();
    $usuario = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$usuario || !password_verify($contra, $usuario['password'])) {
        auroraResponder(401, 'Credenciales incorrectas');
    }
    if ($usuario['estado'] !== 'Activo') {
        auroraResponder(403, 'La cuenta no está activa');
    }

    $rol = $usuario['rol'];
    $control = $usuario['numero_control'];
    $docente = $usuario['id_docente'];
    if (
        !in_array($rol, ['Admin', 'Docente', 'Alumno'], true) ||
        ($rol === 'Admin' && ($control !== null || $docente !== null)) ||
        ($rol === 'Docente' && ($docente === null || $control !== null)) ||
        ($rol === 'Alumno' && ($control === null || $docente !== null))
    ) {
        auroraResponder(403, 'Vinculación del usuario inválida');
    }

    session_regenerate_id(true);
    $_SESSION = ['codigo' => $usuario['codigo']];
    unset($usuario['password']);

    auroraResponder(200, 'Inicio de sesión exitoso', ['data' => $usuario]);
} catch (mysqli_sql_exception $e) {
    error_log('Aurora login: ' . $e->getMessage());
    auroraResponder(500, 'Error interno al iniciar sesión');
}
