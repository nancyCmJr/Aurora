<?php
require_once __DIR__ . '/session_config.php';
auroraIniciarSesion();
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    header('Allow: GET, OPTIONS');
    auroraResponder(405, 'Método no permitido');
}
require_once __DIR__ . '/../conn.php';
$usuario = auroraExigirSesion($conn);
auroraResponder(200, 'Sesión activa', ['data' => $usuario]);
