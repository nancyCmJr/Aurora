<?php
require_once __DIR__ . '/session_config.php';
auroraIniciarSesion();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST, OPTIONS');
    auroraResponder(405, 'Método no permitido');
}

$_SESSION = [];
if (ini_get('session.use_cookies')) {
    $parametros = session_get_cookie_params();
    setcookie(session_name(), '', [
        'expires' => time() - 3600,
        'path' => $parametros['path'],
        'domain' => $parametros['domain'],
        'secure' => $parametros['secure'],
        'httponly' => $parametros['httponly'],
        'samesite' => $parametros['samesite']
    ]);
}
session_destroy();
auroraResponder(200, 'Sesión cerrada correctamente');
