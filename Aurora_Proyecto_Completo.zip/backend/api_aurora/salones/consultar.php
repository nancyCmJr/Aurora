<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'salones', 'consultar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

$id_salon = filter_var(
    $_GET["id_salon"] ?? null,
    FILTER_VALIDATE_INT
);

if ($id_salon === false || $id_salon === null || $id_salon <= 0) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Se requiere un ID de salón válido"
    ]);
    exit();
}

try {

    $stmt = $conn->prepare("
        SELECT
            s.id_salon,
            s.nombre,
            s.tipo,
            s.capacidad,

            s.id_edificio,
            e.nombre AS nombre_edificio,
            e.estado AS estado_edificio,

            s.id_area,
            a.nombre AS nombre_area,
            a.estado AS estado_area,

            s.estado,

            COUNT(DISTINCT h.id_horario) AS total_horarios,
            COUNT(DISTINCT h.id_grupo) AS total_grupos,

            CASE
                WHEN a.id_edificio = s.id_edificio
                    THEN 1
                ELSE 0
            END AS ubicacion_consistente,

            CASE
                WHEN s.estado = 'Inactivo'
                    THEN 1
                WHEN e.estado = 'Activo'
                     AND a.estado = 'Activo'
                     AND a.id_edificio = s.id_edificio
                    THEN 1
                ELSE 0
            END AS estado_consistente

        FROM salones s

        INNER JOIN edificios e
            ON e.id_edificio = s.id_edificio

        INNER JOIN areas a
            ON a.id_area = s.id_area

        LEFT JOIN horarios h
            ON h.id_salon = s.id_salon

        WHERE s.id_salon = ?

        GROUP BY
            s.id_salon,
            s.nombre,
            s.tipo,
            s.capacidad,
            s.id_edificio,
            e.nombre,
            e.estado,
            s.id_area,
            a.nombre,
            a.estado,
            a.id_edificio,
            s.estado
    ");

    $stmt->bind_param("i", $id_salon);
    $stmt->execute();

    $salon = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$salon) {
        http_response_code(404);
        echo json_encode([
            "success" => false,
            "message" => "El salón no existe"
        ]);
        exit();
    }

    // Convertir los valores numéricos.
    $salon["id_salon"] = (int)$salon["id_salon"];
    $salon["capacidad"] = (int)$salon["capacidad"];
    $salon["id_edificio"] = (int)$salon["id_edificio"];
    $salon["id_area"] = (int)$salon["id_area"];

    $salon["total_horarios"] = (int)$salon["total_horarios"];
    $salon["total_grupos"] = (int)$salon["total_grupos"];

    $salon["ubicacion_consistente"] =
        (bool)$salon["ubicacion_consistente"];

    $salon["estado_consistente"] =
        (bool)$salon["estado_consistente"];

    echo json_encode([
        "success" => true,
        "salon" => $salon
    ]);

} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error al consultar el salón"
    ]);
}

$conn->close();
?>
