<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'salones', 'listar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

try {

    $sql = "
        SELECT
            s.id_salon,
            s.nombre,
            s.tipo,
            s.capacidad,

            s.id_edificio,
            e.nombre AS nombre_edificio,
            e.estado AS estado_edificio,

            s.id_area,
            a.nombre AS nombre_area,
            a.estado AS estado_area,

            s.estado,

            COUNT(DISTINCT h.id_horario) AS total_horarios,
            COUNT(DISTINCT h.id_grupo) AS total_grupos,

            CASE
                WHEN a.id_area IS NULL
                    THEN 0
                WHEN a.id_edificio = s.id_edificio
                    THEN 1
                ELSE 0
            END AS ubicacion_consistente,

            CASE
                WHEN s.estado = 'Inactivo'
                    THEN 1
                WHEN e.estado = 'Activo'
                     AND a.estado = 'Activo'
                     AND a.id_edificio = s.id_edificio
                    THEN 1
                ELSE 0
            END AS estado_consistente

        FROM salones s

        INNER JOIN edificios e
            ON e.id_edificio = s.id_edificio

        INNER JOIN areas a
            ON a.id_area = s.id_area

        LEFT JOIN horarios h
            ON h.id_salon = s.id_salon

        GROUP BY
            s.id_salon,
            s.nombre,
            s.tipo,
            s.capacidad,
            s.id_edificio,
            e.nombre,
            e.estado,
            s.id_area,
            a.nombre,
            a.estado,
            a.id_edificio,
            s.estado

        ORDER BY
            e.nombre ASC,
            a.nombre ASC,
            s.nombre ASC
    ";

    $resultado = $conn->query($sql);

    $salones = [];

    while ($fila = $resultado->fetch_assoc()) {

        $fila["id_salon"] = (int)$fila["id_salon"];
        $fila["capacidad"] = (int)$fila["capacidad"];
        $fila["id_edificio"] = (int)$fila["id_edificio"];
        $fila["id_area"] = (int)$fila["id_area"];
        $fila["total_horarios"] = (int)$fila["total_horarios"];
        $fila["total_grupos"] = (int)$fila["total_grupos"];

        $fila["ubicacion_consistente"] =
            (bool)$fila["ubicacion_consistente"];

        $fila["estado_consistente"] =
            (bool)$fila["estado_consistente"];

        $salones[] = $fila;
    }

    echo json_encode([
        "success" => true,
        "total" => count($salones),
        "salones" => $salones
    ]);

} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error al consultar los salones"
    ]);
}

$conn->close();
?>
