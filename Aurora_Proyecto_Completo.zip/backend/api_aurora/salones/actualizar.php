<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'salones', 'actualizar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($status, $mensaje, $datos = []) {
    http_response_code($status);

    echo json_encode(array_merge([
        "success" => $status >= 200 && $status < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

function validarId($valor) {
    if (is_int($valor)) {
        return $valor > 0 ? $valor : false;
    }

    if (
        is_string($valor) &&
        ctype_digit($valor) &&
        filter_var($valor, FILTER_VALIDATE_INT) !== false &&
        (int)$valor > 0
    ) {
        return (int)$valor;
    }

    return false;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "JSON inválido");
}

/*
 * 1. Validar datos.
 */
$id_salon = validarId($data["id_salon"] ?? null);
$id_edificio = validarId($data["id_edificio"] ?? null);
$id_area = validarId($data["id_area"] ?? null);
$capacidad = validarId($data["capacidad"] ?? null);

$nombre = isset($data["nombre"]) && is_string($data["nombre"])
    ? trim($data["nombre"])
    : "";

$tipo = $data["tipo"] ?? null;
$estado = $data["estado"] ?? null;

$tiposPermitidos = [
    "Aula",
    "Laboratorio",
    "Taller",
    "Auditorio"
];

$estadosPermitidos = [
    "Activo",
    "Inactivo"
];

$longitudNombre = function_exists("mb_strlen")
    ? mb_strlen($nombre, "UTF-8")
    : strlen($nombre);

if (
    !$id_salon ||
    !$id_edificio ||
    !$id_area ||
    !$capacidad ||
    $nombre === "" ||
    $longitudNombre > 50 ||
    !is_string($tipo) ||
    !in_array($tipo, $tiposPermitidos, true) ||
    !is_string($estado) ||
    !in_array($estado, $estadosPermitidos, true)
) {
    responder(400, "Verifica los datos enviados");
}

$stmt = null;

try {

    /*
     * 2. Obtener ubicación inicial.
     * Se volverá a comprobar dentro de la transacción.
     */
    $stmt = $conn->prepare("
        SELECT id_edificio, id_area
        FROM salones
        WHERE id_salon = ?
    ");

    $stmt->bind_param("i", $id_salon);
    $stmt->execute();

    $salonInicial = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$salonInicial) {
        throw new DomainException("El salón no existe", 404);
    }

    $edificioAnterior = (int)$salonInicial["id_edificio"];
    $areaAnterior = (int)$salonInicial["id_area"];

    $cambioUbicacion =
        $edificioAnterior !== $id_edificio ||
        $areaAnterior !== $id_area;

    /*
     * 3. Iniciar transacción.
     */
    $conn->begin_transaction();

    /*
     * 4. Bloquear edificios en orden ascendente.
     */
    $edificiosBloquear = array_unique([
        $edificioAnterior,
        $id_edificio
    ]);

    sort($edificiosBloquear, SORT_NUMERIC);

    foreach ($edificiosBloquear as $id) {

        $stmt = $conn->prepare("
            SELECT id_edificio, estado
            FROM edificios
            WHERE id_edificio = ?
            FOR UPDATE
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $resultado = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if (!$resultado) {
            throw new DomainException(
                "Uno de los edificios seleccionados no existe",
                409
            );
        }
    }

    /*
     * 5. Bloquear áreas en orden ascendente.
     */
    $areasBloquear = array_unique([
        $areaAnterior,
        $id_area
    ]);

    sort($areasBloquear, SORT_NUMERIC);

    foreach ($areasBloquear as $id) {

        $stmt = $conn->prepare("
            SELECT id_area, id_edificio, estado
            FROM areas
            WHERE id_area = ?
            FOR UPDATE
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $resultado = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if (!$resultado) {
            throw new DomainException(
                "Una de las áreas seleccionadas no existe",
                409
            );
        }
    }

    /*
     * 6. Bloquear el salón.
     */
    $stmt = $conn->prepare("
        SELECT id_salon, id_edificio, id_area, estado
        FROM salones
        WHERE id_salon = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_salon);
    $stmt->execute();

    $salonActual = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$salonActual) {
        throw new DomainException("El salón ya no existe", 404);
    }

    /*
     * Comprobar que la ubicación no cambió.
     */
    if (
        (int)$salonActual["id_edificio"] !== $edificioAnterior ||
        (int)$salonActual["id_area"] !== $areaAnterior
    ) {
        throw new DomainException(
            "La ubicación del salón cambió durante la operación. Consulta nuevamente sus datos.",
            409
        );
    }

    /*
     * 7. Validar que el área pertenezca al edificio.
     */
    $stmt = $conn->prepare("
        SELECT id_area, id_edificio, estado
        FROM areas
        WHERE id_area = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_area);
    $stmt->execute();

    $area = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$area || (int)$area["id_edificio"] !== $id_edificio) {
        throw new DomainException(
            "El área no pertenece al edificio seleccionado",
            400
        );
    }

    /*
     * 8. Validar estado del edificio y área
     * cuando el salón se registra como activo.
     */
    if ($estado === "Activo") {

        $stmt = $conn->prepare("
            SELECT estado
            FROM edificios
            WHERE id_edificio = ?
        ");

        $stmt->bind_param("i", $id_edificio);
        $stmt->execute();

        $edificio = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if (!$edificio || $edificio["estado"] !== "Activo") {
            throw new DomainException(
                "No se puede activar el salón porque el edificio está inactivo",
                409
            );
        }

        if ($area["estado"] !== "Activo") {
            throw new DomainException(
                "No se puede activar el salón porque el área está inactiva",
                409
            );
        }
    }

    /*
     * 9. Bloquear horarios asociados.
     *
     * Esto coordina la actualización del salón con las
     * operaciones de horarios que respetan el bloqueo
     * del salón antes de insertar o modificar asignaciones.
     */
    $stmt = $conn->prepare("
        SELECT id_horario
        FROM horarios
        WHERE id_salon = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_salon);
    $stmt->execute();

    $resultadoHorarios = $stmt->get_result();

    $totalHorarios = 0;
    $idsHorarios = [];

    while ($fila = $resultadoHorarios->fetch_assoc()) {
        $idsHorarios[] = (int)$fila["id_horario"];
        $totalHorarios++;
    }

    $stmt->close();
    $stmt = null;

    /*
     * 10. No permitir cambios de ubicación
     * cuando existen horarios.
     */
    if ($cambioUbicacion && $totalHorarios > 0) {
        throw new DomainException(
            "No se puede cambiar el edificio o área del salón porque tiene horarios registrados",
            409
        );
    }

    /*
     * 11. No permitir desactivar salones
     * que tengan horarios registrados.
     */
    if ($estado === "Inactivo" && $totalHorarios > 0) {
        throw new DomainException(
            "No se puede desactivar el salón porque tiene horarios registrados",
            409
        );
    }

    /*
     * 12. Validar capacidad contra todos los grupos
     * que utilizan el salón.
     */
    $stmt = $conn->prepare("
        SELECT MAX(g.capacidad) AS capacidad_maxima
        FROM horarios h
        INNER JOIN grupos g
            ON g.id_grupo = h.id_grupo
        WHERE h.id_salon = ?
    ");

    $stmt->bind_param("i", $id_salon);
    $stmt->execute();

    $resultadoCapacidad = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    $capacidadMaxima = $resultadoCapacidad["capacidad_maxima"];

    if (
        $capacidadMaxima !== null &&
        $capacidad < (int)$capacidadMaxima
    ) {
        throw new DomainException(
            "La capacidad del salón no puede ser menor que la capacidad de los grupos que lo utilizan",
            409
        );
    }

    /*
     * 13. Actualizar salón.
     */
    $stmt = $conn->prepare("
        UPDATE salones
        SET
            nombre = ?,
            tipo = ?,
            capacidad = ?,
            id_edificio = ?,
            id_area = ?,
            estado = ?
        WHERE id_salon = ?
    ");

    $stmt->bind_param(
        "ssiiisi",
        $nombre,
        $tipo,
        $capacidad,
        $id_edificio,
        $id_area,
        $estado,
        $id_salon
    );

    $stmt->execute();

    $stmt->close();
    $stmt = null;

    /*
     * 14. Confirmar transacción.
     */
    $conn->commit();

    responder(200, "Salón actualizado correctamente", [
        "id_salon" => $id_salon
    ]);

} catch (DomainException $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    $codigo = $e->getCode();

    if ($codigo < 400 || $codigo > 599) {
        $codigo = 400;
    }

    responder($codigo, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error SQL al actualizar salón: " . $e->getMessage()
    );

    if ($e->getCode() == 1452) {
        responder(400, "El edificio o área seleccionados no son válidos");
    }

    if ($e->getCode() == 3819) {
        responder(400, "Los datos no cumplen las restricciones de la base de datos");
    }

    if ($e->getCode() == 1213 || $e->getCode() == 1205) {
        responder(
            409,
            "La operación tuvo un conflicto con otra actualización. Intenta nuevamente."
        );
    }

    responder(500, "Error de base de datos al actualizar el salón");

} catch (Throwable $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error al actualizar salón: " . $e->getMessage()
    );

    responder(500, "Error interno al actualizar el salón");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}
?>
