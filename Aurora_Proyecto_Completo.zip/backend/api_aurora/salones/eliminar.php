<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'salones', 'eliminar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($status, $mensaje, $datos = []) {
    http_response_code($status);

    echo json_encode(array_merge([
        "success" => $status >= 200 && $status < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

function validarId($valor) {
    if (is_int($valor)) {
        return $valor > 0 ? $valor : false;
    }

    if (
        is_string($valor) &&
        ctype_digit($valor) &&
        filter_var($valor, FILTER_VALIDATE_INT) !== false &&
        (int)$valor > 0
    ) {
        return (int)$valor;
    }

    return false;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "JSON inválido");
}

$id_salon = validarId($data["id_salon"] ?? null);

if (!$id_salon) {
    responder(400, "Se requiere un ID de salón válido");
}

$stmt = null;

try {

    $conn->begin_transaction();

    /*
     * 1. Consultar ubicación del salón.
     */
    $stmt = $conn->prepare("
        SELECT id_edificio, id_area
        FROM salones
        WHERE id_salon = ?
    ");

    $stmt->bind_param("i", $id_salon);
    $stmt->execute();

    $ubicacion = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$ubicacion) {
        throw new DomainException("El salón no existe", 404);
    }

    $id_edificio = (int)$ubicacion["id_edificio"];
    $id_area = (int)$ubicacion["id_area"];

    /*
     * 2. Bloquear edificio.
     */
    $stmt = $conn->prepare("
        SELECT id_edificio
        FROM edificios
        WHERE id_edificio = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_edificio);
    $stmt->execute();

    $edificio = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$edificio) {
        throw new DomainException(
            "El edificio asociado al salón no existe",
            409
        );
    }

    /*
     * 3. Bloquear área.
     */
    $stmt = $conn->prepare("
        SELECT id_area, id_edificio
        FROM areas
        WHERE id_area = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_area);
    $stmt->execute();

    $area = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$area || (int)$area["id_edificio"] !== $id_edificio) {
        throw new DomainException(
            "La ubicación del salón no es consistente",
            409
        );
    }

    /*
     * 4. Bloquear salón.
     */
    $stmt = $conn->prepare("
        SELECT id_salon, id_edificio, id_area, estado
        FROM salones
        WHERE id_salon = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_salon);
    $stmt->execute();

    $salon = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$salon) {
        throw new DomainException("El salón ya no existe", 404);
    }

    if (
        (int)$salon["id_edificio"] !== $id_edificio ||
        (int)$salon["id_area"] !== $id_area
    ) {
        throw new DomainException(
            "La ubicación del salón cambió durante la operación. Consulta nuevamente sus datos.",
            409
        );
    }

    if ($salon["estado"] === "Inactivo") {
        throw new DomainException(
            "El salón ya se encuentra inactivo",
            409
        );
    }

    /*
     * 5. Bloquear y comprobar horarios asociados.
     */
    $stmt = $conn->prepare("
        SELECT id_horario
        FROM horarios
        WHERE id_salon = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_salon);
    $stmt->execute();

    $horarios = $stmt->get_result();

    $totalHorarios = 0;

    while ($horarios->fetch_assoc()) {
        $totalHorarios++;
    }

    $stmt->close();
    $stmt = null;

    if ($totalHorarios > 0) {
        throw new DomainException(
            "No se puede desactivar el salón porque tiene horarios registrados. Primero debes gestionar los horarios asociados.",
            409
        );
    }

    /*
     * 6. Realizar baja lógica.
     */
    $stmt = $conn->prepare("
        UPDATE salones
        SET estado = 'Inactivo'
        WHERE id_salon = ?
    ");

    $stmt->bind_param("i", $id_salon);
    $stmt->execute();

    $stmt->close();
    $stmt = null;

    /*
     * 7. Confirmar transacción.
     */
    $conn->commit();

    responder(200, "Salón desactivado correctamente", [
        "id_salon" => $id_salon
    ]);

} catch (DomainException $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    $codigo = $e->getCode();

    if ($codigo < 400 || $codigo > 599) {
        $codigo = 400;
    }

    responder($codigo, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error SQL al desactivar salón: " . $e->getMessage()
    );

    if ($e->getCode() == 1213 || $e->getCode() == 1205) {
        responder(
            409,
            "La operación tuvo un conflicto con otra actualización. Intenta nuevamente."
        );
    }

    responder(500, "Error de base de datos al desactivar el salón");

} catch (Throwable $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error al desactivar salón: " . $e->getMessage()
    );

    responder(500, "Error interno al desactivar el salón");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}
?>
