<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'salones', 'registar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "Los datos enviados no contienen un JSON válido");
}

// ==========================================
// 3. VALIDAR CAMPOS
// ==========================================

if (
    !isset($data["nombre"]) ||
    !isset($data["capacidad"]) ||
    !isset($data["id_edificio"]) ||
    !isset($data["id_area"])
) {
    responder(
        400,
        "El nombre, capacidad, edificio y área son obligatorios"
    );
}

if (!is_string($data["nombre"])) {
    responder(400, "El nombre del salón debe ser texto");
}

$nombre = trim($data["nombre"]);

if ($nombre === "") {
    responder(400, "El nombre del salón es obligatorio");
}

if (mb_strlen($nombre, "UTF-8") > 50) {
    responder(400, "El nombre no puede superar los 50 caracteres");
}

// ==========================================
// 4. VALIDAR ENTEROS
// ==========================================

function enteroValido($valor)
{
    if (is_int($valor)) {
        return true;
    }

    return is_string($valor) && ctype_digit($valor);
}

if (
    !enteroValido($data["capacidad"]) ||
    !enteroValido($data["id_edificio"]) ||
    !enteroValido($data["id_area"])
) {
    responder(400, "La capacidad y los identificadores deben ser enteros válidos");
}

$capacidad = (int)$data["capacidad"];
$id_edificio = (int)$data["id_edificio"];
$id_area = (int)$data["id_area"];

if ($capacidad <= 0) {
    responder(400, "La capacidad debe ser mayor a cero");
}

if ($id_edificio <= 0 || $id_area <= 0) {
    responder(400, "El edificio y el área deben tener identificadores válidos");
}

// ==========================================
// 5. VALIDAR ENUMS
// ==========================================

$tipo = $data["tipo"] ?? "Aula";
$estado = $data["estado"] ?? "Activo";

$tiposPermitidos = [
    "Aula",
    "Laboratorio",
    "Taller",
    "Auditorio"
];

$estadosPermitidos = [
    "Activo",
    "Inactivo"
];

if (
    !is_string($tipo) ||
    !in_array($tipo, $tiposPermitidos, true)
) {
    responder(400, "El tipo de salón no es válido");
}

if (
    !is_string($estado) ||
    !in_array($estado, $estadosPermitidos, true)
) {
    responder(400, "El estado del salón no es válido");
}

// ==========================================
// 6. INICIAR TRANSACCIÓN
// ==========================================

try {

    $conn->begin_transaction();

    // ======================================
    // 7. BLOQUEAR Y VERIFICAR EDIFICIO
    // ======================================

    $sqlEdificio = "
        SELECT id_edificio, estado
        FROM edificios
        WHERE id_edificio = ?
        FOR UPDATE
    ";

    $stmtEdificio = $conn->prepare($sqlEdificio);
    $stmtEdificio->bind_param("i", $id_edificio);
    $stmtEdificio->execute();

    $edificio = $stmtEdificio->get_result()->fetch_assoc();
    $stmtEdificio->close();

    if (!$edificio) {
        throw new DomainException(
            "El edificio seleccionado no existe",
            404
        );
    }

    // ======================================
    // 8. BLOQUEAR Y VERIFICAR ÁREA
    // ======================================

    $sqlArea = "
        SELECT id_area, id_edificio, estado
        FROM areas
        WHERE id_area = ?
        FOR UPDATE
    ";

    $stmtArea = $conn->prepare($sqlArea);
    $stmtArea->bind_param("i", $id_area);
    $stmtArea->execute();

    $area = $stmtArea->get_result()->fetch_assoc();
    $stmtArea->close();

    if (!$area) {
        throw new DomainException(
            "El área seleccionada no existe",
            404
        );
    }

    // ======================================
    // 9. COMPROBAR RELACIÓN ÁREA-EDIFICIO
    // ======================================

    if ((int)$area["id_edificio"] !== $id_edificio) {
        throw new DomainException(
            "El área seleccionada no pertenece al edificio indicado"
        );
    }

    // ======================================
    // 10. VALIDAR ESTADOS
    // ======================================

    if ($estado === "Activo") {

        if ($edificio["estado"] !== "Activo") {
            throw new DomainException(
                "No se puede registrar un salón activo en un edificio inactivo"
            );
        }

        if ($area["estado"] !== "Activo") {
            throw new DomainException(
                "No se puede registrar un salón activo en un área inactiva"
            );
        }
    }

    // ======================================
    // 11. REGISTRAR SALÓN
    // ======================================

    $sql = "
        INSERT INTO salones (
            nombre,
            tipo,
            capacidad,
            id_edificio,
            id_area,
            estado
        )
        VALUES (?, ?, ?, ?, ?, ?)
    ";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "ssiiis",
        $nombre,
        $tipo,
        $capacidad,
        $id_edificio,
        $id_area,
        $estado
    );

    $stmt->execute();

    $id_salon = $conn->insert_id;

    $stmt->close();

    // ======================================
    // 12. CONFIRMAR TRANSACCIÓN
    // ======================================

    $conn->commit();

    responder(201, "Salón registrado correctamente", [
        "id_salon" => $id_salon
    ]);

} catch (DomainException $e) {

    $conn->rollback();

    $codigo = $e->getCode();

    if (!in_array($codigo, [400, 404, 409], true)) {
        $codigo = 400;
    }

    responder($codigo, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    $conn->rollback();

    error_log(
        "Error SQL en salones/registrar.php: " .
        $e->getMessage()
    );

    if ($e->getCode() == 1452) {
        responder(400, "El edificio o el área seleccionados no son válidos");
    }

    if ($e->getCode() == 3819) {
        responder(400, "Los datos del salón no cumplen las restricciones de la base de datos");
    }

    responder(500, "Error de base de datos al registrar el salón");

} catch (Throwable $e) {

    $conn->rollback();

    error_log(
        "Error en salones/registrar.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al registrar el salón");

} finally {

    $conn->close();
}

?>
