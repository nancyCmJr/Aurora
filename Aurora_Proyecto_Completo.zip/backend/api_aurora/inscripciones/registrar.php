<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'inscripciones', 'registrar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

function responder($codigo, $datos) {
    http_response_code($codigo);
    echo json_encode($datos, JSON_UNESCAPED_UNICODE);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, [
        "success" => false,
        "message" => "Método no permitido"
    ]);
}

require_once __DIR__ . "/../conn.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, [
        "success" => false,
        "message" => "JSON inválido"
    ]);
}

// Validar número de control.
if (
    !isset($data["numero_control"]) ||
    !is_string($data["numero_control"])
) {
    responder(400, [
        "success" => false,
        "message" => "El número de control debe ser texto"
    ]);
}

$numero_control = trim($data["numero_control"]);

if ($numero_control === "" || strlen($numero_control) > 20) {
    responder(400, [
        "success" => false,
        "message" => "El número de control es obligatorio y no debe superar 20 caracteres"
    ]);
}

// Validar ID de carrera.
$id_carrera = filter_var(
    $data["id_carrera"] ?? null,
    FILTER_VALIDATE_INT
);

if ($id_carrera === false || $id_carrera === null || $id_carrera <= 0) {
    responder(400, [
        "success" => false,
        "message" => "Se requiere un ID de carrera válido"
    ]);
}

// El ciclo es obligatorio. Los grupos y el kardex utilizan estos valores.
$periodo = (isset($data['periodo']) && is_string($data['periodo']))
    ? trim($data['periodo']) : '';
$anioRaw = $data['anio'] ?? null;
$anio = filter_var($anioRaw, FILTER_VALIDATE_INT);
if ($periodo === '' || mb_strlen($periodo, 'UTF-8') > 20 ||
    $anio === false || $anio < 1901 || $anio > 2155) {
    responder(400, [
        'success' => false,
        'message' => 'Periodo (máximo 20 caracteres) y año (1901–2155) válidos son obligatorios'
    ]);
}

// Validar fecha opcional.
$fecha_inscripcion = $data["fecha_inscripcion"] ?? null;

if ($fecha_inscripcion !== null && $fecha_inscripcion !== "") {

    if (!is_string($fecha_inscripcion)) {
        responder(400, [
            "success" => false,
            "message" => "La fecha debe enviarse como texto"
        ]);
    }

    $fecha = DateTime::createFromFormat("!Y-m-d", $fecha_inscripcion);
    $erroresFecha = DateTime::getLastErrors();

    if (
        !$fecha ||
        ($erroresFecha !== false &&
            ($erroresFecha["warning_count"] > 0 ||
             $erroresFecha["error_count"] > 0)) ||
        $fecha->format("Y-m-d") !== $fecha_inscripcion
    ) {
        responder(400, [
            "success" => false,
            "message" => "La fecha debe tener el formato YYYY-MM-DD y ser válida"
        ]);
    }

} else {
    $fecha_inscripcion = null;
}

$transaccionIniciada = false;

try {
    $conn->begin_transaction();
    $transaccionIniciada = true;

    // 1. Verificar que el alumno exista y esté activo.
    // El bloqueo evita que su estado cambie durante el registro.
    $stmt = $conn->prepare("
        SELECT numero_control
        FROM alumnos
        WHERE numero_control = ?
          AND estado = 'Activo'
        FOR UPDATE
    ");

    $stmt->bind_param("s", $numero_control);
    $stmt->execute();

    $alumno = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$alumno) {
        throw new DomainException(
            "El alumno no existe o no se encuentra activo"
        );
    }

    // 2. Verificar que la carrera exista y esté activa.
    // También se bloquea para evitar cambios simultáneos de estado.
    $stmt = $conn->prepare("
        SELECT id_carrera
        FROM carreras
        WHERE id_carrera = ?
          AND estado = 'Activa'
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_carrera);
    $stmt->execute();

    $carrera = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$carrera) {
        throw new DomainException(
            "La carrera no existe o no se encuentra activa"
        );
    }

    // 3. El mismo alumno puede tener historial en distintos ciclos.
    // Se impide duplicar el MISMO ciclo o abrir una segunda inscripción
    // cuando otra sigue en curso (también protegido con UNIQUE en MySQL).
    $stmt = $conn->prepare("
        SELECT id_inscripciones, estado, periodo, anio
        FROM inscripciones
        WHERE numero_control = ?
          AND ((periodo = ? AND anio = ?) OR estado = 'En curso')
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->bind_param("ssi", $numero_control, $periodo, $anio);
    $stmt->execute();

    $inscripcionExistente = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($inscripcionExistente) {
        throw new DomainException(
            "El alumno ya tiene una inscripción para el mismo ciclo o mantiene otra En curso (" .
            $inscripcionExistente["periodo"] . " " . $inscripcionExistente["anio"] . "). " .
            "Finaliza o cancela la inscripción activa antes de crear una nueva."
        );
    }

    // 4. Registrar la inscripción.
    if ($fecha_inscripcion !== null) {

        $stmt = $conn->prepare("
            INSERT INTO inscripciones (
                numero_control,
                id_carrera,
                periodo,
                anio,
                fecha_inscripcion
            )
            VALUES (?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "sisis",
            $numero_control,
            $id_carrera,
            $periodo,
            $anio,
            $fecha_inscripcion
        );

    } else {

        $stmt = $conn->prepare("
            INSERT INTO inscripciones (
                numero_control,
                id_carrera,
                periodo,
                anio
            )
            VALUES (?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "sisi",
            $numero_control,
            $id_carrera,
            $periodo,
            $anio
        );
    }

    $stmt->execute();
    $id_inscripcion = $conn->insert_id;
    $stmt->close();

    $conn->commit();
    $transaccionIniciada = false;

    responder(201, [
        "success" => true,
        "message" => "Inscripción registrada correctamente",
        "id_inscripciones" => $id_inscripcion,
        "numero_control" => $numero_control,
        "id_carrera" => $id_carrera,
        "periodo" => $periodo,
        "anio" => $anio,
        "fecha_inscripcion" => $fecha_inscripcion
    ]);

} catch (DomainException $e) {

    if ($transaccionIniciada) {
        $conn->rollback();
    }

    responder(400, [
        "success" => false,
        "message" => $e->getMessage()
    ]);

} catch (mysqli_sql_exception $e) {

    if ($transaccionIniciada) {
        $conn->rollback();
    }

    // 1062: duplicidad de un índice UNIQUE.
    if ($e->getCode() === 1062) {
        responder(409, [
            "success" => false,
            "message" => "Ya existe una inscripción para ese ciclo o una inscripción En curso"
        ]);
    }

    // 1452: incumplimiento de una llave foránea.
    if ($e->getCode() === 1452) {
        responder(400, [
            "success" => false,
            "message" => "El alumno o la carrera relacionados no existen"
        ]);
    }

    error_log("Error SQL en inscripciones/registrar.php: " . $e->getMessage());

    responder(500, [
        "success" => false,
        "message" => "Error de base de datos al registrar la inscripción"
    ]);

} catch (Throwable $e) {

    if ($transaccionIniciada) {
        $conn->rollback();
    }

    error_log("Error en inscripciones/registrar.php: " . $e->getMessage());

    responder(500, [
        "success" => false,
        "message" => "Error interno al registrar la inscripción"
    ]);
}

$conn->close();
?>
