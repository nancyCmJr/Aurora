<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'inscripciones', 'actualizar');

// La identidad histórica de una inscripción es inmutable. Solo cambia su estado.
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
function responder($codigo, $mensaje, $extra = []) {
    http_response_code($codigo);
    echo json_encode(array_merge(['success' => $codigo >= 200 && $codigo < 300, 'message' => $mensaje], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') responder(405, 'Método no permitido');
$data = json_decode(file_get_contents('php://input'), true);
if (!is_array($data)) responder(400, 'JSON inválido');
$id = filter_var($data['id_inscripciones'] ?? null, FILTER_VALIDATE_INT);
if (!$id || $id <= 0) responder(400, 'ID de inscripción inválido');
$estado = $data['estado'] ?? null;
if (!is_string($estado) || !in_array($estado, ['En curso', 'Finalizada', 'Cancelada'], true)) responder(400, 'Estado inválido');
require_once __DIR__ . '/../conn.php';
$enTransaccion = false;
try {
    // Obtener el alumno antes de abrir transacción para bloquear primero su fila.
    $stmt = $conn->prepare('SELECT numero_control FROM inscripciones WHERE id_inscripciones = ?');
    $stmt->bind_param('i', $id); $stmt->execute();
    $preliminar = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$preliminar) throw new DomainException('Inscripción no encontrada', 404);

    $conn->begin_transaction(); $enTransaccion = true;
    $stmt = $conn->prepare('SELECT numero_control, estado FROM alumnos WHERE numero_control = ? FOR UPDATE');
    $stmt->bind_param('s', $preliminar['numero_control']); $stmt->execute();
    $alumno = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$alumno) throw new DomainException('Alumno no encontrado', 404);
    $stmt = $conn->prepare('SELECT id_inscripciones, numero_control, id_carrera, fecha_inscripcion, periodo, anio, estado FROM inscripciones WHERE id_inscripciones = ? FOR UPDATE');
    $stmt->bind_param('i', $id); $stmt->execute();
    $actual = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$actual || $actual['numero_control'] !== $preliminar['numero_control']) throw new DomainException('La inscripción fue modificada por otra operación', 409);

    // Admite formularios antiguos que envían campos adicionales, pero no permite cambiarlos.
    foreach (['numero_control', 'id_carrera', 'fecha_inscripcion', 'periodo', 'anio'] as $campo) {
        if (array_key_exists($campo, $data) && (string)$data[$campo] !== (string)$actual[$campo]) {
            throw new DomainException("No se puede cambiar $campo de una inscripción histórica. Registra otra en el nuevo ciclo", 409);
        }
    }
    $transiciones = ['En curso' => ['En curso','Finalizada','Cancelada'], 'Finalizada' => ['Finalizada'], 'Cancelada' => ['Cancelada']];
    if (!in_array($estado, $transiciones[$actual['estado']], true)) throw new DomainException('Una inscripción finalizada o cancelada no puede reactivarse ni alterarse', 409);

    if ($estado !== 'En curso' && $estado !== $actual['estado']) {
        $stmt = $conn->prepare("SELECT
            SUM(CASE WHEN k.estado = 'Cursando' THEN 1 ELSE 0 END) AS cursando,
            SUM(CASE WHEN k.estado <> 'Baja' THEN 1 ELSE 0 END) AS historico
            FROM kardex k WHERE k.numero_control = ? AND k.periodo = ? AND k.anio = ?");
        $stmt->bind_param('ssi', $actual['numero_control'], $actual['periodo'], $actual['anio']);
        $stmt->execute(); $conteos = $stmt->get_result()->fetch_assoc(); $stmt->close();
        if ((int)$conteos['cursando'] > 0) throw new DomainException('Hay materias Cursando en este ciclo. Primero registra sus calificaciones o bajas', 409);
        if ($estado === 'Cancelada' && (int)$conteos['historico'] > 0) throw new DomainException('No se puede cancelar una inscripción con materias aprobadas o reprobadas; debe finalizarse', 409);
    }
    if ($estado !== $actual['estado']) {
        $stmt = $conn->prepare('UPDATE inscripciones SET estado = ? WHERE id_inscripciones = ?');
        $stmt->bind_param('si', $estado, $id); $stmt->execute(); $stmt->close();
    }
    $conn->commit(); $enTransaccion = false;
    responder(200, 'Inscripción actualizada sin modificar su historial', [
        'id_inscripciones' => (int)$id, 'numero_control' => $actual['numero_control'],
        'id_carrera' => (int)$actual['id_carrera'], 'fecha_inscripcion' => $actual['fecha_inscripcion'],
        'periodo' => $actual['periodo'], 'anio' => (int)$actual['anio'], 'estado' => $estado
    ]);
} catch (DomainException $e) {
    if ($enTransaccion) $conn->rollback();
    responder(in_array((int)$e->getCode(), [404,409], true) ? (int)$e->getCode() : 400, $e->getMessage());
} catch (mysqli_sql_exception $e) {
    if ($enTransaccion) $conn->rollback();
    error_log('inscripciones/actualizar: ' . $e->getMessage());
    if ((int)$e->getCode() === 1062) responder(409, 'Ya existe otra inscripción En curso para este alumno');
    if (in_array((int)$e->getCode(), [1644,1205,1213], true)) responder(409, 'Conflicto con una restricción de integridad o una operación concurrente');
    responder(500, 'Error de base de datos al actualizar la inscripción');
} catch (Throwable $e) {
    if ($enTransaccion) $conn->rollback();
    error_log('inscripciones/actualizar inesperado: ' . $e->getMessage());
    responder(500, 'Error inesperado al actualizar la inscripción');
} finally {
    $conn->close();
}
