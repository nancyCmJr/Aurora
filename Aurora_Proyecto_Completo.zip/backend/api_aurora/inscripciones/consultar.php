<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'inscripciones', 'consultar');

// Por ID: una inscripción. Por número de control: historial completo del alumno.
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
function responder($codigo, $mensaje, $extra = []) {
    http_response_code($codigo);
    echo json_encode(array_merge(['success' => $codigo >= 200 && $codigo < 300, 'message' => $mensaje], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'GET') responder(405, 'Método no permitido');
$tieneId = isset($_GET['id_inscripciones']);
$tieneNumero = isset($_GET['numero_control']);
if ($tieneId === $tieneNumero) responder(400, 'Indica solo id_inscripciones o numero_control');
$condiciones = [];
$tipos = '';
$parametros = [];
if ($tieneId) {
    $id = filter_var($_GET['id_inscripciones'], FILTER_VALIDATE_INT);
    if (!$id || $id <= 0) responder(400, 'ID de inscripción inválido');
    if (isset($_GET['periodo']) || isset($_GET['anio'])) responder(400, 'Los filtros de ciclo se utilizan con numero_control');
    $condiciones[] = 'i.id_inscripciones = ?'; $tipos .= 'i'; $parametros[] = $id;
} else {
    $numero = $_GET['numero_control'];
    if (!is_string($numero) || ($numero = trim($numero)) === '' || mb_strlen($numero, 'UTF-8') > 20) responder(400, 'Número de control inválido');
    $condiciones[] = 'i.numero_control = ?'; $tipos .= 's'; $parametros[] = $numero;
    if (isset($_GET['periodo'])) {
        $periodo = $_GET['periodo'];
        if (!is_string($periodo) || ($periodo = trim($periodo)) === '' || mb_strlen($periodo, 'UTF-8') > 20) responder(400, 'Periodo inválido');
        $condiciones[] = 'i.periodo = ?'; $tipos .= 's'; $parametros[] = $periodo;
    }
    if (isset($_GET['anio'])) {
        $anio = filter_var($_GET['anio'], FILTER_VALIDATE_INT);
        if ($anio === false || $anio < 1901 || $anio > 2155) responder(400, 'Año inválido');
        $condiciones[] = 'i.anio = ?'; $tipos .= 'i'; $parametros[] = $anio;
    }
}
require_once __DIR__ . '/../conn.php';
try {
    $sql = "SELECT i.id_inscripciones, i.numero_control, i.id_carrera, i.fecha_inscripcion,
            i.periodo, i.anio, i.estado AS estado_inscripcion,
            a.nombre, a.seg_nombre, a.apellidos,
            CONCAT_WS(' ', a.nombre, NULLIF(a.seg_nombre, ''), a.apellidos) AS nombre_completo,
            a.semestre, a.estado AS estado_alumno,
            c.nombre AS carrera, c.tipo AS tipo_carrera, c.total_creditos, c.estado AS estado_carrera
            FROM inscripciones i JOIN alumnos a ON a.numero_control = i.numero_control
            JOIN carreras c ON c.id_carrera = i.id_carrera
            WHERE " . implode(' AND ', $condiciones) . ' ORDER BY i.anio DESC, i.fecha_inscripcion DESC, i.id_inscripciones DESC';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($tipos, ...$parametros); $stmt->execute();
    $resultado = $stmt->get_result();
    $historial = [];
    while ($fila = $resultado->fetch_assoc()) {
        foreach (['id_inscripciones','id_carrera','anio','semestre','total_creditos'] as $campo) $fila[$campo] = (int)$fila[$campo];
        $historial[] = $fila;
    }
    $stmt->close();
    if (!$historial) responder(404, 'No se encontraron inscripciones con ese criterio');
    // Compatibilidad: "inscripcion" conserva la primera/más reciente;
    // "inscripciones" contiene el historial completo, sin perder filas.
    responder(200, 'Inscripciones consultadas correctamente', [
        'inscripcion' => $historial[0], 'total' => count($historial), 'inscripciones' => $historial
    ]);
} catch (Throwable $e) {
    error_log('inscripciones/consultar: ' . $e->getMessage());
    responder(500, 'Error al consultar las inscripciones');
} finally {
    $conn->close();
}
