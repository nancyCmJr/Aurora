<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'materias', 'eliminar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = []) {

    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. RECIBIR Y VALIDAR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "JSON inválido");
}

$id = filter_var(
    $data["id_materia"] ?? null,
    FILTER_VALIDATE_INT
);

if ($id === false || $id === null || $id <= 0) {
    responder(400, "ID de materia inválido");
}

// ==========================================
// 3. INICIAR TRANSACCIÓN
// ==========================================

$stmt = null;
$transaccion = false;

try {

    $conn->begin_transaction();
    $transaccion = true;

    // ======================================
    // 4. CONSULTAR Y BLOQUEAR MATERIA
    // ======================================

    $stmt = $conn->prepare("
        SELECT id_materia, clave_materia, nombre, estado
        FROM materias
        WHERE id_materia = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $materia = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$materia) {
        throw new DomainException("Materia no encontrada");
    }

    // ======================================
    // 5. COMPROBAR SI YA ESTÁ INACTIVA
    // ======================================

    if ($materia["estado"] === "Inactiva") {

        $conn->commit();
        $transaccion = false;

        responder(200, "La materia ya se encuentra inactiva", [
            "id_materia" => (int)$id,
            "estado" => "Inactiva"
        ]);
    }

    // ======================================
    // 6. VERIFICAR RETÍCULAS VIGENTES
    // ======================================

    $stmt = $conn->prepare("
        SELECT r.id_reticula
        FROM reticula_materia rm
        INNER JOIN reticulas r
            ON rm.id_reticula = r.id_reticula
        WHERE rm.id_materia = ?
          AND r.estado = 'Vigente'
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $reticula = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if ($reticula) {
        throw new DomainException(
            "No se puede desactivar: la materia pertenece a una retícula vigente"
        );
    }

    // ======================================
    // 7. VERIFICAR GRUPOS PLANEADOS O ABIERTOS
    // ======================================

    $stmt = $conn->prepare("
        SELECT id_grupo
        FROM grupos
        WHERE id_materia = ?
          AND estado IN ('Planeado', 'Abierto')
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $grupo = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if ($grupo) {
        throw new DomainException(
            "No se puede desactivar: la materia tiene grupos planeados o abiertos"
        );
    }

    // ======================================
    // 8. VERIFICAR MATERIAS DEPENDIENTES
    // ======================================

    $stmt = $conn->prepare("
        SELECT id_materia
        FROM materias
        WHERE id_materia_requisito = ?
          AND estado = 'Activa'
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $dependiente = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if ($dependiente) {
        throw new DomainException(
            "No se puede desactivar: otras materias activas la utilizan como requisito"
        );
    }

    // ======================================
    // 9. REALIZAR BAJA LÓGICA
    // ======================================

    $stmt = $conn->prepare("
        UPDATE materias
        SET estado = 'Inactiva'
        WHERE id_materia = ?
          AND estado = 'Activa'
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $filasAfectadas = $stmt->affected_rows;

    $stmt->close();
    $stmt = null;

    if ($filasAfectadas !== 1) {
        throw new Exception(
            "No fue posible desactivar la materia"
        );
    }

    // ======================================
    // 10. CONFIRMAR TRANSACCIÓN
    // ======================================

    $conn->commit();
    $transaccion = false;

    responder(200, "Materia desactivada correctamente", [
        "id_materia" => (int)$id,
        "clave_materia" => $materia["clave_materia"],
        "nombre" => $materia["nombre"],
        "estado_anterior" => "Activa",
        "estado_actual" => "Inactiva"
    ]);

} catch (DomainException $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    responder(409, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log("Error SQL en materias/eliminar.php: " . $e->getMessage());

    responder(500, "Error de base de datos al desactivar la materia");

} catch (Throwable $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log("Error interno en materias/eliminar.php: " . $e->getMessage());

    responder(500, "Error interno al desactivar la materia");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
