<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'materias', 'registar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";
require_once __DIR__ . "/validar_requisito.php";

function responder($codigo, $mensaje, $datos = []) {

    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. RECIBIR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "JSON inválido");
}

// ==========================================
// 3. VALIDAR CAMPOS OBLIGATORIOS
// ==========================================

if (
    !isset($data["clave_materia"]) ||
    !isset($data["nombre"]) ||
    !array_key_exists("creditos", $data)
) {
    responder(400, "Faltan datos obligatorios");
}

if (
    !is_string($data["clave_materia"]) ||
    !is_string($data["nombre"])
) {
    responder(400, "La clave y el nombre deben ser textos");
}

// ==========================================
// 4. OBTENER Y NORMALIZAR DATOS
// ==========================================

$clave = trim($data["clave_materia"]);
$nombre = trim($data["nombre"]);

$creditos = filter_var(
    $data["creditos"],
    FILTER_VALIDATE_INT
);

$horas_teoricas = filter_var(
    $data["horas_teoricas"] ?? 0,
    FILTER_VALIDATE_INT
);

$horas_practicas = filter_var(
    $data["horas_practicas"] ?? 0,
    FILTER_VALIDATE_INT
);

$id_requisito = null;

if (
    array_key_exists("id_materia_requisito", $data) &&
    $data["id_materia_requisito"] !== null &&
    $data["id_materia_requisito"] !== ""
) {
    $id_requisito = filter_var(
        $data["id_materia_requisito"],
        FILTER_VALIDATE_INT
    );
}

$estado = $data["estado"] ?? "Activa";

// ==========================================
// 5. VALIDAR REGLAS DE LA TABLA
// ==========================================

if (
    $clave === "" ||
    mb_strlen($clave) > 15 ||
    $nombre === "" ||
    mb_strlen($nombre) > 150 ||
    $creditos === false ||
    $creditos < 3 ||
    $creditos > 6 ||
    $horas_teoricas === false ||
    $horas_teoricas < 0 ||
    $horas_practicas === false ||
    $horas_practicas < 0 ||
    !is_string($estado) ||
    !in_array($estado, ["Activa", "Inactiva"], true) ||
    ($id_requisito !== null &&
        ($id_requisito === false || $id_requisito <= 0))
) {
    responder(400, "Verifica los datos de la materia");
}

// ==========================================
// 6. REGISTRAR MATERIA
// ==========================================

$stmt = null;
$transaccion = false;

try {

    $conn->begin_transaction();
    $transaccion = true;

    // --------------------------------------
    // VALIDAR MATERIA REQUISITO
    // --------------------------------------

    if ($id_requisito !== null) {

        $stmt = $conn->prepare("
            SELECT id_materia, estado
            FROM materias
            WHERE id_materia = ?
            FOR UPDATE
        ");

        $stmt->bind_param("i", $id_requisito);
        $stmt->execute();

        $requisito = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if (!$requisito) {
            throw new DomainException(
                "La materia requisito no existe"
            );
        }

        if ($requisito["estado"] !== "Activa") {
            throw new DomainException(
                "La materia requisito debe estar activa"
            );
        }

        // Verificar que no exista un ciclo de requisitos.

        $validacion = validarCadenaRequisitos(
            $conn,
            null,
            $id_requisito
        );

        if (
            !isset($validacion["valido"]) ||
            !$validacion["valido"]
        ) {
            throw new DomainException(
                $validacion["mensaje"] ??
                "La cadena de requisitos no es válida"
            );
        }
    }

    // --------------------------------------
    // INSERTAR MATERIA
    // --------------------------------------

    $stmt = $conn->prepare("
        INSERT INTO materias (
            clave_materia,
            nombre,
            creditos,
            horas_teoricas,
            horas_practicas,
            id_materia_requisito,
            estado
        ) VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "ssiiiis",
        $clave,
        $nombre,
        $creditos,
        $horas_teoricas,
        $horas_practicas,
        $id_requisito,
        $estado
    );

    $stmt->execute();

    $id_materia = $conn->insert_id;

    $stmt->close();
    $stmt = null;

    $conn->commit();
    $transaccion = false;

    responder(201, "Materia registrada correctamente", [
        "id_materia" => (int)$id_materia,
        "clave_materia" => $clave,
        "nombre" => $nombre,
        "creditos" => $creditos,
        "horas_teoricas" => $horas_teoricas,
        "horas_practicas" => $horas_practicas,
        "id_materia_requisito" => $id_requisito,
        "estado" => $estado
    ]);

} catch (DomainException $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    responder(400, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log("Error SQL en materias/registrar.php: " . $e->getMessage());

    if ($e->getCode() === 1062) {
        responder(409, "La clave de materia ya está registrada");
    }

    if ($e->getCode() === 1452) {
        responder(400, "La materia requisito indicada no existe");
    }

    if ($e->getCode() === 3819) {
        responder(400, "Los datos incumplen una restricción de la base de datos");
    }

    responder(500, "Error de base de datos al registrar la materia");

} catch (Throwable $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log("Error interno en materias/registrar.php: " . $e->getMessage());

    responder(500, "Error interno al registrar la materia");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
