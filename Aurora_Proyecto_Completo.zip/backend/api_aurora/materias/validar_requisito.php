<?php
// Utilidad compartida por materias/registar.php y materias/actualizar.php.
// No es un endpoint HTTP independiente. Impedir ejecución directa.
if (realpath($_SERVER['SCRIPT_FILENAME'] ?? '') === realpath(__FILE__)) {
    http_response_code(404);
    exit;
}

function validarCadenaRequisitos($conn, $id_materia, $id_requisito)
{
    // ==========================================
    // 1. NORMALIZAR IDENTIFICADORES
    // ==========================================

    $id_materia = $id_materia !== null
        ? (int)$id_materia
        : null;

    $id_requisito = $id_requisito !== null
        ? (int)$id_requisito
        : null;

    // Si no se establece requisito, la cadena es válida.
    if ($id_requisito === null) {
        return [
            "valido" => true,
            "mensaje" => "La materia no tiene requisito."
        ];
    }

    if ($id_requisito <= 0 ||
        ($id_materia !== null && $id_materia <= 0)) {

        return [
            "valido" => false,
            "mensaje" => "Los identificadores de las materias son inválidos."
        ];
    }

    // ==========================================
    // 2. PREPARAR CONSULTA
    // ==========================================

    $stmt = $conn->prepare("
        SELECT id_materia_requisito
        FROM materias
        WHERE id_materia = ?
    ");

    if (!$stmt) {
        return [
            "valido" => false,
            "mensaje" => "No fue posible validar la cadena de requisitos."
        ];
    }

    $visitados = [];
    $actual = $id_requisito;

    try {

        // ======================================
        // 3. RECORRER CADENA DE REQUISITOS
        // ======================================

        while ($actual !== null) {

            // Detectar si la cadena regresa
            // a la materia que se está modificando.

            if (
                $id_materia !== null &&
                $actual === $id_materia
            ) {
                return [
                    "valido" => false,
                    "mensaje" => "No se puede establecer este requisito porque generaría un ciclo."
                ];
            }

            // Detectar ciclos existentes.

            if (isset($visitados[$actual])) {
                return [
                    "valido" => false,
                    "mensaje" => "La cadena de requisitos contiene un ciclo existente."
                ];
            }

            $visitados[$actual] = true;

            // Consultar el requisito de la materia actual.

            $stmt->bind_param("i", $actual);
            $stmt->execute();

            $resultado = $stmt->get_result();

            if ($resultado->num_rows === 0) {

                return [
                    "valido" => false,
                    "mensaje" => "Una de las materias requisito no existe."
                ];
            }

            $materia = $resultado->fetch_assoc();

            $actual = $materia["id_materia_requisito"] !== null
                ? (int)$materia["id_materia_requisito"]
                : null;
        }

        // ======================================
        // 4. CADENA VÁLIDA
        // ======================================

        return [
            "valido" => true,
            "mensaje" => "Cadena de requisitos válida."
        ];

    } catch (Throwable $e) {

        error_log(
            "Error al validar cadena de requisitos: " .
            $e->getMessage()
        );

        return [
            "valido" => false,
            "mensaje" => "Ocurrió un error al validar la cadena de requisitos."
        ];

    } finally {

        $stmt->close();
    }
}

?>
