<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'materias', 'consultar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = []) {

    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR ID
// ==========================================

$id = filter_var(
    $_GET["id_materia"] ?? null,
    FILTER_VALIDATE_INT
);

if ($id === false || $id === null || $id <= 0) {
    responder(400, "ID de materia inválido");
}

// ==========================================
// 3. CONSULTAR MATERIA
// ==========================================

$sql = "
    SELECT
        m.id_materia,
        m.clave_materia,
        m.nombre,
        m.creditos,
        m.horas_teoricas,
        m.horas_practicas,

        m.id_materia_requisito,

        r.clave_materia AS clave_requisito,
        r.nombre AS nombre_requisito,
        r.estado AS estado_requisito,

        (
            SELECT COUNT(*)
            FROM materias dependientes
            WHERE dependientes.id_materia_requisito = m.id_materia
        ) AS total_materias_dependientes,

        m.estado

    FROM materias m

    LEFT JOIN materias r
        ON m.id_materia_requisito = r.id_materia

    WHERE m.id_materia = ?
";

$stmt = null;

try {

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $resultado = $stmt->get_result();

    if ($resultado->num_rows === 0) {
        responder(404, "Materia no encontrada");
    }

    $materia = $resultado->fetch_assoc();

    // ======================================
    // 4. CONVERTIR TIPOS DE DATOS
    // ======================================

    $materia["id_materia"] = (int)$materia["id_materia"];
    $materia["creditos"] = (int)$materia["creditos"];

    $materia["horas_teoricas"] =
        (int)$materia["horas_teoricas"];

    $materia["horas_practicas"] =
        (int)$materia["horas_practicas"];

    $materia["id_materia_requisito"] =
        $materia["id_materia_requisito"] !== null
            ? (int)$materia["id_materia_requisito"]
            : null;

    $materia["total_materias_dependientes"] =
        (int)$materia["total_materias_dependientes"];

    $stmt->close();
    $stmt = null;

    responder(200, "Materia consultada correctamente", [
        "materia" => $materia
    ]);

} catch (mysqli_sql_exception $e) {

    error_log("Error SQL en materias/consultar.php: " . $e->getMessage());

    responder(500, "Error de base de datos al consultar la materia");

} catch (Throwable $e) {

    error_log("Error interno en materias/consultar.php: " . $e->getMessage());

    responder(500, "Error interno al consultar la materia");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
