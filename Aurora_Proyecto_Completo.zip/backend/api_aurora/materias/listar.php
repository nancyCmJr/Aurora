<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'materias', 'listar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = []) {

    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. CONSULTAR MATERIAS
// ==========================================

$sql = "
    SELECT
        m.id_materia,
        m.clave_materia,
        m.nombre,
        m.creditos,
        m.horas_teoricas,
        m.horas_practicas,

        m.id_materia_requisito,

        r.clave_materia AS clave_requisito,
        r.nombre AS nombre_requisito,
        r.estado AS estado_requisito,

        (
            SELECT COUNT(*)
            FROM materias dependientes
            WHERE dependientes.id_materia_requisito = m.id_materia
        ) AS total_materias_dependientes,

        m.estado

    FROM materias m

    LEFT JOIN materias r
        ON m.id_materia_requisito = r.id_materia

    ORDER BY
        m.nombre ASC,
        m.clave_materia ASC
";

try {

    $resultado = $conn->query($sql);

    $materias = [];

    while ($fila = $resultado->fetch_assoc()) {

        $fila["id_materia"] = (int)$fila["id_materia"];
        $fila["creditos"] = (int)$fila["creditos"];
        $fila["horas_teoricas"] = (int)$fila["horas_teoricas"];
        $fila["horas_practicas"] = (int)$fila["horas_practicas"];

        $fila["id_materia_requisito"] =
            $fila["id_materia_requisito"] !== null
                ? (int)$fila["id_materia_requisito"]
                : null;

        $fila["total_materias_dependientes"] =
            (int)$fila["total_materias_dependientes"];

        $materias[] = $fila;
    }

    responder(200, "Materias consultadas correctamente", [
        "total" => count($materias),
        "materias" => $materias
    ]);

} catch (mysqli_sql_exception $e) {

    error_log("Error SQL en materias/listar.php: " . $e->getMessage());

    responder(500, "Error de base de datos al consultar las materias");

} catch (Throwable $e) {

    error_log("Error interno en materias/listar.php: " . $e->getMessage());

    responder(500, "Error interno al consultar las materias");

} finally {

    $conn->close();
}

?>
