<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'materias', 'actualizar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";
require_once __DIR__ . "/validar_requisito.php";

function responder($codigo, $mensaje, $datos = []) {

    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. RECIBIR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "JSON inválido");
}

// ==========================================
// 3. VALIDAR CAMPOS OBLIGATORIOS
// ==========================================

$obligatorios = [
    "id_materia",
    "clave_materia",
    "nombre",
    "creditos",
    "horas_teoricas",
    "horas_practicas",
    "estado"
];

foreach ($obligatorios as $campo) {
    if (!array_key_exists($campo, $data)) {
        responder(400, "Falta el campo obligatorio: " . $campo);
    }
}

if (
    !is_string($data["clave_materia"]) ||
    !is_string($data["nombre"]) ||
    !is_string($data["estado"])
) {
    responder(400, "Los datos de texto tienen un formato incorrecto");
}

// ==========================================
// 4. OBTENER Y NORMALIZAR DATOS
// ==========================================

$id = filter_var(
    $data["id_materia"],
    FILTER_VALIDATE_INT
);

$clave = trim($data["clave_materia"]);
$nombre = trim($data["nombre"]);

$creditos = filter_var(
    $data["creditos"],
    FILTER_VALIDATE_INT
);

$horas_teoricas = filter_var(
    $data["horas_teoricas"],
    FILTER_VALIDATE_INT
);

$horas_practicas = filter_var(
    $data["horas_practicas"],
    FILTER_VALIDATE_INT
);

$id_requisito = null;

if (
    array_key_exists("id_materia_requisito", $data) &&
    $data["id_materia_requisito"] !== null &&
    $data["id_materia_requisito"] !== ""
) {
    $id_requisito = filter_var(
        $data["id_materia_requisito"],
        FILTER_VALIDATE_INT
    );
}

$estado = $data["estado"];

// ==========================================
// 5. VALIDAR DATOS
// ==========================================

if (
    $id === false ||
    $id === null ||
    $id <= 0 ||
    $clave === "" ||
    mb_strlen($clave) > 15 ||
    $nombre === "" ||
    mb_strlen($nombre) > 150 ||
    $creditos === false ||
    $creditos < 3 ||
    $creditos > 6 ||
    $horas_teoricas === false ||
    $horas_teoricas < 0 ||
    $horas_practicas === false ||
    $horas_practicas < 0 ||
    !in_array($estado, ["Activa", "Inactiva"], true) ||
    (
        $id_requisito !== null &&
        ($id_requisito === false || $id_requisito <= 0)
    )
) {
    responder(400, "Verifica los datos de la materia");
}

if ($id_requisito !== null && $id_requisito === $id) {
    responder(400, "Una materia no puede ser requisito de sí misma");
}

// ==========================================
// 6. INICIAR TRANSACCIÓN
// ==========================================

$stmt = null;
$transaccion = false;

try {

    $conn->begin_transaction();
    $transaccion = true;

    // ======================================
    // 7. BLOQUEAR Y CONSULTAR MATERIA
    // ======================================

    $stmt = $conn->prepare("
        SELECT *
        FROM materias
        WHERE id_materia = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $materiaActual = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$materiaActual) {
        throw new DomainException("Materia no encontrada");
    }

    // Con grupos históricos, conservar identidad, créditos, horas y requisitos.
    $stmtHist = $conn->prepare('SELECT id_grupo FROM grupos WHERE id_materia = ? LIMIT 1');
    $stmtHist->bind_param('i',$id);
    $stmtHist->execute();
    $tieneGrupos = $stmtHist->get_result()->num_rows > 0;
    $stmtHist->close();
    if ($tieneGrupos && (
        $clave !== $materiaActual['clave_materia'] ||
        (int)$creditos !== (int)$materiaActual['creditos'] ||
        (int)$horas_teoricas !== (int)$materiaActual['horas_teoricas'] ||
        (int)$horas_practicas !== (int)$materiaActual['horas_practicas'] ||
        $id_requisito !== ($materiaActual['id_materia_requisito'] === null ? null : (int)$materiaActual['id_materia_requisito'])
    )) {
        throw new DomainException('No se modifican los datos académicos de una materia utilizada en grupos históricos',409);
    }

    // ======================================
    // 8. VALIDAR CLAVE DUPLICADA
    // ======================================

    $stmt = $conn->prepare("
        SELECT id_materia
        FROM materias
        WHERE clave_materia = ?
          AND id_materia <> ?
        LIMIT 1
    ");

    $stmt->bind_param("si", $clave, $id);
    $stmt->execute();

    $duplicada = $stmt->get_result()->num_rows > 0;

    $stmt->close();
    $stmt = null;

    if ($duplicada) {
        throw new DomainException(
            "La clave ya pertenece a otra materia",
            409
        );
    }

    // ======================================
    // 9. VALIDAR MATERIA REQUISITO
    // ======================================

    if ($id_requisito !== null) {

        $stmt = $conn->prepare("
            SELECT id_materia, estado
            FROM materias
            WHERE id_materia = ?
            FOR UPDATE
        ");

        $stmt->bind_param("i", $id_requisito);
        $stmt->execute();

        $requisito = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if (!$requisito) {
            throw new DomainException(
                "La materia requisito no existe"
            );
        }

        if ($requisito["estado"] !== "Activa") {
            throw new DomainException(
                "La materia requisito debe estar activa"
            );
        }

        $validacion = validarCadenaRequisitos(
            $conn,
            $id,
            $id_requisito
        );

        if (
            !isset($validacion["valido"]) ||
            !$validacion["valido"]
        ) {
            throw new DomainException(
                $validacion["mensaje"] ??
                "La cadena de requisitos no es válida"
            );
        }

        // Comprobar que el requisito no esté ubicado
        // en el mismo semestre o en uno posterior
        // dentro de una misma retícula.

        $stmt = $conn->prepare("
            SELECT
                rm_actual.id_reticula,
                rm_actual.semestre AS semestre_materia,
                rm_requisito.semestre AS semestre_requisito
            FROM reticula_materia rm_actual
            INNER JOIN reticula_materia rm_requisito
                ON rm_actual.id_reticula = rm_requisito.id_reticula
            WHERE rm_actual.id_materia = ?
              AND rm_requisito.id_materia = ?
              AND rm_requisito.semestre >= rm_actual.semestre
            LIMIT 1
        ");

        $stmt->bind_param("ii", $id, $id_requisito);
        $stmt->execute();

        $ordenIncorrecto = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if ($ordenIncorrecto) {
            throw new DomainException(
                "El requisito debe estar ubicado en un semestre anterior dentro de la retícula"
            );
        }
    }

    // ======================================
    // 10. VALIDAR CAMBIO DE CRÉDITOS
    // ======================================

    if ((int)$materiaActual["creditos"] !== $creditos) {

        $stmt = $conn->prepare("
            SELECT
                r.id_reticula,
                c.total_creditos,
                COALESCE(SUM(m.creditos), 0) AS creditos_actuales
            FROM reticulas r
            INNER JOIN carreras c
                ON r.id_carrera = c.id_carrera
            INNER JOIN reticula_materia rm
                ON r.id_reticula = rm.id_reticula
            INNER JOIN materias m
                ON rm.id_materia = m.id_materia
            WHERE r.id_reticula IN (
                SELECT id_reticula
                FROM reticula_materia
                WHERE id_materia = ?
            )
            GROUP BY r.id_reticula, c.total_creditos
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $reticulas = $stmt->get_result();

        while ($reticula = $reticulas->fetch_assoc()) {

            $nuevoTotal =
                (int)$reticula["creditos_actuales"]
                - (int)$materiaActual["creditos"]
                + $creditos;

            if ($nuevoTotal > (int)$reticula["total_creditos"]) {

                $stmt->close();
                $stmt = null;

                throw new DomainException(
                    "El cambio de créditos supera el total permitido por la carrera en la retícula " .
                    $reticula["id_reticula"]
                );
            }
        }

        $stmt->close();
        $stmt = null;
    }

    // ======================================
    // 11. VALIDAR DESACTIVACIÓN
    // ======================================

    if (
        $estado === "Inactiva" &&
        $materiaActual["estado"] === "Activa"
    ) {

        // No desactivar si pertenece a una retícula vigente.

        $stmt = $conn->prepare("
            SELECT r.id_reticula
            FROM reticula_materia rm
            INNER JOIN reticulas r
                ON rm.id_reticula = r.id_reticula
            WHERE rm.id_materia = ?
              AND r.estado = 'Vigente'
            LIMIT 1
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $enReticulaVigente = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if ($enReticulaVigente) {
            throw new DomainException(
                "No se puede desactivar: la materia pertenece a una retícula vigente"
            );
        }

        // No desactivar si tiene grupos planeados o abiertos.

        $stmt = $conn->prepare("
            SELECT id_grupo
            FROM grupos
            WHERE id_materia = ?
              AND estado IN ('Planeado', 'Abierto')
            LIMIT 1
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $tieneGruposActivos = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if ($tieneGruposActivos) {
            throw new DomainException(
                "No se puede desactivar: la materia tiene grupos planeados o abiertos"
            );
        }

        // No desactivar si otras materias activas
        // la utilizan como requisito.

        $stmt = $conn->prepare("
            SELECT id_materia
            FROM materias
            WHERE id_materia_requisito = ?
              AND estado = 'Activa'
            LIMIT 1
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $tieneDependientes = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if ($tieneDependientes) {
            throw new DomainException(
                "No se puede desactivar: otras materias activas la utilizan como requisito"
            );
        }
    }

    // ======================================
    // 12. ACTUALIZAR MATERIA
    // ======================================

    $stmt = $conn->prepare("
        UPDATE materias SET
            clave_materia = ?,
            nombre = ?,
            creditos = ?,
            horas_teoricas = ?,
            horas_practicas = ?,
            id_materia_requisito = ?,
            estado = ?
        WHERE id_materia = ?
    ");

    $stmt->bind_param(
        "ssiiiisi",
        $clave,
        $nombre,
        $creditos,
        $horas_teoricas,
        $horas_practicas,
        $id_requisito,
        $estado,
        $id
    );

    $stmt->execute();

    $stmt->close();
    $stmt = null;

    $conn->commit();
    $transaccion = false;

    responder(200, "Materia actualizada correctamente", [
        "id_materia" => $id,
        "clave_materia" => $clave,
        "nombre" => $nombre,
        "creditos" => $creditos,
        "horas_teoricas" => $horas_teoricas,
        "horas_practicas" => $horas_practicas,
        "id_materia_requisito" => $id_requisito,
        "estado" => $estado
    ]);

} catch (DomainException $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    $codigo = $e->getCode() === 409 ? 409 : 400;

    responder($codigo, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log("Error SQL en materias/actualizar.php: " . $e->getMessage());

    if ($e->getCode() === 1062) {
        responder(409, "La clave de materia ya está registrada");
    }

    if ($e->getCode() === 1452) {
        responder(400, "La materia requisito indicada no existe");
    }

    if ($e->getCode() === 3819) {
        responder(400, "Los datos incumplen una restricción de la base de datos");
    }

    responder(500, "Error de base de datos al actualizar la materia");

} catch (Throwable $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log("Error interno en materias/actualizar.php: " . $e->getMessage());

    responder(500, "Error interno al actualizar la materia");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
