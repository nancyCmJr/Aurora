<?php
require_once __DIR__ . '/academico.php';

function auroraGrupo(mysqli $db, int $id, bool $bloquear = false): array {
    $grupo = auroraFila($db, 'SELECT g.*, m.estado AS estado_materia,
        m.id_materia_requisito, d.estado AS estado_docente
        FROM grupos g JOIN materias m ON m.id_materia = g.id_materia
        JOIN docentes d ON d.id_docente = g.id_docente
        WHERE g.id_grupo = ?' . ($bloquear ? ' FOR UPDATE' : ''), [$id]);
    if (!$grupo) throw new DomainException('Grupo inexistente', 404);
    return $grupo;
}
function auroraElegibilidad(mysqli $db, string $numero, array $g): void {
    if ($g['estado'] !== 'Abierto') throw new DomainException('El grupo no está abierto', 409);
    if ($g['estado_materia'] !== 'Activa' || $g['estado_docente'] !== 'Activo') {
        throw new DomainException('Materia o docente inactivo', 409);
    }
    $alumno = auroraFila($db, 'SELECT estado FROM alumnos WHERE numero_control = ?', [$numero]);
    if (!$alumno || $alumno['estado'] !== 'Activo') {
        throw new DomainException('Alumno inexistente o inactivo', 409);
    }
    $ins = auroraFila($db, "SELECT i.id_carrera FROM inscripciones i JOIN carreras c
        ON c.id_carrera = i.id_carrera WHERE i.numero_control = ? AND i.periodo = ?
        AND i.anio = ? AND i.estado = 'En curso' AND c.estado = 'Activa'",
        [$numero, $g['periodo'], (int)$g['anio']]);
    if (!$ins) throw new DomainException('El alumno no está inscrito en la carrera de este ciclo', 409);
    $ret = auroraFila($db, "SELECT r.id_reticula FROM reticulas r
        JOIN reticula_materia rm ON rm.id_reticula = r.id_reticula
        WHERE r.id_carrera = ? AND r.estado = 'Vigente' AND rm.id_materia = ?
        AND rm.semestre = ?", [(int)$ins['id_carrera'], (int)$g['id_materia'], (int)$g['semestre']]);
    if (!$ret) throw new DomainException('La materia y el semestre no corresponden a la retícula vigente de la carrera', 409);
    if ($g['id_materia_requisito'] !== null) {
        $prev = auroraFila($db, "SELECT k.id_kardex FROM kardex k JOIN grupos g ON g.id_grupo = k.id_grupo
            WHERE k.numero_control = ? AND g.id_materia = ? AND k.estado = 'Aprobada' LIMIT 1",
            [$numero, (int)$g['id_materia_requisito']]);
        if (!$prev) throw new DomainException('No ha aprobado el requisito de esta materia', 409);
    }
    $aprobado = auroraFila($db, "SELECT k.id_kardex FROM kardex k JOIN grupos g ON g.id_grupo = k.id_grupo
        WHERE k.numero_control = ? AND g.id_materia = ? AND k.estado = 'Aprobada' LIMIT 1",
        [$numero, (int)$g['id_materia']]);
    if ($aprobado) throw new DomainException('El alumno ya aprobó esta materia en un ciclo anterior', 409);
    $duplicado = auroraFila($db, "SELECT k.id_kardex FROM kardex k JOIN grupos g ON g.id_grupo = k.id_grupo
        WHERE k.numero_control = ? AND g.id_materia = ? AND k.periodo = ? AND k.anio = ?
          AND k.estado <> 'Baja' LIMIT 1", [$numero, (int)$g['id_materia'], $g['periodo'], (int)$g['anio']]);
    if ($duplicado) throw new DomainException('El alumno ya tiene esta materia en el mismo ciclo', 409);
    $ocup = auroraFila($db, "SELECT COUNT(*) total FROM kardex WHERE id_grupo = ? AND estado <> 'Baja'", [(int)$g['id_grupo']]);
    if ((int)$ocup['total'] >= (int)$g['capacidad']) throw new DomainException('No hay cupo disponible', 409);
}
function auroraValidarNota(string $estado, $calificacion): ?int {
    if (!in_array($estado, ['Cursando','Aprobada','Reprobada','Baja'], true))
        auroraResponder(400, 'Estado de kardex inválido');
    if ($calificacion === '' || $calificacion === null) $calificacion = null;
    if ($calificacion !== null) {
        $n = filter_var($calificacion, FILTER_VALIDATE_INT);
        if ($n === false || $n < 0 || $n > 100) auroraResponder(400, 'Calificación fuera del rango 0 a 100');
        $calificacion = (int)$n;
    }
    if ($estado === 'Cursando' && $calificacion !== null) auroraResponder(400, 'Una materia cursándose no tiene calificación final');
    if (in_array($estado, ['Aprobada','Reprobada'], true) && $calificacion === null)
        auroraResponder(400, 'La calificación final es obligatoria');
    if ($estado === 'Baja' && $calificacion !== null) auroraResponder(400, 'Una baja no debe llevar calificación');
    $min = (int)(getenv('AURORA_NOTA_APROBATORIA') ?: 70);
    if ($estado === 'Aprobada' && $calificacion < $min) auroraResponder(400, "La nota para aprobar debe ser al menos $min");
    if ($estado === 'Reprobada' && $calificacion >= $min) auroraResponder(400, "La nota reprobatoria debe ser menor a $min");
    return $calificacion;
}
