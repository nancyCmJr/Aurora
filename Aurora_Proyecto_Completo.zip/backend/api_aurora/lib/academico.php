
<?php

/**
 * =========================================================
 * AURORA - UTILIDADES ACADÉMICAS
 * =========================================================
 *
 * Compatible con PHP 8.0 o superior.
 *
 * Requisitos:
 * - PHP >= 8.0
 * - mysqli
 * - mysqlnd
 *
 * Funciones:
 * - auroraJson()
 * - auroraId()
 * - auroraCiclo()
 * - auroraSql()
 * - auroraFila()
 * - auroraFilas()
 * - auroraModificar()
 * - auroraEnum()
 * - auroraFallo()
 * - auroraVerificarReticulaEditable()
 *
 * =========================================================
 */

require_once __DIR__ . '/../auth/session_config.php';

// =========================================================
// 1. COMPATIBILIDAD CON PHP 8.0
// =========================================================

/**
 * array_is_list() existe de forma nativa
 * solamente desde PHP 8.1.
 *
 * Esta implementación permite utilizarla
 * también en PHP 8.0.
 */

if (!function_exists('array_is_list')) {

    function array_is_list(array $array): bool {

        $indice = 0;

        foreach ($array as $clave => $valor) {

            if ($clave !== $indice) {
                return false;
            }

            $indice++;
        }

        return true;
    }
}

// =========================================================
// 2. LEER Y VALIDAR JSON
// =========================================================

/**
 * Lee el cuerpo de una solicitud HTTP
 * y comprueba que sea un objeto JSON.
 *
 * Correcto:
 * {
 *   "id_grupo": 1,
 *   "id_salon": 2
 * }
 *
 * Incorrecto:
 * [
 *   1,
 *   2
 * ]
 *
 * @return array
 */

function auroraJson(): array {

    $contenido = file_get_contents('php://input');

    if (
        $contenido === false ||
        trim($contenido) === ''
    ) {

        auroraResponder(
            400,
            'No se recibieron datos JSON'
        );

        exit;
    }

    // Decodificar primero como objeto para
    // distinguir {} de [] correctamente.

    $objeto = json_decode($contenido);

    if (
        json_last_error() !== JSON_ERROR_NONE ||
        !($objeto instanceof stdClass)
    ) {

        auroraResponder(
            400,
            'Envía un objeto JSON válido'
        );

        exit;
    }

    // Convertir el objeto JSON a arreglo
    // asociativo para utilizarlo en los endpoints.

    $datos = json_decode($contenido, true);

    if (!is_array($datos)) {

        auroraResponder(
            400,
            'No fue posible procesar los datos JSON'
        );

        exit;
    }

    return $datos;
}

// =========================================================
// 3. VALIDAR IDENTIFICADORES
// =========================================================

/**
 * Verifica que un identificador sea
 * un número entero positivo.
 *
 * @param mixed $value
 * @param string $field
 *
 * @return int
 */

function auroraId(
    $value,
    string $field = 'identificador'
): int {

    if (
        $value === null ||
        is_bool($value) ||
        is_array($value) ||
        is_object($value)
    ) {

        auroraResponder(
            400,
            "El campo $field debe ser un entero positivo"
        );

        exit;
    }

    $numero = filter_var(
        $value,
        FILTER_VALIDATE_INT
    );

    if (
        $numero === false ||
        $numero === null ||
        $numero < 1
    ) {

        auroraResponder(
            400,
            "El campo $field debe ser un entero positivo"
        );

        exit;
    }

    return (int) $numero;
}

// =========================================================
// 4. VALIDAR PERIODO Y AÑO
// =========================================================

/**
 * Comprueba los datos de un ciclo escolar.
 *
 * Campos esperados:
 *
 * periodo: texto de máximo 20 caracteres
 * anio: entero entre 1901 y 2155
 *
 * @param array $datos
 *
 * @return array
 */

function auroraCiclo(array $datos): array {

    $periodo = $datos['periodo'] ?? null;

    $anio = filter_var(
        $datos['anio'] ?? null,
        FILTER_VALIDATE_INT
    );

    // Validar periodo

    if (!is_string($periodo)) {

        auroraResponder(
            400,
            'El periodo escolar debe ser texto'
        );

        exit;
    }

    $periodo = trim($periodo);

    // Longitud compatible aunque no exista
    // la extensión mbstring.

    if (function_exists('mb_strlen')) {

        $longitud = mb_strlen(
            $periodo,
            'UTF-8'
        );

    } else {

        $longitud = strlen($periodo);
    }

    if (
        $periodo === '' ||
        $longitud > 20
    ) {

        auroraResponder(
            400,
            'El periodo es obligatorio y debe ' .
            'tener máximo 20 caracteres'
        );

        exit;
    }

    // Validar año

    if (
        $anio === false ||
        $anio === null ||
        $anio < 1901 ||
        $anio > 2155
    ) {

        auroraResponder(
            400,
            'El año escolar debe estar ' .
            'entre 1901 y 2155'
        );

        exit;
    }

    return [
        $periodo,
        (int) $anio
    ];
}

// =========================================================
// 5. EJECUTAR CONSULTAS SQL
// =========================================================

/**
 * Prepara y ejecuta una consulta SQL.
 *
 * Utiliza parámetros preparados para
 * evitar inyección SQL.
 *
 * Detecta los tipos automáticamente:
 *
 * i = integer
 * d = double
 * s = string
 *
 * @param mysqli $conn
 * @param string $sql
 * @param array $params
 *
 * @return mysqli_stmt
 */

function auroraSql(
    mysqli $conn,
    string $sql,
    array $params = []
): mysqli_stmt {

    $stmt = $conn->prepare($sql);

    if ($params !== []) {

        $tipos = '';

        foreach ($params as $valor) {

            if (is_int($valor)) {

                $tipos .= 'i';

            } elseif (is_float($valor)) {

                $tipos .= 'd';

            } else {

                $tipos .= 's';
            }
        }

        // bind_param recibe los parámetros
        // por referencia. Se crea una copia
        // indexada para trabajar de forma
        // compatible con PHP 8.0.

        $valores = array_values($params);

        $referencias = [];

        foreach ($valores as $indice => &$valor) {

            $referencias[$indice] = &$valor;
        }

        unset($valor);

        $stmt->bind_param(
            $tipos,
            ...$referencias
        );
    }

    $stmt->execute();

    return $stmt;
}

// =========================================================
// 6. CONSULTAR UN SOLO REGISTRO
// =========================================================

/**
 * Devuelve una fila asociativa.
 *
 * Si no encuentra resultados,
 * devuelve null.
 *
 * @return array|null
 */

function auroraFila(
    mysqli $conn,
    string $sql,
    array $params = []
): ?array {

    $stmt = auroraSql(
        $conn,
        $sql,
        $params
    );

    $resultado = $stmt->get_result();

    $fila = $resultado->fetch_assoc();

    $resultado->free();

    $stmt->close();

    return $fila ?: null;
}

// =========================================================
// 7. CONSULTAR VARIOS REGISTROS
// =========================================================

/**
 * Devuelve todas las filas de
 * una consulta SQL.
 *
 * @return array
 */

function auroraFilas(
    mysqli $conn,
    string $sql,
    array $params = []
): array {

    $stmt = auroraSql(
        $conn,
        $sql,
        $params
    );

    $resultado = $stmt->get_result();

    $filas = $resultado->fetch_all(
        MYSQLI_ASSOC
    );

    $resultado->free();

    $stmt->close();

    return $filas;
}

// =========================================================
// 8. MODIFICAR REGISTROS
// =========================================================

/**
 * Ejecuta una consulta de modificación.
 *
 * Se utiliza para:
 * - INSERT
 * - UPDATE
 * - DELETE
 *
 * Devuelve el número de filas afectadas.
 *
 * @return int
 */

function auroraModificar(
    mysqli $conn,
    string $sql,
    array $params = []
): int {

    $stmt = auroraSql(
        $conn,
        $sql,
        $params
    );

    $afectadas = $stmt->affected_rows;

    $stmt->close();

    return (int) $afectadas;
}

// =========================================================
// 9. VALIDAR VALORES ENUM
// =========================================================

/**
 * Comprueba que un valor corresponda
 * a una de las opciones permitidas.
 *
 * Ejemplo:
 *
 * auroraEnum(
 *   $datos['estado'] ?? null,
 *   ['Activo', 'Cancelado'],
 *   'estado'
 * );
 *
 * @return string
 */

function auroraEnum(
    $valor,
    array $opciones,
    string $campo
): string {

    if (
        !is_string($valor) ||
        !in_array(
            $valor,
            $opciones,
            true
        )
    ) {

        auroraResponder(
            400,
            "Valor de $campo inválido"
        );

        exit;
    }

    return $valor;
}

// =========================================================
// 10. MANEJO CENTRALIZADO DE ERRORES
// =========================================================

/**
 * Controla excepciones de los endpoints.
 *
 * Compatible con PHP 8.0.
 *
 * NOTA:
 * Se utiliza void en lugar de never,
 * porque never requiere PHP 8.1.
 *
 * @return void
 */

function auroraFallo(
    Throwable $e,
    mysqli $conn
): void {

    // ====================================
    // REVERTIR TRANSACCIÓN SI EXISTE
    // ====================================

    try {

        $conn->rollback();

    } catch (Throwable $ignorar) {

        // No interrumpir el manejo del error
        // si no hay una transacción activa.
    }

    // ====================================
    // ERRORES DE NEGOCIO
    // ====================================

    if ($e instanceof DomainException) {

        $codigo = (int) $e->getCode();

        if (
            !in_array(
                $codigo,
                [400, 403, 404, 409],
                true
            )
        ) {

            $codigo = 409;
        }

        auroraResponder(
            $codigo,
            $e->getMessage()
        );

        exit;
    }

    // ====================================
    // ERRORES MYSQL
    // ====================================

    if ($e instanceof mysqli_sql_exception) {

        $codigo = (int) $e->getCode();

        // Registro duplicado

        if ($codigo === 1062) {

            auroraResponder(
                409,
                'Ya existe un registro con ' .
                'esa combinación única'
            );

            exit;
        }

        // Restricciones de integridad

        if (
            in_array(
                $codigo,
                [1451, 1452, 3819, 1644],
                true
            )
        ) {

            // Registrar la información técnica
            // sin mostrar detalles SQL al cliente.

            error_log(
                'Aurora - restricción MySQL: ' .
                $e->getMessage()
            );

            auroraResponder(
                409,
                'Operación rechazada por ' .
                'una restricción de integridad'
            );

            exit;
        }
    }

    // ====================================
    // ERROR INTERNO
    // ====================================

    error_log(
        'Aurora API: ' .
        $e->getMessage()
    );

    auroraResponder(
        500,
        'Ocurrió un error interno ' .
        'al procesar la solicitud'
    );

    exit;
}

// =========================================================
// 11. VALIDAR EDICIÓN DE RETÍCULAS
// =========================================================

/**
 * No permite modificar una retícula
 * cuando ya existe historial de
 * inscripciones de su carrera.
 *
 * @return void
 */

function auroraVerificarReticulaEditable(
    mysqli $conn,
    int $idReticula
): void {

    $fila = auroraFila(

        $conn,

        "
        SELECT
            r.id_carrera,

            (
                SELECT COUNT(*)
                FROM inscripciones i
                WHERE i.id_carrera = r.id_carrera
            ) AS inscripciones

        FROM reticulas r

        WHERE r.id_reticula = ?
        ",

        [$idReticula]
    );

    if (!$fila) {

        throw new DomainException(
            'Retícula inexistente',
            404
        );
    }

    if (
        (int) $fila['inscripciones'] > 0
    ) {

        throw new DomainException(

            'No se puede alterar una retícula ' .
            'de una carrera que ya tiene ' .
            'historial de inscripciones',

            409
        );
    }
}
