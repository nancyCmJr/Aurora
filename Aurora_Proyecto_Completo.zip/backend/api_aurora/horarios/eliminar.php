<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'horarios', 'eliminar');
require_once __DIR__ . '/../lib/academico.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') auroraResponder(405,'Método no permitido');
$d=auroraJson(); $id=auroraId($d['id_horario'] ?? null,'id_horario');
try {
    $conn->begin_transaction();
    $h=auroraFila($conn,'SELECT id_grupo, estado FROM horarios WHERE id_horario=? FOR UPDATE',[$id]);
    if (!$h) throw new DomainException('Horario inexistente',404);
    if ($h['estado']==='Cancelado') throw new DomainException('El horario ya está cancelado',409);
    auroraModificar($conn,"UPDATE horarios SET estado='Cancelado' WHERE id_horario=?",[$id]);
    $conn->commit();
    auroraResponder(200,'Horario cancelado; se conserva el historial',['data'=>['id_horario'=>$id,'id_grupo'=>(int)$h['id_grupo'],'estado'=>'Cancelado']]);
} catch (Throwable $e) {auroraFallo($e,$conn);}
