<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'horarios', 'actualizar');
require_once __DIR__ . '/../lib/academico.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') auroraResponder(405,'Método no permitido');
$d=auroraJson(); $id=auroraId($d['id_horario'] ?? null,'id_horario');
try {
    $conn->begin_transaction();
    $old=auroraFila($conn,'SELECT * FROM horarios WHERE id_horario=? FOR UPDATE',[$id]);
    if (!$old) throw new DomainException('Horario inexistente',404);
    if ($old['estado'] === 'Cancelado') throw new DomainException('El horario cancelado queda como histórico; registra uno nuevo',409);
    $g=isset($d['id_grupo'])?auroraId($d['id_grupo'],'id_grupo'):(int)$old['id_grupo'];
    if ($g !== (int)$old['id_grupo']) throw new DomainException('No se reasigna un horario histórico a otro grupo',409);
    $s=isset($d['id_salon'])?auroraId($d['id_salon'],'id_salon'):(int)$old['id_salon'];
    $dia=auroraEnum($d['dia_semana'] ?? $old['dia_semana'],['Lunes','Martes','Miercoles','Jueves','Viernes','Sabado'],'dia_semana');
    $inicio=(string)($d['hora_inicio'] ?? $old['hora_inicio']);
    $fin=(string)($d['hora_fin'] ?? $old['hora_fin']);
    if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/',$inicio)
      || !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/',$fin)
      || strcmp($fin,$inicio)<=0) throw new DomainException('Horario inválido',400);
    auroraModificar($conn,'UPDATE horarios SET id_salon=?, dia_semana=?, hora_inicio=?, hora_fin=? WHERE id_horario=?',[$s,$dia,$inicio,$fin,$id]);
    $conn->commit();
    auroraResponder(200,'Horario actualizado',['data'=>['id_horario'=>$id,'id_grupo'=>$g,'id_salon'=>$s,'dia_semana'=>$dia,'hora_inicio'=>$inicio,'hora_fin'=>$fin]]);
} catch (Throwable $e) {auroraFallo($e,$conn);}
