<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'horarios', 'consultar');
require_once __DIR__ . '/../lib/academico.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') auroraResponder(405,'Método no permitido');
$id=auroraId($_GET['id_horario'] ?? null,'id_horario');
try {
 $h=auroraFila($conn,"SELECT h.*,g.clave_grupo,g.capacidad,g.semestre,g.modalidad,
 g.estado AS estado_grupo,g.periodo,g.anio,g.id_docente,g.id_materia,
 s.nombre AS nombre_salon,s.tipo AS tipo_salon,s.capacidad AS capacidad_salon,
 s.id_edificio,s.id_area,d.nombre AS nombre_docente,d.apellidos AS apellidos_docente,
 m.nombre AS nombre_materia,m.clave_materia
 FROM horarios h JOIN grupos g ON g.id_grupo=h.id_grupo
 JOIN salones s ON s.id_salon=h.id_salon JOIN docentes d ON d.id_docente=g.id_docente
 JOIN materias m ON m.id_materia=g.id_materia WHERE h.id_horario=?",[$id]);
 if (!$h) throw new DomainException('Horario inexistente',404);
 auroraResponder(200,'Horario consultado correctamente',['horario'=>$h,'data'=>$h]);
} catch(Throwable $e){auroraFallo($e,$conn);}
