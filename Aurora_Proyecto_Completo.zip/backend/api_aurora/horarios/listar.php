<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'horarios', 'listar');
require_once __DIR__ . '/../lib/academico.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') auroraResponder(405,'Método no permitido');
$sql="SELECT h.id_horario,h.id_grupo,g.clave_grupo,g.capacidad,g.semestre,g.modalidad,
 g.estado AS estado_grupo,g.periodo,g.anio,h.id_salon,s.nombre AS nombre_salon,
 s.tipo AS tipo_salon,s.capacidad AS capacidad_salon,s.estado AS estado_salon,
 s.id_edificio,e.nombre AS nombre_edificio,s.id_area,a.nombre AS nombre_area,
 h.dia_semana,h.hora_inicio,h.hora_fin,h.estado AS estado_horario,
 g.id_docente,d.codigo AS codigo_docente,d.nombre AS nombre_docente,
 d.seg_nombre AS segundo_nombre_docente,d.apellidos AS apellidos_docente,
 d.estado AS estado_docente,g.id_materia,m.clave_materia,m.nombre AS nombre_materia,
 m.estado AS estado_materia
 FROM horarios h JOIN grupos g ON g.id_grupo=h.id_grupo
 JOIN salones s ON s.id_salon=h.id_salon JOIN edificios e ON e.id_edificio=s.id_edificio
 JOIN areas a ON a.id_area=s.id_area JOIN docentes d ON d.id_docente=g.id_docente
 JOIN materias m ON m.id_materia=g.id_materia WHERE 1=1";
$filters=['id_grupo'=>'i','id_docente'=>'i','id_salon'=>'i','dia_semana'=>'s','periodo'=>'s','anio'=>'i','estado_horario'=>'s'];
$cols=['id_grupo'=>'h.id_grupo','id_docente'=>'g.id_docente','id_salon'=>'h.id_salon',
'dia_semana'=>'h.dia_semana','periodo'=>'g.periodo','anio'=>'g.anio','estado_horario'=>'h.estado'];
$params=[];
foreach($filters as $campo=>$tipo){
 if (!isset($_GET[$campo]) || $_GET[$campo]==='') continue;
 $v=$_GET[$campo];
 if ($tipo==='i') $v=auroraId($v,$campo);
 elseif (!is_string($v) || strlen($v)>20) auroraResponder(400,'Filtro inválido: '.$campo);
 $sql.=' AND '.$cols[$campo].'=?'; $params[]=$v;
}
$sql.=" ORDER BY g.anio DESC,g.periodo,h.dia_semana,h.hora_inicio,h.id_horario";
try {$datos=auroraFilas($conn,$sql,$params);
 auroraResponder(200,'Horarios consultados',['total'=>count($datos),'horarios'=>$datos,'data'=>$datos]);
} catch(Throwable $e){auroraFallo($e,$conn);}
