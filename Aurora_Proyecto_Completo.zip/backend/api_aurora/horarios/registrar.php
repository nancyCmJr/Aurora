<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'horarios', 'registrar');
require_once __DIR__ . '/../lib/academico.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') auroraResponder(405,'Método no permitido');
$d=auroraJson();
$g=auroraId($d['id_grupo'] ?? null,'id_grupo'); $s=auroraId($d['id_salon'] ?? null,'id_salon');
$dia=auroraEnum($d['dia_semana'] ?? null,['Lunes','Martes','Miercoles','Jueves','Viernes','Sabado'],'dia_semana');
$inicio=trim((string)($d['hora_inicio'] ?? '')); $fin=trim((string)($d['hora_fin'] ?? ''));
if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/',$inicio)
    || !preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/',$fin)
    || strcmp($fin,$inicio)<=0) auroraResponder(400,'Intervalo de horario inválido');
try {
    // sp_registrar_horario gestiona su propia transacción y ejecuta los triggers.
    $stmt=auroraSql($conn,'CALL sp_registrar_horario(?,?,?,?,?)',[$g,$s,$dia,$inicio,$fin]);
    $r=$stmt->get_result()->fetch_assoc(); $stmt->close();
    while ($conn->more_results()) { $conn->next_result(); $rs=$conn->store_result(); if ($rs) $rs->free(); }
    auroraResponder(201,'Horario registrado correctamente',['data'=>['id_horario'=>(int)$r['id_horario'],'id_grupo'=>$g,'id_salon'=>$s]]);
} catch (Throwable $e) {auroraFallo($e,$conn);}
