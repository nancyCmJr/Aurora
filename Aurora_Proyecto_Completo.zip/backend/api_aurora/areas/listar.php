<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'areas', 'listar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(405, "Método no permitido");
}

try {

    // ======================================
    // 2. CONSULTAR ÁREAS
    // ======================================

    $sql = "
        SELECT
            a.id_area,
            a.nombre,
            a.id_edificio,

            e.nombre AS nombre_edificio,
            e.estado AS estado_edificio,

            a.estado,

            COUNT(s.id_salon) AS total_salones,

            COALESCE(SUM(
                CASE
                    WHEN s.estado = 'Activo' THEN 1
                    ELSE 0
                END
            ), 0) AS salones_activos,

            COALESCE(SUM(
                CASE
                    WHEN s.estado = 'Inactivo' THEN 1
                    ELSE 0
                END
            ), 0) AS salones_inactivos

        FROM areas a

        INNER JOIN edificios e
            ON e.id_edificio = a.id_edificio

        LEFT JOIN salones s
            ON s.id_area = a.id_area

        GROUP BY
            a.id_area,
            a.nombre,
            a.id_edificio,
            e.nombre,
            e.estado,
            a.estado

        ORDER BY
            a.nombre ASC
    ";

    $resultado = $conn->query($sql);

    if (!$resultado) {
        throw new RuntimeException(
            "No fue posible ejecutar la consulta"
        );
    }

    // ======================================
    // 3. CONSTRUIR RESPUESTA
    // ======================================

    $areas = [];

    while ($fila = $resultado->fetch_assoc()) {

        $fila["id_area"] = (int)$fila["id_area"];
        $fila["id_edificio"] = (int)$fila["id_edificio"];

        $fila["total_salones"] =
            (int)$fila["total_salones"];

        $fila["salones_activos"] =
            (int)$fila["salones_activos"];

        $fila["salones_inactivos"] =
            (int)$fila["salones_inactivos"];

        // Indicador de consistencia
        $fila["edificio_consistente"] =
            $fila["estado"] !== "Activo" ||
            $fila["estado_edificio"] === "Activo";

        $fila["area_consistente"] =
            $fila["estado"] !== "Inactivo" ||
            $fila["salones_activos"] === 0;

        $areas[] = $fila;
    }

    $resultado->free();

    // ======================================
    // 4. RESPUESTA
    // ======================================

    responder(200, "Áreas consultadas correctamente", [
        "total" => count($areas),
        "areas" => $areas
    ]);

} catch (Throwable $e) {

    error_log(
        "Error en areas/listar.php: " .
        $e->getMessage()
    );

    responder(500, "Error al consultar las áreas");

} finally {

    $conn->close();
}

?>
