<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'areas', 'registrar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"));

if (!$data || !is_object($data)) {
    responder(400, "Los datos enviados no son válidos");
}

// ==========================================
// 3. VALIDAR CAMPOS
// ==========================================

if (
    !isset($data->nombre) ||
    !isset($data->id_edificio)
) {
    responder(400, "El nombre y el edificio son obligatorios");
}

if (!is_string($data->nombre)) {
    responder(400, "El nombre del área debe ser texto");
}

$nombre = trim($data->nombre);

if ($nombre === "") {
    responder(400, "El nombre del área es obligatorio");
}

if (mb_strlen($nombre, "UTF-8") > 120) {
    responder(400, "El nombre no puede superar los 120 caracteres");
}

if (
    !is_int($data->id_edificio) &&
    !(is_string($data->id_edificio) &&
      ctype_digit($data->id_edificio))
) {
    responder(400, "El ID del edificio debe ser un entero válido");
}

$id_edificio = (int)$data->id_edificio;

if ($id_edificio <= 0) {
    responder(400, "El edificio seleccionado no es válido");
}

// ==========================================
// 4. VALIDAR ESTADO
// ==========================================

$estado = $data->estado ?? "Activo";

if (
    !is_string($estado) ||
    !in_array($estado, ["Activo", "Inactivo"], true)
) {
    responder(400, "El estado del área no es válido");
}

// ==========================================
// 5. INICIAR TRANSACCIÓN
// ==========================================

try {

    $conn->begin_transaction();

    // ======================================
    // 6. VERIFICAR Y BLOQUEAR EDIFICIO
    // ======================================

    $sqlEdificio = "
        SELECT id_edificio, estado
        FROM edificios
        WHERE id_edificio = ?
        FOR UPDATE
    ";

    $stmtEdificio = $conn->prepare($sqlEdificio);
    $stmtEdificio->bind_param("i", $id_edificio);
    $stmtEdificio->execute();

    $edificio = $stmtEdificio->get_result()->fetch_assoc();
    $stmtEdificio->close();

    if (!$edificio) {
        throw new DomainException(
            "El edificio seleccionado no existe",
            404
        );
    }

    // ======================================
    // 7. VALIDAR ESTADO DEL EDIFICIO
    // ======================================

    if (
        $estado === "Activo" &&
        $edificio["estado"] !== "Activo"
    ) {
        throw new DomainException(
            "No se puede registrar un área activa en un edificio inactivo"
        );
    }

    // ======================================
    // 8. REGISTRAR ÁREA
    // ======================================

    $sql = "
        INSERT INTO areas (
            nombre,
            id_edificio,
            estado
        )
        VALUES (?, ?, ?)
    ";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "sis",
        $nombre,
        $id_edificio,
        $estado
    );

    $stmt->execute();

    $id_area = $conn->insert_id;

    $stmt->close();

    // ======================================
    // 9. CONFIRMAR TRANSACCIÓN
    // ======================================

    $conn->commit();

    responder(201, "Área registrada correctamente", [
        "id_area" => $id_area
    ]);

} catch (DomainException $e) {

    $conn->rollback();

    $codigo = $e->getCode();

    if (!in_array($codigo, [400, 404], true)) {
        $codigo = 400;
    }

    responder($codigo, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    $conn->rollback();

    error_log(
        "Error SQL en areas/registrar.php: " .
        $e->getMessage()
    );

    if ($e->getCode() == 1452) {
        responder(400, "El edificio seleccionado no es válido");
    }

    responder(500, "Error de base de datos al registrar el área");

} catch (Throwable $e) {

    $conn->rollback();

    error_log(
        "Error en areas/registrar.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al registrar el área");

} finally {

    $conn->close();
}

?>
