<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'areas', 'consultar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR ID
// ==========================================

$id_area = filter_var(
    $_GET["id_area"] ?? null,
    FILTER_VALIDATE_INT
);

if ($id_area === false || $id_area === null || $id_area <= 0) {
    responder(400, "El identificador del área es inválido");
}

$stmt = null;

try {

    // ======================================
    // 3. CONSULTAR ÁREA Y RELACIONES
    // ======================================

    $sql = "
        SELECT
            a.id_area,
            a.nombre,
            a.id_edificio,

            e.nombre AS nombre_edificio,
            e.estado AS estado_edificio,

            a.estado,

            COUNT(s.id_salon) AS total_salones,

            COALESCE(SUM(
                CASE
                    WHEN s.estado = 'Activo' THEN 1
                    ELSE 0
                END
            ), 0) AS salones_activos,

            COALESCE(SUM(
                CASE
                    WHEN s.estado = 'Inactivo' THEN 1
                    ELSE 0
                END
            ), 0) AS salones_inactivos

        FROM areas a

        INNER JOIN edificios e
            ON e.id_edificio = a.id_edificio

        LEFT JOIN salones s
            ON s.id_area = a.id_area

        WHERE a.id_area = ?

        GROUP BY
            a.id_area,
            a.nombre,
            a.id_edificio,
            e.nombre,
            e.estado,
            a.estado

        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_area);
    $stmt->execute();

    $area = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$area) {
        responder(404, "El área no existe");
    }

    // ======================================
    // 4. CONVERTIR TIPOS
    // ======================================

    $area["id_area"] = (int)$area["id_area"];
    $area["id_edificio"] = (int)$area["id_edificio"];

    $area["total_salones"] =
        (int)$area["total_salones"];

    $area["salones_activos"] =
        (int)$area["salones_activos"];

    $area["salones_inactivos"] =
        (int)$area["salones_inactivos"];

    // ======================================
    // 5. INDICADORES DE CONSISTENCIA
    // ======================================

    $area["edificio_consistente"] =
        $area["estado"] !== "Activo" ||
        $area["estado_edificio"] === "Activo";

    $area["area_consistente"] =
        $area["estado"] !== "Inactivo" ||
        $area["salones_activos"] === 0;

    // ======================================
    // 6. RESPUESTA
    // ======================================

    responder(200, "Área consultada correctamente", [
        "area" => $area
    ]);

} catch (Throwable $e) {

    error_log(
        "Error en areas/consultar.php: " .
        $e->getMessage()
    );

    responder(500, "Error al consultar el área");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
