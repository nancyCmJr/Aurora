<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'areas', 'actualizar');


header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ]), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"));

if (
    !$data ||
    !is_object($data)
) {
    responder(400, "Los datos enviados no son válidos");
}

// ==========================================
// 3. VALIDAR CAMPOS
// ==========================================

if (
    !isset($data->id_area) ||
    !isset($data->nombre) ||
    !isset($data->id_edificio) ||
    !isset($data->estado)
) {
    responder(400, "Todos los campos son obligatorios");
}

if (
    !is_int($data->id_area) &&
    !(is_string($data->id_area) &&
      ctype_digit($data->id_area))
) {
    responder(400, "El ID del área debe ser un entero válido");
}

if (
    !is_int($data->id_edificio) &&
    !(is_string($data->id_edificio) &&
      ctype_digit($data->id_edificio))
) {
    responder(400, "El ID del edificio debe ser un entero válido");
}

$id_area = (int)$data->id_area;
$id_edificio = (int)$data->id_edificio;

if ($id_area <= 0 || $id_edificio <= 0) {
    responder(400, "Los identificadores deben ser mayores a cero");
}

if (!is_string($data->nombre)) {
    responder(400, "El nombre del área debe ser texto");
}

$nombre = trim($data->nombre);

if ($nombre === "") {
    responder(400, "El nombre del área es obligatorio");
}

if (mb_strlen($nombre, "UTF-8") > 120) {
    responder(400, "El nombre no puede superar los 120 caracteres");
}

$estado = $data->estado;

if (
    !is_string($estado) ||
    !in_array($estado, ["Activo", "Inactivo"], true)
) {
    responder(400, "El estado del área no es válido");
}

// ==========================================
// 4. INICIAR TRANSACCIÓN
// ==========================================

try {

    $conn->begin_transaction();

    // ======================================
    // 5. VERIFICAR Y BLOQUEAR ÁREA
    // ======================================

    $sqlArea = "
        SELECT id_area, id_edificio, estado
        FROM areas
        WHERE id_area = ?
        FOR UPDATE
    ";

    $stmtArea = $conn->prepare($sqlArea);
    $stmtArea->bind_param("i", $id_area);
    $stmtArea->execute();

    $area = $stmtArea->get_result()->fetch_assoc();
    $stmtArea->close();

    if (!$area) {
        throw new DomainException(
            "El área que intenta actualizar no existe",
            404
        );
    }

    // ======================================
    // 6. VERIFICAR Y BLOQUEAR EDIFICIO
    // ======================================

    $sqlEdificio = "
        SELECT id_edificio, estado
        FROM edificios
        WHERE id_edificio = ?
        FOR UPDATE
    ";

    $stmtEdificio = $conn->prepare($sqlEdificio);
    $stmtEdificio->bind_param("i", $id_edificio);
    $stmtEdificio->execute();

    $edificio = $stmtEdificio->get_result()->fetch_assoc();
    $stmtEdificio->close();

    if (!$edificio) {
        throw new DomainException(
            "El edificio seleccionado no existe",
            404
        );
    }

    // ======================================
    // 7. VALIDAR ESTADO DEL EDIFICIO
    // ======================================

    if (
        $estado === "Activo" &&
        $edificio["estado"] !== "Activo"
    ) {
        throw new DomainException(
            "No se puede activar un área perteneciente a un edificio inactivo"
        );
    }

    // ======================================
    // 8. VERIFICAR SALONES ASOCIADOS
    // ======================================

    $sqlSalones = "
        SELECT
            COUNT(*) AS total_salones,
            COALESCE(SUM(
                CASE
                    WHEN estado = 'Activo' THEN 1
                    ELSE 0
                END
            ), 0) AS salones_activos
        FROM salones
        WHERE id_area = ?
    ";

    $stmtSalones = $conn->prepare($sqlSalones);
    $stmtSalones->bind_param("i", $id_area);
    $stmtSalones->execute();

    $salones = $stmtSalones->get_result()->fetch_assoc();
    $stmtSalones->close();

    $totalSalones = (int)$salones["total_salones"];
    $salonesActivos = (int)$salones["salones_activos"];

    // ======================================
    // 9. EVITAR CAMBIO DE EDIFICIO
    // ======================================

    if (
        (int)$area["id_edificio"] !== $id_edificio &&
        $totalSalones > 0
    ) {
        throw new DomainException(
            "No se puede cambiar el edificio del área porque tiene salones asociados"
        );
    }

    // ======================================
    // 10. EVITAR DESACTIVACIÓN INCONSISTENTE
    // ======================================

    if (
        $estado === "Inactivo" &&
        $salonesActivos > 0
    ) {
        throw new DomainException(
            "No se puede desactivar el área porque tiene salones activos"
        );
    }

    // ======================================
    // 11. ACTUALIZAR ÁREA
    // ======================================

    $sqlActualizar = "
        UPDATE areas
        SET
            nombre = ?,
            id_edificio = ?,
            estado = ?
        WHERE id_area = ?
    ";

    $stmtActualizar = $conn->prepare($sqlActualizar);

    $stmtActualizar->bind_param(
        "sisi",
        $nombre,
        $id_edificio,
        $estado,
        $id_area
    );

    $stmtActualizar->execute();
    $stmtActualizar->close();

    // ======================================
    // 12. CONFIRMAR TRANSACCIÓN
    // ======================================

    $conn->commit();

    responder(200, "Área actualizada correctamente");

} catch (DomainException $e) {

    $conn->rollback();

    $codigo = $e->getCode();

    if (!in_array($codigo, [400, 404], true)) {
        $codigo = 400;
    }

    responder($codigo, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    $conn->rollback();

    error_log(
        "Error SQL en areas/actualizar.php: " .
        $e->getMessage()
    );

    if ($e->getCode() == 1452) {
        responder(400, "El edificio seleccionado no es válido");
    }

    responder(500, "Error de base de datos al actualizar el área");

} catch (Throwable $e) {

    $conn->rollback();

    error_log(
        "Error en areas/actualizar.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al actualizar el área");

} finally {

    $conn->close();
}

?>
