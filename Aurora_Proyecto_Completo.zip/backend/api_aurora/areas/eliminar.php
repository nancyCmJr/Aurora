<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'areas', 'eliminar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje)
{
    http_response_code($codigo);

    echo json_encode([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"));

if (!$data || !is_object($data)) {
    responder(400, "Los datos enviados no son válidos");
}

// ==========================================
// 3. VALIDAR IDENTIFICADOR
// ==========================================

if (!isset($data->id_area)) {
    responder(400, "El identificador del área es obligatorio");
}

if (
    !is_int($data->id_area) &&
    !(is_string($data->id_area) &&
      ctype_digit($data->id_area))
) {
    responder(400, "El identificador del área debe ser un entero válido");
}

$id_area = (int)$data->id_area;

if ($id_area <= 0) {
    responder(400, "El identificador del área debe ser mayor a cero");
}

// ==========================================
// 4. INICIAR TRANSACCIÓN
// ==========================================

try {

    $conn->begin_transaction();

    // ======================================
    // 5. BLOQUEAR Y CONSULTAR ÁREA
    // ======================================

    $sqlArea = "
        SELECT id_area, nombre, estado
        FROM areas
        WHERE id_area = ?
        FOR UPDATE
    ";

    $stmtArea = $conn->prepare($sqlArea);
    $stmtArea->bind_param("i", $id_area);
    $stmtArea->execute();

    $area = $stmtArea->get_result()->fetch_assoc();
    $stmtArea->close();

    if (!$area) {
        throw new DomainException(
            "El área no existe",
            404
        );
    }

    // ======================================
    // 6. VERIFICAR ESTADO ACTUAL
    // ======================================

    if ($area["estado"] === "Inactivo") {

        $conn->commit();

        responder(200, "El área ya se encontraba inactiva");
    }

    // ======================================
    // 7. VERIFICAR SALONES ACTIVOS
    // ======================================

    $sqlSalones = "
        SELECT COUNT(*) AS total
        FROM salones
        WHERE id_area = ?
          AND estado = 'Activo'
    ";

    $stmtSalones = $conn->prepare($sqlSalones);
    $stmtSalones->bind_param("i", $id_area);
    $stmtSalones->execute();

    $resultado = $stmtSalones->get_result()->fetch_assoc();
    $stmtSalones->close();

    $totalSalonesActivos = (int)$resultado["total"];

    if ($totalSalonesActivos > 0) {

        throw new DomainException(
            "No se puede desactivar el área porque tiene " .
            $totalSalonesActivos .
            " salón(es) activo(s). Desactive primero los salones relacionados."
        );
    }

    // ======================================
    // 8. REALIZAR BAJA LÓGICA
    // ======================================

    $sqlActualizar = "
        UPDATE areas
        SET estado = 'Inactivo'
        WHERE id_area = ?
          AND estado = 'Activo'
    ";

    $stmtActualizar = $conn->prepare($sqlActualizar);
    $stmtActualizar->bind_param("i", $id_area);
    $stmtActualizar->execute();

    $stmtActualizar->close();

    // ======================================
    // 9. CONFIRMAR TRANSACCIÓN
    // ======================================

    $conn->commit();

    responder(200, "Área desactivada correctamente");

} catch (DomainException $e) {

    $conn->rollback();

    $codigo = $e->getCode();

    if (!in_array($codigo, [400, 404, 409], true)) {
        $codigo = 409;
    }

    responder($codigo, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    $conn->rollback();

    error_log(
        "Error SQL en areas/eliminar.php: " .
        $e->getMessage()
    );

    responder(500, "Error de base de datos al desactivar el área");

} catch (Throwable $e) {

    $conn->rollback();

    error_log(
        "Error en areas/eliminar.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al desactivar el área");

} finally {

    $conn->close();
}

?>
