<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reticulas', 'listar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(405, "Método no permitido");
}

try {

    // ======================================
    // 2. CONSULTAR RETÍCULAS
    // ======================================

    $sql = "
        SELECT
            r.id_reticula,
            r.anio,
            r.id_carrera,

            c.nombre AS nombre_carrera,
            c.tipo AS tipo_carrera,
            c.total_creditos AS creditos_carrera,
            c.estado AS estado_carrera,

            r.estado,

            COUNT(rm.id_materia) AS total_materias,

            COALESCE(SUM(m.creditos), 0)
                AS creditos_asignados,

            COALESCE(SUM(
                CASE
                    WHEN m.estado = 'Inactiva' THEN 1
                    ELSE 0
                END
            ), 0) AS materias_inactivas,

            (
                SELECT COUNT(*)
                FROM reticulas rv
                WHERE rv.id_carrera = r.id_carrera
                  AND rv.estado = 'Vigente'
            ) AS total_reticulas_vigentes,

            (
                SELECT COUNT(*)
                FROM reticula_materia rm2
                INNER JOIN materias m2
                    ON m2.id_materia = rm2.id_materia
                WHERE rm2.id_reticula = r.id_reticula
                  AND m2.id_materia_requisito IS NOT NULL
                  AND NOT EXISTS (
                      SELECT 1
                      FROM reticula_materia rm3
                      WHERE rm3.id_reticula = r.id_reticula
                        AND rm3.id_materia = m2.id_materia_requisito
                  )
            ) AS requisitos_no_asignados

        FROM reticulas r

        INNER JOIN carreras c
            ON c.id_carrera = r.id_carrera

        LEFT JOIN reticula_materia rm
            ON rm.id_reticula = r.id_reticula

        LEFT JOIN materias m
            ON m.id_materia = rm.id_materia

        GROUP BY
            r.id_reticula,
            r.anio,
            r.id_carrera,
            c.nombre,
            c.tipo,
            c.total_creditos,
            c.estado,
            r.estado

        ORDER BY
            r.anio DESC,
            c.nombre ASC
    ";

    $resultado = $conn->query($sql);

    if (!$resultado) {
        throw new RuntimeException(
            "No fue posible ejecutar la consulta"
        );
    }

    // ======================================
    // 3. CONSTRUIR RESPUESTA
    // ======================================

    $reticulas = [];

    while ($fila = $resultado->fetch_assoc()) {

        $fila["id_reticula"] = (int)$fila["id_reticula"];
        $fila["anio"] = (int)$fila["anio"];
        $fila["id_carrera"] = (int)$fila["id_carrera"];

        $fila["creditos_carrera"] =
            (int)$fila["creditos_carrera"];

        $fila["total_materias"] =
            (int)$fila["total_materias"];

        $fila["creditos_asignados"] =
            (int)$fila["creditos_asignados"];

        $fila["materias_inactivas"] =
            (int)$fila["materias_inactivas"];

        $fila["total_reticulas_vigentes"] =
            (int)$fila["total_reticulas_vigentes"];

        $fila["requisitos_no_asignados"] =
            (int)$fila["requisitos_no_asignados"];

        $fila["creditos_disponibles"] =
            $fila["creditos_carrera"] -
            $fila["creditos_asignados"];

        $fila["tiene_otra_reticula_vigente"] =
            $fila["total_reticulas_vigentes"] > 0 &&
            $fila["estado"] !== "Vigente";

        $fila["cumple_creditos"] =
            $fila["creditos_asignados"] <=
            $fila["creditos_carrera"];

        $reticulas[] = $fila;
    }

    $resultado->free();

    // ======================================
    // 4. RESPUESTA
    // ======================================

    responder(200, "Retículas consultadas correctamente", [
        "total" => count($reticulas),
        "reticulas" => $reticulas
    ]);

} catch (Throwable $e) {

    error_log(
        "Error en reticulas/listar.php: " .
        $e->getMessage()
    );

    responder(500, "Error al consultar las retículas");

} finally {

    $conn->close();
}

?>
