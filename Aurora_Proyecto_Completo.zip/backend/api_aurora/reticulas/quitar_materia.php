<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reticulas', 'quitar_materia');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. RECIBIR Y VALIDAR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "JSON inválido");
}

$id_reticula = filter_var(
    $data["id_reticula"] ?? null,
    FILTER_VALIDATE_INT
);

$id_materia = filter_var(
    $data["id_materia"] ?? null,
    FILTER_VALIDATE_INT
);

if (
    $id_reticula === false ||
    $id_reticula === null ||
    $id_reticula <= 0
) {
    responder(400, "ID de retícula inválido");
}

if (
    $id_materia === false ||
    $id_materia === null ||
    $id_materia <= 0
) {
    responder(400, "ID de materia inválido");
}

// ==========================================
// 3. INICIAR TRANSACCIÓN
// ==========================================

$transaccion = false;
$stmt = null;

try {

    $conn->begin_transaction();
    $transaccion = true;
    require_once __DIR__ . '/../lib/academico.php';
    auroraVerificarReticulaEditable($conn, (int)$id_reticula);

    // ======================================
    // 4. BLOQUEAR Y VALIDAR RETÍCULA
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            id_reticula,
            estado
        FROM reticulas
        WHERE id_reticula = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_reticula);
    $stmt->execute();

    $reticula = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$reticula) {
        throw new DomainException("La retícula no existe");
    }

    if ($reticula["estado"] !== "No vigente") {
        throw new DomainException(
            "No se pueden retirar materias de una retícula vigente"
        );
    }

    // ======================================
    // 5. VERIFICAR ASIGNACIÓN
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            rm.id_materia,
            rm.semestre,
            m.clave_materia,
            m.nombre
        FROM reticula_materia rm
        INNER JOIN materias m
            ON m.id_materia = rm.id_materia
        WHERE rm.id_reticula = ?
          AND rm.id_materia = ?
        FOR UPDATE
    ");

    $stmt->bind_param("ii", $id_reticula, $id_materia);
    $stmt->execute();

    $asignacion = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$asignacion) {
        throw new DomainException(
            "La materia no está asignada a esta retícula"
        );
    }

    // ======================================
    // 6. VERIFICAR MATERIAS DEPENDIENTES
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            m.id_materia,
            m.clave_materia,
            m.nombre,
            rm.semestre
        FROM reticula_materia rm
        INNER JOIN materias m
            ON m.id_materia = rm.id_materia
        WHERE rm.id_reticula = ?
          AND m.id_materia_requisito = ?
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->bind_param("ii", $id_reticula, $id_materia);
    $stmt->execute();

    $dependencia = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if ($dependencia) {
        throw new DomainException(
            "No se puede retirar la materia porque es prerrequisito de " .
            $dependencia["clave_materia"] . " - " .
            $dependencia["nombre"] .
            ", asignada en el semestre " .
            $dependencia["semestre"]
        );
    }

    // ======================================
    // 7. VERIFICAR GRUPOS PLANEADOS O ABIERTOS
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            id_grupo,
            clave_grupo,
            estado
        FROM grupos
        WHERE id_materia = ?
          AND estado IN ('Planeado', 'Abierto')
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_materia);
    $stmt->execute();

    $grupo = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if ($grupo) {
        throw new DomainException(
            "No se puede retirar la materia porque tiene el grupo " .
            $grupo["clave_grupo"] .
            " en estado " . $grupo["estado"]
        );
    }

    // ======================================
    // 8. VERIFICAR HISTORIAL EN KARDEX
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            k.id_kardex,
            k.numero_control,
            g.clave_grupo
        FROM kardex k
        INNER JOIN grupos g
            ON g.id_grupo = k.id_grupo
        WHERE g.id_materia = ?
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_materia);
    $stmt->execute();

    $registroKardex = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if ($registroKardex) {
        throw new DomainException(
            "No se puede retirar la materia porque tiene registros " .
            "académicos en el kardex del alumno " .
            $registroKardex["numero_control"]
        );
    }

    // ======================================
    // 9. ELIMINAR ÚNICAMENTE LA ASIGNACIÓN
    // ======================================

    $stmt = $conn->prepare("
        DELETE FROM reticula_materia
        WHERE id_reticula = ?
          AND id_materia = ?
    ");

    $stmt->bind_param("ii", $id_reticula, $id_materia);
    $stmt->execute();

    if ($stmt->affected_rows !== 1) {
        throw new DomainException(
            "No fue posible retirar la materia de la retícula"
        );
    }

    $stmt->close();
    $stmt = null;

    // ======================================
    // 10. CONFIRMAR TRANSACCIÓN
    // ======================================

    $conn->commit();
    $transaccion = false;

    responder(200, "Materia retirada correctamente de la retícula", [
        "id_reticula" => (int)$id_reticula,
        "id_materia" => (int)$id_materia,
        "clave_materia" => $asignacion["clave_materia"],
        "nombre_materia" => $asignacion["nombre"],
        "semestre_anterior" => (int)$asignacion["semestre"]
    ]);

} catch (DomainException $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    responder(409, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log(
        "Error SQL en reticulas/quitar_materia.php: " .
        $e->getMessage()
    );

    responder(500, "Error de base de datos al retirar la materia");

} catch (Throwable $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log(
        "Error interno en reticulas/quitar_materia.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al retirar la materia");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
