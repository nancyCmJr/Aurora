<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reticulas', 'validar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR ID
// ==========================================

$id_reticula = filter_var(
    $_GET["id_reticula"] ?? null,
    FILTER_VALIDATE_INT
);

if (
    $id_reticula === false ||
    $id_reticula === null ||
    $id_reticula <= 0
) {
    responder(400, "Debes proporcionar un ID de retícula válido");
}

$stmt = null;

try {

    // ======================================
    // 3. CONSULTAR RETÍCULA Y CARRERA
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            r.id_reticula,
            r.anio,
            r.estado AS estado_reticula,
            c.id_carrera,
            c.nombre AS carrera,
            c.tipo AS tipo_carrera,
            c.total_creditos,
            c.estado AS estado_carrera
        FROM reticulas r
        INNER JOIN carreras c
            ON c.id_carrera = r.id_carrera
        WHERE r.id_reticula = ?
    ");

    $stmt->bind_param("i", $id_reticula);
    $stmt->execute();

    $reticula = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$reticula) {
        responder(404, "No se encontró la retícula");
    }

    $reticula["id_reticula"] = (int)$reticula["id_reticula"];
    $reticula["anio"] = (int)$reticula["anio"];
    $reticula["id_carrera"] = (int)$reticula["id_carrera"];
    $reticula["total_creditos"] = (int)$reticula["total_creditos"];

    // ======================================
    // 4. CONSULTAR MATERIAS
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            rm.id_materia,
            rm.semestre,

            m.clave_materia,
            m.nombre AS materia,
            m.creditos,
            m.estado AS estado_materia,
            m.id_materia_requisito,

            requisito.clave_materia AS clave_requisito,
            requisito.nombre AS nombre_requisito,
            requisito.estado AS estado_requisito,

            rm_requisito.semestre AS semestre_requisito

        FROM reticula_materia rm

        INNER JOIN materias m
            ON m.id_materia = rm.id_materia

        LEFT JOIN materias requisito
            ON requisito.id_materia = m.id_materia_requisito

        LEFT JOIN reticula_materia rm_requisito
            ON rm_requisito.id_reticula = rm.id_reticula
            AND rm_requisito.id_materia = m.id_materia_requisito

        WHERE rm.id_reticula = ?

        ORDER BY rm.semestre ASC, m.nombre ASC
    ");

    $stmt->bind_param("i", $id_reticula);
    $stmt->execute();

    $resultado = $stmt->get_result();

    $materias = [];
    $errores = [];
    $advertencias = [];

    $creditosAsignados = 0;

    // Mapa de materias de la retícula para detectar ciclos.
    $mapaMaterias = [];

    while ($fila = $resultado->fetch_assoc()) {

        $idMateria = (int)$fila["id_materia"];

        $fila["id_materia"] = $idMateria;
        $fila["semestre"] = (int)$fila["semestre"];
        $fila["creditos"] = (int)$fila["creditos"];

        $fila["id_materia_requisito"] =
            $fila["id_materia_requisito"] !== null
                ? (int)$fila["id_materia_requisito"]
                : null;

        $fila["semestre_requisito"] =
            $fila["semestre_requisito"] !== null
                ? (int)$fila["semestre_requisito"]
                : null;

        $creditosAsignados += $fila["creditos"];

        $mapaMaterias[$idMateria] = [
            "id_materia_requisito" =>
                $fila["id_materia_requisito"],
            "nombre" => $fila["materia"]
        ];

        // ==================================
        // 5. VALIDAR ESTADO DE MATERIA
        // ==================================

        if ($fila["estado_materia"] !== "Activa") {

            $errores[] = [
                "tipo" => "Materia inactiva",
                "id_materia" => $idMateria,
                "materia" => $fila["materia"],
                "mensaje" => "La materia está inactiva"
            ];
        }

        // ==================================
        // 6. VALIDAR PRERREQUISITOS
        // ==================================

        if ($fila["id_materia_requisito"] !== null) {

            if ($fila["estado_requisito"] === null) {

                $errores[] = [
                    "tipo" => "Requisito inexistente",
                    "id_materia" => $idMateria,
                    "materia" => $fila["materia"],
                    "mensaje" => "El prerrequisito referenciado no existe"
                ];

            } elseif ($fila["estado_requisito"] !== "Activa") {

                $errores[] = [
                    "tipo" => "Requisito inactivo",
                    "id_materia" => $idMateria,
                    "materia" => $fila["materia"],
                    "requisito" => $fila["nombre_requisito"],
                    "mensaje" => "El prerrequisito está inactivo"
                ];
            }

            if ($fila["semestre_requisito"] === null) {

                $advertencias[] = [
                    "tipo" => "Requisito no asignado",
                    "id_materia" => $idMateria,
                    "materia" => $fila["materia"],
                    "requisito" => $fila["nombre_requisito"],
                    "mensaje" => "El requisito no está asignado a esta retícula"
                ];

            } elseif (
                $fila["semestre_requisito"] >= $fila["semestre"]
            ) {

                $errores[] = [
                    "tipo" => "Orden de semestres incorrecto",
                    "id_materia" => $idMateria,
                    "materia" => $fila["materia"],
                    "requisito" => $fila["nombre_requisito"],
                    "mensaje" => "El requisito debe estar en un semestre anterior"
                ];
            }
        }

        $materias[] = $fila;
    }

    $stmt->close();
    $stmt = null;

    // ======================================
    // 7. VALIDAR RETÍCULA SIN MATERIAS
    // ======================================

    if (count($materias) === 0) {

        $errores[] = [
            "tipo" => "Retícula vacía",
            "mensaje" => "La retícula no tiene materias asignadas"
        ];
    }

    // ======================================
    // 8. DETECTAR CICLOS INDIRECTOS
    // ======================================

    foreach ($mapaMaterias as $idMateria => $datos) {

        $visitados = [];
        $actual = $idMateria;

        while ($actual !== null) {

            if (isset($visitados[$actual])) {

                $errores[] = [
                    "tipo" => "Ciclo de prerrequisitos",
                    "id_materia" => $idMateria,
                    "materia" => $mapaMaterias[$idMateria]["nombre"],
                    "mensaje" => "Se detectó un ciclo indirecto en la cadena de prerrequisitos"
                ];

                break;
            }

            $visitados[$actual] = true;

            if (!isset($mapaMaterias[$actual])) {
                break;
            }

            $actual =
                $mapaMaterias[$actual]["id_materia_requisito"];
        }
    }

    // ======================================
    // 9. VALIDAR CRÉDITOS
    // ======================================

    $creditosPermitidos = (int)$reticula["total_creditos"];

    if ($creditosAsignados > $creditosPermitidos) {

        $errores[] = [
            "tipo" => "Créditos excedidos",
            "mensaje" => "Los créditos asignados exceden el total permitido para la carrera",
            "creditos_asignados" => $creditosAsignados,
            "creditos_carrera" => $creditosPermitidos
        ];
    }

    // ======================================
    // 10. VALIDAR ESTADO DE CARRERA
    // ======================================

    if ($reticula["estado_carrera"] !== "Activa") {

        $errores[] = [
            "tipo" => "Carrera inactiva",
            "mensaje" => "La carrera asociada a esta retícula está inactiva"
        ];
    }

    // ======================================
    // 11. VALIDAR ESTADO DE RETÍCULA
    // ======================================

    if ($reticula["estado_reticula"] !== "Vigente") {

        $advertencias[] = [
            "tipo" => "Retícula no vigente",
            "mensaje" => "La retícula no está vigente"
        ];
    }

    // ======================================
    // 12. RESPUESTA FINAL
    // ======================================

    responder(200, "Validación de retícula completada", [

        "valida" => count($errores) === 0,

        "reticula" => $reticula,

        "resumen" => [
            "total_materias" => count($materias),
            "creditos_asignados" => $creditosAsignados,
            "creditos_carrera" => $creditosPermitidos,
            "creditos_disponibles" =>
                $creditosPermitidos - $creditosAsignados,

            "total_errores" => count($errores),
            "total_advertencias" => count($advertencias)
        ],

        "materias" => $materias,

        "errores" => $errores,

        "advertencias" => $advertencias
    ]);

} catch (mysqli_sql_exception $e) {

    error_log(
        "Error SQL en reticulas/validar.php: " .
        $e->getMessage()
    );

    responder(500, "Error de base de datos al validar la retícula");

} catch (Throwable $e) {

    error_log(
        "Error interno en reticulas/validar.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al validar la retícula");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
