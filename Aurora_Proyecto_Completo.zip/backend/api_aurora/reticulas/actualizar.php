<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reticulas', 'actualizar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. RECIBIR Y VALIDAR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "JSON inválido");
}

foreach (["id_reticula", "anio", "id_carrera", "estado"] as $campo) {
    if (!array_key_exists($campo, $data)) {
        responder(400, "Falta el campo obligatorio: " . $campo);
    }
}

$id = filter_var($data["id_reticula"], FILTER_VALIDATE_INT);
$anio = filter_var($data["anio"], FILTER_VALIDATE_INT);
$id_carrera = filter_var($data["id_carrera"], FILTER_VALIDATE_INT);
$estado = $data["estado"];

if (
    $id === false || $id === null || $id <= 0 ||
    $anio === false || $anio === null ||
    $anio < 1901 || $anio > 2155 ||
    $id_carrera === false || $id_carrera === null ||
    $id_carrera <= 0 ||
    !is_string($estado) ||
    !in_array($estado, ["Vigente", "No vigente"], true)
) {
    responder(400, "Verifica los datos de la retícula");
}

$transaccion = false;
$stmt = null;

try {

    // ======================================
    // 3. INICIAR TRANSACCIÓN
    // ======================================

    $conn->begin_transaction();
    $transaccion = true;

    // ======================================
    // 4. BLOQUEAR Y CONSULTAR RETÍCULA
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            id_reticula,
            anio,
            id_carrera,
            estado
        FROM reticulas
        WHERE id_reticula = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $reticulaActual = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$reticulaActual) {
        throw new DomainException("La retícula no existe");
    }

    $idCarreraAnterior = (int)$reticulaActual["id_carrera"];
    if (((int)$reticulaActual['anio'] !== (int)$anio ||
         (int)$reticulaActual['id_carrera'] !== (int)$id_carrera)) {
        require_once __DIR__ . '/../lib/academico.php';
        auroraVerificarReticulaEditable($conn, (int)$id);
    }


    // ======================================
    // 5. VERIFICAR CARRERA DESTINO
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            id_carrera,
            nombre,
            total_creditos,
            estado
        FROM carreras
        WHERE id_carrera = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_carrera);
    $stmt->execute();

    $carrera = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$carrera) {
        throw new DomainException(
            "La carrera seleccionada no existe"
        );
    }

    // ======================================
    // 6. VERIFICAR CAMBIO DE CARRERA
    // ======================================

    $cambioCarrera = $id_carrera !== $idCarreraAnterior;

    if ($cambioCarrera) {

        $stmt = $conn->prepare("
            SELECT COUNT(*) AS total
            FROM reticula_materia
            WHERE id_reticula = ?
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $asignaciones = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if ((int)$asignaciones["total"] > 0) {
            throw new DomainException(
                "No se puede cambiar la carrera porque la retícula ya tiene materias asignadas"
            );
        }
    }

    // ======================================
    // 7. EVITAR DUPLICADOS
    // ======================================

    $stmt = $conn->prepare("
        SELECT id_reticula
        FROM reticulas
        WHERE anio = ?
          AND id_carrera = ?
          AND id_reticula <> ?
        LIMIT 1
    ");

    $stmt->bind_param("iii", $anio, $id_carrera, $id);
    $stmt->execute();

    $duplicada = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if ($duplicada) {
        throw new DomainException(
            "Ya existe otra retícula para esa carrera y año"
        );
    }

    // ======================================
    // 8. VALIDAR ESTADO VIGENTE
    // ======================================

    if ($estado === "Vigente") {

        if ($carrera["estado"] !== "Activa") {
            throw new DomainException(
                "No se puede establecer como vigente una retícula de una carrera inactiva"
            );
        }

        // Comprobar que no exista otra retícula vigente.
        $stmt = $conn->prepare("
            SELECT id_reticula, anio
            FROM reticulas
            WHERE id_carrera = ?
              AND estado = 'Vigente'
              AND id_reticula <> ?
            LIMIT 1
            FOR UPDATE
        ");

        $stmt->bind_param("ii", $id_carrera, $id);
        $stmt->execute();

        $otraVigente = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if ($otraVigente) {
            throw new DomainException(
                "La carrera ya tiene otra retícula vigente del año " .
                $otraVigente["anio"]
            );
        }

        // ==================================
        // 9. VALIDAR MATERIAS DE LA RETÍCULA
        // ==================================

        $stmt = $conn->prepare("
            SELECT
                COUNT(*) AS total_materias,
                COALESCE(SUM(m.creditos), 0) AS creditos_asignados,
                COALESCE(SUM(
                    CASE
                        WHEN m.estado <> 'Activa' THEN 1
                        ELSE 0
                    END
                ), 0) AS materias_inactivas
            FROM reticula_materia rm
            INNER JOIN materias m
                ON m.id_materia = rm.id_materia
            WHERE rm.id_reticula = ?
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $resumen = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if ((int)$resumen["total_materias"] === 0) {
            throw new DomainException(
                "No se puede activar una retícula sin materias asignadas"
            );
        }

        if ((int)$resumen["materias_inactivas"] > 0) {
            throw new DomainException(
                "La retícula contiene materias inactivas"
            );
        }

        if (
            (int)$resumen["creditos_asignados"] >
            (int)$carrera["total_creditos"]
        ) {
            throw new DomainException(
                "Los créditos asignados exceden el total permitido para la carrera"
            );
        }

        // ==================================
        // 10. VALIDAR PRERREQUISITOS
        // ==================================

        $stmt = $conn->prepare("
            SELECT
                m.clave_materia,
                m.nombre,
                requisito.nombre AS nombre_requisito,
                requisito.estado AS estado_requisito,
                rm_requisito.semestre AS semestre_requisito,
                rm.semestre AS semestre_materia

            FROM reticula_materia rm

            INNER JOIN materias m
                ON m.id_materia = rm.id_materia

            LEFT JOIN materias requisito
                ON requisito.id_materia = m.id_materia_requisito

            LEFT JOIN reticula_materia rm_requisito
                ON rm_requisito.id_reticula = rm.id_reticula
                AND rm_requisito.id_materia = m.id_materia_requisito

            WHERE rm.id_reticula = ?
              AND m.id_materia_requisito IS NOT NULL
              AND (
                    requisito.id_materia IS NULL
                    OR requisito.estado <> 'Activa'
                    OR rm_requisito.id_materia IS NULL
                    OR rm_requisito.semestre >= rm.semestre
              )

            LIMIT 1
        ");

        $stmt->bind_param("i", $id);
        $stmt->execute();

        $requisitoIncorrecto = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if ($requisitoIncorrecto) {
            throw new DomainException(
                "La materia " .
                $requisitoIncorrecto["clave_materia"] .
                " tiene un prerrequisito ausente, inactivo o asignado en un semestre incorrecto"
            );
        }
    }

    // ======================================
    // 11. ACTUALIZAR RETÍCULA
    // ======================================

    $stmt = $conn->prepare("
        UPDATE reticulas
        SET
            anio = ?,
            id_carrera = ?,
            estado = ?
        WHERE id_reticula = ?
    ");

    $stmt->bind_param(
        "iisi",
        $anio,
        $id_carrera,
        $estado,
        $id
    );

    $stmt->execute();

    $stmt->close();
    $stmt = null;

    // ======================================
    // 12. CONFIRMAR TRANSACCIÓN
    // ======================================

    $conn->commit();
    $transaccion = false;

    responder(200, "Retícula actualizada correctamente", [
        "id_reticula" => (int)$id,
        "anio" => (int)$anio,
        "id_carrera" => (int)$id_carrera,
        "estado" => $estado
    ]);

} catch (DomainException $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    responder(409, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log(
        "Error SQL en reticulas/actualizar.php: " .
        $e->getMessage()
    );

    responder(500, "Error de base de datos al actualizar la retícula");

} catch (Throwable $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log(
        "Error interno en reticulas/actualizar.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al actualizar la retícula");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
