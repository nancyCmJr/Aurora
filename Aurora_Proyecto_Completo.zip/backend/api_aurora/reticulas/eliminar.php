<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reticulas', 'eliminar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. RECIBIR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "JSON inválido");
}

$id = filter_var(
    $data["id_reticula"] ?? null,
    FILTER_VALIDATE_INT
);

if ($id === false || $id === null || $id <= 0) {
    responder(400, "ID de retícula inválido");
}

$transaccion = false;
$stmt = null;

try {

    // ======================================
    // 3. INICIAR TRANSACCIÓN
    // ======================================

    $conn->begin_transaction();
    $transaccion = true;

    // ======================================
    // 4. BLOQUEAR Y CONSULTAR RETÍCULA
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            id_reticula,
            id_carrera,
            anio,
            estado
        FROM reticulas
        WHERE id_reticula = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $reticula = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$reticula) {
        throw new DomainException("Retícula no encontrada");
    }

    // ======================================
    // 5. COMPROBAR ESTADO ACTUAL
    // ======================================

    if ($reticula["estado"] === "No vigente") {

        $conn->commit();
        $transaccion = false;

        responder(200, "La retícula ya se encuentra como no vigente", [
            "id_reticula" => (int)$id,
            "estado" => "No vigente"
        ]);
    }

    $id_carrera = (int)$reticula["id_carrera"];

    // ======================================
    // 6. BLOQUEAR CARRERA
    // ======================================

    $stmt = $conn->prepare("
        SELECT id_carrera, nombre
        FROM carreras
        WHERE id_carrera = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_carrera);
    $stmt->execute();

    $carrera = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$carrera) {
        throw new DomainException(
            "No se encontró la carrera asociada a la retícula"
        );
    }

    // ======================================
    // 7. BUSCAR OTRA RETÍCULA VIGENTE
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            id_reticula,
            anio
        FROM reticulas
        WHERE id_carrera = ?
          AND estado = 'Vigente'
          AND id_reticula <> ?
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->bind_param("ii", $id_carrera, $id);
    $stmt->execute();

    $otraVigente = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    // ======================================
    // 8. PROTEGER INSCRIPCIONES ACTIVAS
    // ======================================

    if (!$otraVigente) {

        $stmt = $conn->prepare("
            SELECT COUNT(*) AS total
            FROM inscripciones i
            INNER JOIN alumnos a
                ON a.numero_control = i.numero_control
            WHERE i.id_carrera = ?
              AND i.estado = 'En curso'
              AND a.estado = 'Activo'
        ");

        $stmt->bind_param("i", $id_carrera);
        $stmt->execute();

        $resultado = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if ((int)$resultado["total"] > 0) {

            throw new DomainException(
                "No se puede desactivar la última retícula vigente porque " .
                "la carrera tiene alumnos activos con inscripción en curso. " .
                "Primero registra y establece otra retícula vigente."
            );
        }
    }

    // ======================================
    // 9. CAMBIAR ESTADO
    // ======================================

    $stmt = $conn->prepare("
        UPDATE reticulas
        SET estado = 'No vigente'
        WHERE id_reticula = ?
          AND estado = 'Vigente'
    ");

    $stmt->bind_param("i", $id);
    $stmt->execute();

    if ($stmt->affected_rows !== 1) {
        throw new DomainException(
            "No fue posible cambiar el estado de la retícula"
        );
    }

    $stmt->close();
    $stmt = null;

    // ======================================
    // 10. CONFIRMAR TRANSACCIÓN
    // ======================================

    $conn->commit();
    $transaccion = false;

    responder(200, "Retícula marcada como no vigente correctamente", [
        "id_reticula" => (int)$id,
        "id_carrera" => $id_carrera,
        "estado" => "No vigente"
    ]);

} catch (DomainException $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    responder(409, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log(
        "Error SQL en reticulas/eliminar.php: " .
        $e->getMessage()
    );

    responder(500, "Error de base de datos al desactivar la retícula");

} catch (Throwable $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log(
        "Error interno en reticulas/eliminar.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al desactivar la retícula");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
