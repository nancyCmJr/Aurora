<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reticulas', 'consultar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR ID
// ==========================================

$id = filter_var(
    $_GET["id_reticula"] ?? null,
    FILTER_VALIDATE_INT
);

if ($id === false || $id === null || $id <= 0) {
    responder(400, "ID de retícula inválido");
}

$stmt = null;

try {

    // ======================================
    // 3. CONSULTAR RETÍCULA
    // ======================================

    $sql = "
        SELECT
            r.id_reticula,
            r.anio,
            r.id_carrera,

            c.nombre AS nombre_carrera,
            c.tipo AS tipo_carrera,
            c.total_creditos,
            c.estado AS estado_carrera,

            r.estado,

            COUNT(rm.id_materia) AS total_materias,

            COALESCE(SUM(m.creditos), 0)
                AS creditos_asignados,

            COALESCE(SUM(
                CASE
                    WHEN m.estado = 'Inactiva' THEN 1
                    ELSE 0
                END
            ), 0) AS materias_inactivas,

            (
                SELECT COUNT(*)
                FROM reticulas rv
                WHERE rv.id_carrera = r.id_carrera
                  AND rv.estado = 'Vigente'
            ) AS total_reticulas_vigentes,

            (
                SELECT COUNT(*)
                FROM reticula_materia rm2
                INNER JOIN materias m2
                    ON m2.id_materia = rm2.id_materia
                WHERE rm2.id_reticula = r.id_reticula
                  AND m2.id_materia_requisito IS NOT NULL
                  AND NOT EXISTS (
                      SELECT 1
                      FROM reticula_materia rm3
                      WHERE rm3.id_reticula = r.id_reticula
                        AND rm3.id_materia = m2.id_materia_requisito
                  )
            ) AS requisitos_no_asignados

        FROM reticulas r

        INNER JOIN carreras c
            ON c.id_carrera = r.id_carrera

        LEFT JOIN reticula_materia rm
            ON rm.id_reticula = r.id_reticula

        LEFT JOIN materias m
            ON m.id_materia = rm.id_materia

        WHERE r.id_reticula = ?

        GROUP BY
            r.id_reticula,
            r.anio,
            r.id_carrera,
            c.nombre,
            c.tipo,
            c.total_creditos,
            c.estado,
            r.estado
    ";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("i", $id);
    $stmt->execute();

    $reticula = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$reticula) {
        responder(404, "Retícula no encontrada");
    }

    // ======================================
    // 4. CONVERTIR TIPOS
    // ======================================

    $reticula["id_reticula"] =
        (int)$reticula["id_reticula"];

    $reticula["anio"] =
        (int)$reticula["anio"];

    $reticula["id_carrera"] =
        (int)$reticula["id_carrera"];

    $reticula["total_creditos"] =
        (int)$reticula["total_creditos"];

    $reticula["total_materias"] =
        (int)$reticula["total_materias"];

    $reticula["creditos_asignados"] =
        (int)$reticula["creditos_asignados"];

    $reticula["materias_inactivas"] =
        (int)$reticula["materias_inactivas"];

    $reticula["total_reticulas_vigentes"] =
        (int)$reticula["total_reticulas_vigentes"];

    $reticula["requisitos_no_asignados"] =
        (int)$reticula["requisitos_no_asignados"];

    // ======================================
    // 5. CALCULAR INDICADORES
    // ======================================

    $reticula["creditos_disponibles"] =
        $reticula["total_creditos"] -
        $reticula["creditos_asignados"];

    $reticula["cumple_creditos"] =
        $reticula["creditos_asignados"] <=
        $reticula["total_creditos"];

    $reticula["tiene_otra_reticula_vigente"] =
        $reticula["total_reticulas_vigentes"] > 0 &&
        $reticula["estado"] !== "Vigente";

    // ======================================
    // 6. RESPUESTA
    // ======================================

    responder(200, "Retícula consultada correctamente", [
        "reticula" => $reticula,

        "resumen" => [
            "total_materias" => $reticula["total_materias"],
            "creditos_asignados" => $reticula["creditos_asignados"],
            "creditos_carrera" => $reticula["total_creditos"],
            "creditos_disponibles" => $reticula["creditos_disponibles"],
            "materias_inactivas" => $reticula["materias_inactivas"],
            "requisitos_no_asignados" => $reticula["requisitos_no_asignados"],
            "cumple_creditos" => $reticula["cumple_creditos"]
        ]
    ]);

} catch (mysqli_sql_exception $e) {

    error_log(
        "Error SQL en reticulas/consultar.php: " .
        $e->getMessage()
    );

    responder(500, "Error de base de datos al consultar la retícula");

} catch (Throwable $e) {

    error_log(
        "Error interno en reticulas/consultar.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al consultar la retícula");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
