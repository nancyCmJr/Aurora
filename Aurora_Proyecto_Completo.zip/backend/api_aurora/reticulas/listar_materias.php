<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reticulas', 'listar_materias');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR IDENTIFICADORES
// ==========================================

$id_reticula = filter_var(
    $_GET["id_reticula"] ?? null,
    FILTER_VALIDATE_INT
);

if (
    $id_reticula === false ||
    $id_reticula === null ||
    $id_reticula <= 0
) {
    responder(400, "Se requiere un ID de retícula válido");
}

$semestre = null;

if (isset($_GET["semestre"]) && $_GET["semestre"] !== "") {

    $semestre = filter_var(
        $_GET["semestre"],
        FILTER_VALIDATE_INT
    );

    if (
        $semestre === false ||
        $semestre === null ||
        $semestre < 1 ||
        $semestre > 20
    ) {
        responder(400, "El semestre debe estar entre 1 y 20");
    }
}

$stmt = null;

try {

    // ======================================
    // 3. CONSULTAR RETÍCULA Y CARRERA
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            r.id_reticula,
            r.anio,
            r.estado AS estado_reticula,
            c.id_carrera,
            c.nombre AS carrera,
            c.tipo AS tipo_carrera,
            c.total_creditos,
            c.estado AS estado_carrera
        FROM reticulas r
        INNER JOIN carreras c
            ON c.id_carrera = r.id_carrera
        WHERE r.id_reticula = ?
    ");

    $stmt->bind_param("i", $id_reticula);
    $stmt->execute();

    $reticula = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$reticula) {
        responder(404, "La retícula no existe");
    }

    $reticula["id_reticula"] = (int)$reticula["id_reticula"];
    $reticula["anio"] = (int)$reticula["anio"];
    $reticula["id_carrera"] = (int)$reticula["id_carrera"];
    $reticula["total_creditos"] = (int)$reticula["total_creditos"];

    // ======================================
    // 4. CONSULTAR MATERIAS Y PRERREQUISITOS
    // ======================================

    $sql = "
        SELECT
            m.id_materia,
            m.clave_materia,
            m.nombre,
            m.creditos,
            m.horas_teoricas,
            m.horas_practicas,
            m.estado AS estado_materia,
            rm.semestre,

            m.id_materia_requisito,

            requisito.clave_materia AS clave_requisito,
            requisito.nombre AS nombre_requisito,
            requisito.estado AS estado_requisito,

            rm_requisito.semestre AS semestre_requisito

        FROM reticula_materia rm

        INNER JOIN materias m
            ON m.id_materia = rm.id_materia

        LEFT JOIN materias requisito
            ON requisito.id_materia = m.id_materia_requisito

        LEFT JOIN reticula_materia rm_requisito
            ON rm_requisito.id_reticula = rm.id_reticula
            AND rm_requisito.id_materia = m.id_materia_requisito

        WHERE rm.id_reticula = ?
    ";

    if ($semestre !== null) {
        $sql .= " AND rm.semestre = ?";
    }

    $sql .= " ORDER BY rm.semestre ASC, m.nombre ASC";

    $stmt = $conn->prepare($sql);

    if ($semestre !== null) {
        $stmt->bind_param("ii", $id_reticula, $semestre);
    } else {
        $stmt->bind_param("i", $id_reticula);
    }

    $stmt->execute();

    $resultado = $stmt->get_result();

    $materias = [];

    $totalCreditosFiltrados = 0;
    $materiasConError = 0;

    $conteoErrores = [
        "materias_inactivas" => 0,
        "requisitos_no_asignados" => 0,
        "requisitos_inactivos" => 0,
        "orden_semestres_incorrecto" => 0
    ];

    while ($fila = $resultado->fetch_assoc()) {

        $validacion = "Correcta";
        $mensajeValidacion = "La materia cumple con las validaciones académicas";

        // ==================================
        // 5. VALIDAR ESTADO DE LA MATERIA
        // ==================================

        if ($fila["estado_materia"] !== "Activa") {

            $validacion = "Incorrecta";

            $mensajeValidacion = "La materia está inactiva";

            $conteoErrores["materias_inactivas"]++;
        }

        // ==================================
        // 6. VALIDAR PRERREQUISITO
        // ==================================

        if ($fila["id_materia_requisito"] !== null) {

            if ($fila["semestre_requisito"] === null) {

                $validacion = "Incompleta";

                $mensajeValidacion =
                    "El prerrequisito no está asignado a esta retícula";

                $conteoErrores["requisitos_no_asignados"]++;

            } elseif ($fila["estado_requisito"] !== "Activa") {

                $validacion = "Incorrecta";

                $mensajeValidacion =
                    "El prerrequisito está inactivo";

                $conteoErrores["requisitos_inactivos"]++;

            } elseif (
                (int)$fila["semestre_requisito"] >=
                (int)$fila["semestre"]
            ) {

                $validacion = "Incorrecta";

                $mensajeValidacion =
                    "El prerrequisito debe estar en un semestre anterior";

                $conteoErrores["orden_semestres_incorrecto"]++;
            }
        }

        if ($validacion !== "Correcta") {
            $materiasConError++;
        }

        $totalCreditosFiltrados += (int)$fila["creditos"];

        $materias[] = [
            "id_materia" => (int)$fila["id_materia"],
            "clave_materia" => $fila["clave_materia"],
            "nombre" => $fila["nombre"],
            "creditos" => (int)$fila["creditos"],
            "horas_teoricas" => (int)$fila["horas_teoricas"],
            "horas_practicas" => (int)$fila["horas_practicas"],
            "estado_materia" => $fila["estado_materia"],
            "semestre" => (int)$fila["semestre"],

            "prerrequisito" =>
                $fila["id_materia_requisito"] !== null
                    ? [
                        "id_materia" =>
                            (int)$fila["id_materia_requisito"],

                        "clave_materia" =>
                            $fila["clave_requisito"],

                        "nombre" =>
                            $fila["nombre_requisito"],

                        "estado" =>
                            $fila["estado_requisito"],

                        "semestre" =>
                            $fila["semestre_requisito"] !== null
                                ? (int)$fila["semestre_requisito"]
                                : null
                    ]
                    : null,

            "validacion_academica" => $validacion,
            "mensaje_validacion" => $mensajeValidacion
        ];
    }

    $stmt->close();
    $stmt = null;

    // ======================================
    // 7. CALCULAR CRÉDITOS DE TODA LA RETÍCULA
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            COUNT(*) AS total_materias,
            COALESCE(SUM(m.creditos), 0) AS creditos_totales
        FROM reticula_materia rm
        INNER JOIN materias m
            ON m.id_materia = rm.id_materia
        WHERE rm.id_reticula = ?
    ");

    $stmt->bind_param("i", $id_reticula);
    $stmt->execute();

    $resumen = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    // ======================================
    // 8. CALCULAR RESUMEN
    // ======================================

    $creditosTotales = (int)$resumen["creditos_totales"];

    $creditosPermitidos = (int)$reticula["total_creditos"];

    $creditosDisponibles =
        $creditosPermitidos - $creditosTotales;

    // ======================================
    // 9. RESPUESTA
    // ======================================

    responder(200, "Materias de la retícula consultadas correctamente", [

        "reticula" => $reticula,

        "materias" => $materias,

        "resumen" => [
            "total_materias" => (int)$resumen["total_materias"],

            "materias_mostradas" => count($materias),

            "creditos_totales" => $creditosTotales,

            "creditos_filtrados" => $totalCreditosFiltrados,

            "creditos_permitidos" => $creditosPermitidos,

            "creditos_disponibles" => $creditosDisponibles,

            "materias_con_error_academico" => $materiasConError,

            "detalle_errores" => $conteoErrores,

            "cumple_creditos" =>
                $creditosTotales <= $creditosPermitidos,

            "cumple_validaciones_academicas" =>
                $materiasConError === 0
        ]
    ]);

} catch (mysqli_sql_exception $e) {

    error_log(
        "Error SQL en reticulas/listar_materias.php: " .
        $e->getMessage()
    );

    responder(500, "Error de base de datos al consultar las materias");

} catch (Throwable $e) {

    error_log(
        "Error interno en reticulas/listar_materias.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al consultar las materias");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
