<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reticulas', 'asignar_materias');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. RECIBIR Y VALIDAR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "JSON inválido");
}

$id_reticula = filter_var(
    $data["id_reticula"] ?? null,
    FILTER_VALIDATE_INT
);

$materias = $data["materias"] ?? null;

if (
    $id_reticula === false ||
    $id_reticula === null ||
    $id_reticula <= 0
) {
    responder(400, "ID de retícula inválido");
}

if (!is_array($materias) || count($materias) === 0) {
    responder(400, "Debe proporcionar al menos una materia");
}

// ==========================================
// 3. VALIDAR MATERIAS RECIBIDAS
// ==========================================

$materiasNuevas = [];
$idsRecibidos = [];

foreach ($materias as $materia) {

    if (!is_array($materia)) {
        responder(400, "Formato de materia inválido");
    }

    $id_materia = filter_var(
        $materia["id_materia"] ?? null,
        FILTER_VALIDATE_INT
    );

    $semestre = filter_var(
        $materia["semestre"] ?? null,
        FILTER_VALIDATE_INT
    );

    if (
        $id_materia === false ||
        $id_materia === null ||
        $id_materia <= 0
    ) {
        responder(400, "ID de materia inválido");
    }

    if (
        $semestre === false ||
        $semestre === null ||
        $semestre < 1 ||
        $semestre > 20
    ) {
        responder(400, "El semestre debe estar entre 1 y 20");
    }

    if (isset($idsRecibidos[$id_materia])) {
        responder(400, "La solicitud contiene materias repetidas");
    }

    $idsRecibidos[$id_materia] = true;

    $materiasNuevas[$id_materia] = [
        "id_materia" => $id_materia,
        "semestre" => $semestre
    ];
}

// ==========================================
// 4. INICIAR TRANSACCIÓN
// ==========================================

$transaccion = false;
$stmt = null;
$stmtMateria = null;
$stmtInsert = null;

try {

    $conn->begin_transaction();
    $transaccion = true;
    require_once __DIR__ . '/../lib/academico.php';
    auroraVerificarReticulaEditable($conn, (int)$id_reticula);

    // ======================================
    // 5. BLOQUEAR Y VALIDAR RETÍCULA
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            r.id_reticula,
            r.estado,
            c.total_creditos
        FROM reticulas r
        INNER JOIN carreras c
            ON c.id_carrera = r.id_carrera
        WHERE r.id_reticula = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_reticula);
    $stmt->execute();

    $reticula = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$reticula) {
        throw new DomainException("La retícula no existe");
    }

    if ($reticula["estado"] !== "Vigente") {
        throw new DomainException(
            "No se pueden asignar materias a una retícula no vigente"
        );
    }

    // ======================================
    // 6. CONSULTAR MATERIAS YA ASIGNADAS
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            m.id_materia,
            m.id_materia_requisito,
            m.creditos,
            m.estado,
            rm.semestre
        FROM reticula_materia rm
        INNER JOIN materias m
            ON m.id_materia = rm.id_materia
        WHERE rm.id_reticula = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_reticula);
    $stmt->execute();

    $resultado = $stmt->get_result();

    $materiasReticula = [];
    $creditosActuales = 0;

    while ($fila = $resultado->fetch_assoc()) {

        $id = (int)$fila["id_materia"];

        $materiasReticula[$id] = [
            "id_materia" => $id,

            "id_materia_requisito" =>
                $fila["id_materia_requisito"] !== null
                    ? (int)$fila["id_materia_requisito"]
                    : null,

            "semestre" => (int)$fila["semestre"],
            "creditos" => (int)$fila["creditos"],
            "estado" => $fila["estado"]
        ];

        $creditosActuales += (int)$fila["creditos"];
    }

    $stmt->close();
    $stmt = null;

    // ======================================
    // 7. VALIDAR MATERIAS YA ASIGNADAS
    // ======================================

    foreach ($materiasReticula as $materia) {

        if ($materia["estado"] !== "Activa") {
            throw new DomainException(
                "La retícula contiene la materia con ID " .
                $materia["id_materia"] .
                " en estado Inactiva. Debe corregirse antes de continuar."
            );
        }
    }

    // ======================================
    // 8. CONSULTAR Y BLOQUEAR NUEVAS MATERIAS
    // ======================================

    $stmtMateria = $conn->prepare("
        SELECT
            id_materia,
            id_materia_requisito,
            creditos,
            estado
        FROM materias
        WHERE id_materia = ?
        FOR UPDATE
    ");

    foreach ($materiasNuevas as $id => $materiaNueva) {

        $stmtMateria->bind_param("i", $id);
        $stmtMateria->execute();

        $materiaBD = $stmtMateria->get_result()->fetch_assoc();

        if (!$materiaBD) {
            throw new DomainException(
                "No existe la materia con ID " . $id
            );
        }

        if ($materiaBD["estado"] !== "Activa") {
            throw new DomainException(
                "La materia con ID " . $id . " está inactiva"
            );
        }

        if (isset($materiasReticula[$id])) {
            throw new DomainException(
                "La materia con ID " . $id .
                " ya está asignada a esta retícula"
            );
        }

        $materiasReticula[$id] = [
            "id_materia" => $id,

            "id_materia_requisito" =>
                $materiaBD["id_materia_requisito"] !== null
                    ? (int)$materiaBD["id_materia_requisito"]
                    : null,

            "semestre" => $materiaNueva["semestre"],
            "creditos" => (int)$materiaBD["creditos"],
            "estado" => $materiaBD["estado"]
        ];

        $creditosActuales += (int)$materiaBD["creditos"];
    }

    $stmtMateria->close();
    $stmtMateria = null;

    // ======================================
    // 9. VALIDAR CRÉDITOS DE LA CARRERA
    // ======================================

    $creditosPermitidos = (int)$reticula["total_creditos"];

    if ($creditosActuales > $creditosPermitidos) {
        throw new DomainException(
            "La asignación supera los créditos permitidos. " .
            "Créditos acumulados: " . $creditosActuales .
            ". Créditos permitidos: " . $creditosPermitidos
        );
    }

    // ======================================
    // 10. VALIDAR PRERREQUISITOS
    // ======================================

    foreach ($materiasReticula as $materia) {

        $idRequisito = $materia["id_materia_requisito"];

        if ($idRequisito === null) {
            continue;
        }

        if (!isset($materiasReticula[$idRequisito])) {
            throw new DomainException(
                "La materia con ID " . $materia["id_materia"] .
                " requiere la materia con ID " . $idRequisito .
                ", pero no está asignada a esta retícula"
            );
        }

        $requisito = $materiasReticula[$idRequisito];

        if ($requisito["estado"] !== "Activa") {
            throw new DomainException(
                "El prerrequisito con ID " . $idRequisito .
                " está inactivo"
            );
        }

        if ($requisito["semestre"] >= $materia["semestre"]) {
            throw new DomainException(
                "El prerrequisito de la materia con ID " .
                $materia["id_materia"] .
                " debe estar ubicado en un semestre anterior"
            );
        }
    }

    // ======================================
    // 11. INSERTAR MATERIAS NUEVAS
    // ======================================

    $stmtInsert = $conn->prepare("
        INSERT INTO reticula_materia (
            id_reticula,
            id_materia,
            semestre
        )
        VALUES (?, ?, ?)
    ");

    foreach ($materiasNuevas as $materia) {

        $id = $materia["id_materia"];
        $semestre = $materia["semestre"];

        $stmtInsert->bind_param(
            "iii",
            $id_reticula,
            $id,
            $semestre
        );

        $stmtInsert->execute();
    }

    $stmtInsert->close();
    $stmtInsert = null;

    // ======================================
    // 12. CONFIRMAR TRANSACCIÓN
    // ======================================

    $conn->commit();
    $transaccion = false;

    responder(200, "Materias asignadas correctamente", [
        "id_reticula" => (int)$id_reticula,
        "total_materias_asignadas" => count($materiasNuevas),
        "total_materias_en_reticula" => count($materiasReticula),
        "creditos_totales" => $creditosActuales,
        "creditos_permitidos" => $creditosPermitidos
    ]);

} catch (DomainException $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    responder(409, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log(
        "Error SQL en reticulas/asignar_materias.php: " .
        $e->getMessage()
    );

    if ((int)$e->getCode() === 1062) {
        responder(409, "Una o más materias ya están asignadas a la retícula");
    }

    if ((int)$e->getCode() === 1452) {
        responder(400, "La retícula o alguna materia relacionada no existe");
    }

    if ((int)$e->getCode() === 3819) {
        responder(400, "La asignación incumple una restricción de la base de datos");
    }

    responder(500, "Error de base de datos al asignar las materias");

} catch (Throwable $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log(
        "Error interno en reticulas/asignar_materias.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al asignar las materias");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    if ($stmtMateria) {
        $stmtMateria->close();
    }

    if ($stmtInsert) {
        $stmtInsert->close();
    }

    $conn->close();
}

?>
