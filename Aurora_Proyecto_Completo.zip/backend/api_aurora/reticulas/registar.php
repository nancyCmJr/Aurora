<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'reticulas', 'registar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = [])
{
    http_response_code($codigo);

    echo json_encode(array_merge([
        "success" => $codigo >= 200 && $codigo < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. RECIBIR JSON
// ==========================================

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    responder(400, "JSON inválido");
}

// ==========================================
// 3. VALIDAR CAMPOS
// ==========================================

if (
    !array_key_exists("anio", $data) ||
    !array_key_exists("id_carrera", $data)
) {
    responder(400, "Faltan datos obligatorios");
}

$anio = filter_var(
    $data["anio"],
    FILTER_VALIDATE_INT
);

$id_carrera = filter_var(
    $data["id_carrera"],
    FILTER_VALIDATE_INT
);

$estado = $data["estado"] ?? "Vigente";

if (
    $anio === false ||
    $anio < 1901 ||
    $anio > 2155
) {
    responder(400, "El año debe estar entre 1901 y 2155");
}

if (
    $id_carrera === false ||
    $id_carrera <= 0
) {
    responder(400, "El ID de carrera no es válido");
}

if (
    !is_string($estado) ||
    !in_array($estado, ["Vigente", "No vigente"], true)
) {
    responder(400, "El estado de la retícula no es válido");
}

// ==========================================
// 4. INICIAR TRANSACCIÓN
// ==========================================

$transaccion = false;
$stmt = null;

try {

    $conn->begin_transaction();
    $transaccion = true;

    // ======================================
    // 5. VERIFICAR Y BLOQUEAR CARRERA
    // ======================================

    $stmt = $conn->prepare("
        SELECT
            id_carrera,
            nombre,
            total_creditos,
            estado
        FROM carreras
        WHERE id_carrera = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_carrera);
    $stmt->execute();

    $carrera = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$carrera) {
        throw new DomainException(
            "La carrera seleccionada no existe"
        );
    }

    if ($carrera["estado"] !== "Activa") {
        throw new DomainException(
            "No se pueden registrar retículas para una carrera inactiva"
        );
    }

    // ======================================
    // 6. VERIFICAR RETÍCULA DUPLICADA
    // ======================================

    $stmt = $conn->prepare("
        SELECT id_reticula, estado
        FROM reticulas
        WHERE id_carrera = ?
          AND anio = ?
        LIMIT 1
    ");

    $stmt->bind_param("ii", $id_carrera, $anio);
    $stmt->execute();

    $duplicada = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if ($duplicada) {
        throw new DomainException(
            "Ya existe una retícula para esta carrera en el año indicado"
        );
    }

    // ======================================
    // 7. VERIFICAR RETÍCULA VIGENTE
    // ======================================

    if ($estado === "Vigente") {

        $stmt = $conn->prepare("
            SELECT id_reticula, anio
            FROM reticulas
            WHERE id_carrera = ?
              AND estado = 'Vigente'
            LIMIT 1
            FOR UPDATE
        ");

        $stmt->bind_param("i", $id_carrera);
        $stmt->execute();

        $vigente = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if ($vigente) {
            throw new DomainException(
                "La carrera ya tiene una retícula vigente del año " .
                $vigente["anio"] .
                ". Primero debes cambiar su estado."
            );
        }
    }

    // ======================================
    // 8. REGISTRAR RETÍCULA
    // ======================================

    $stmt = $conn->prepare("
        INSERT INTO reticulas (
            anio,
            id_carrera,
            estado
        )
        VALUES (?, ?, ?)
    ");

    $stmt->bind_param(
        "iis",
        $anio,
        $id_carrera,
        $estado
    );

    $stmt->execute();

    $id_nueva_reticula = $conn->insert_id;

    $stmt->close();
    $stmt = null;

    // ======================================
    // 9. CONFIRMAR TRANSACCIÓN
    // ======================================

    $conn->commit();
    $transaccion = false;

    responder(201, "Retícula registrada correctamente", [
        "id_reticula" => (int)$id_nueva_reticula,
        "anio" => (int)$anio,
        "id_carrera" => (int)$id_carrera,
        "estado" => $estado
    ]);

} catch (DomainException $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    responder(409, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log(
        "Error SQL en reticulas/registrar.php: " .
        $e->getMessage()
    );

    responder(500, "Error de base de datos al registrar la retícula");

} catch (Throwable $e) {

    if ($transaccion) {
        $conn->rollback();
    }

    error_log(
        "Error interno en reticulas/registrar.php: " .
        $e->getMessage()
    );

    responder(500, "Error interno al registrar la retícula");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>