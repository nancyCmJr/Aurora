<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'docentes', 'actualizar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($status, $mensaje, $datos = []) {
    http_response_code($status);

    echo json_encode(array_merge([
        "success" => $status >= 200 && $status < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

function textoValido($valor, $maximo, $obligatorio = false) {
    if (!is_string($valor)) {
        return false;
    }

    $valor = trim($valor);

    if ($obligatorio && $valor === '') {
        return false;
    }

    return mb_strlen($valor, "UTF-8") <= $maximo;
}

function valorOpcional($valor) {
    if ($valor === null) {
        return null;
    }

    if (!is_string($valor) && !is_numeric($valor)) {
        throw new DomainException("Se recibió un dato complementario inválido", 400);
    }

    $valor = trim((string)$valor);

    return $valor === '' ? null : $valor;
}

function validarFecha($fecha, $campo) {
    if ($fecha === null) {
        return;
    }

    $partes = explode("-", $fecha);

    if (
        count($partes) !== 3 ||
        !checkdate(
            (int)$partes[1],
            (int)$partes[2],
            (int)$partes[0]
        )
    ) {
        throw new DomainException(
            "La fecha de " . $campo . " no es válida",
            400
        );
    }
}

function verificarLongitud($valor, $maximo, $campo) {
    if ($valor !== null && mb_strlen($valor, "UTF-8") > $maximo) {
        throw new DomainException(
            "El campo " . $campo . " supera la longitud permitida",
            400
        );
    }
}

$data = json_decode(file_get_contents("php://input"));

if (!is_object($data)) {
    responder(400, "El formato JSON no es válido");
}

/* -----------------------------------------
   1. Validar datos principales
----------------------------------------- */

$id_docente = $data->id_docente ?? null;

if (
    !(is_int($id_docente) && $id_docente > 0) &&
    !(is_string($id_docente) &&
      ctype_digit($id_docente) &&
      filter_var($id_docente, FILTER_VALIDATE_INT) !== false &&
      (int)$id_docente > 0)
) {
    responder(400, "Se requiere un ID de docente válido");
}

$id_docente = (int)$id_docente;

$camposObligatorios = [
    "codigo" => 20,
    "nombre" => 60,
    "apellidos" => 100
];

foreach ($camposObligatorios as $campo => $longitud) {
    if (
        !isset($data->$campo) ||
        !textoValido($data->$campo, $longitud, true)
    ) {
        responder(
            400,
            "El campo " . $campo . " es obligatorio o supera la longitud permitida"
        );
    }
}

if (
    !isset($data->estado) ||
    !is_string($data->estado) ||
    !in_array($data->estado, ["Activo", "Inactivo", "Baja"], true)
) {
    responder(400, "El estado del docente no es válido");
}

$codigo = trim($data->codigo);
$nombre = trim($data->nombre);
$apellidos = trim($data->apellidos);
$estado = $data->estado;

$cedula = valorOpcional($data->cedula ?? null);
$seg_nombre = valorOpcional($data->seg_nombre ?? null);
$titulo_academico = valorOpcional($data->titulo_academico ?? null);

verificarLongitud($cedula, 20, "cédula");
verificarLongitud($seg_nombre, 60, "segundo nombre");
verificarLongitud($titulo_academico, 100, "título académico");

/* -----------------------------------------
   2. Validar detalle
----------------------------------------- */

$detalle = null;

if (property_exists($data, "detalle") && $data->detalle !== null) {
    if (!is_object($data->detalle)) {
        responder(400, "Los datos complementarios no son válidos");
    }

    $detalle = $data->detalle;
}

/* -----------------------------------------
   3. Transacción
----------------------------------------- */

$stmt = null;

try {

    $conn->begin_transaction();

    /* -----------------------------------------
       3.1 Bloquear y verificar docente
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_docente
        FROM docentes
        WHERE id_docente = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_docente);
    $stmt->execute();

    $existe = $stmt->get_result()->num_rows > 0;

    $stmt->close();
    $stmt = null;

    if (!$existe) {
        throw new DomainException("No se encontró el docente", 404);
    }

    /* -----------------------------------------
       3.2 Validar estado y dependencias
    ----------------------------------------- */

    if ($estado !== "Activo") {

        $stmt = $conn->prepare("
            SELECT COUNT(*) AS total
            FROM contratos
            WHERE id_docente = ?
              AND status = 'Activo'
        ");

        $stmt->bind_param("i", $id_docente);
        $stmt->execute();

        $contratosActivos = (int)$stmt->get_result()
            ->fetch_assoc()["total"];

        $stmt->close();
        $stmt = null;

        if ($contratosActivos > 0) {
            throw new DomainException(
                "No se puede cambiar el estado del docente porque tiene contratos activos.",
                409
            );
        }

        $stmt = $conn->prepare("
            SELECT COUNT(*) AS total
            FROM grupos
            WHERE id_docente = ?
              AND estado IN ('Planeado', 'Abierto')
        ");

        $stmt->bind_param("i", $id_docente);
        $stmt->execute();

        $gruposActivos = (int)$stmt->get_result()
            ->fetch_assoc()["total"];

        $stmt->close();
        $stmt = null;

        if ($gruposActivos > 0) {
            throw new DomainException(
                "No se puede cambiar el estado del docente porque tiene grupos planeados o abiertos. Primero debes reasignarlos o cambiar su estado.",
                409
            );
        }
    }

    /* -----------------------------------------
       3.3 Verificar código duplicado
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_docente
        FROM docentes
        WHERE codigo = ?
          AND id_docente <> ?
        LIMIT 1
    ");

    $stmt->bind_param("si", $codigo, $id_docente);
    $stmt->execute();

    $duplicado = $stmt->get_result()->num_rows > 0;

    $stmt->close();
    $stmt = null;

    if ($duplicado) {
        throw new DomainException(
            "El código ya está registrado por otro docente.",
            409
        );
    }

    /* -----------------------------------------
       3.4 Verificar cédula duplicada
    ----------------------------------------- */

    if ($cedula !== null) {

        $stmt = $conn->prepare("
            SELECT id_docente
            FROM docentes
            WHERE cedula = ?
              AND id_docente <> ?
            LIMIT 1
        ");

        $stmt->bind_param("si", $cedula, $id_docente);
        $stmt->execute();

        $duplicado = $stmt->get_result()->num_rows > 0;

        $stmt->close();
        $stmt = null;

        if ($duplicado) {
            throw new DomainException(
                "La cédula profesional ya está registrada por otro docente.",
                409
            );
        }
    }

    /* -----------------------------------------
       4. Actualizar datos principales
    ----------------------------------------- */

    $stmt = $conn->prepare("
        UPDATE docentes
        SET codigo = ?,
            cedula = ?,
            nombre = ?,
            seg_nombre = ?,
            apellidos = ?,
            titulo_academico = ?,
            estado = ?
        WHERE id_docente = ?
    ");

    $stmt->bind_param(
        "sssssssi",
        $codigo,
        $cedula,
        $nombre,
        $seg_nombre,
        $apellidos,
        $titulo_academico,
        $estado,
        $id_docente
    );

    $stmt->execute();
    $stmt->close();
    $stmt = null;

    /* -----------------------------------------
       5. Actualizar detalle si fue enviado
    ----------------------------------------- */

    if ($detalle !== null) {

        $curp = valorOpcional($detalle->curp ?? null);
        $rfc = valorOpcional($detalle->rfc ?? null);
        $fecha_nacimiento = valorOpcional($detalle->fecha_nacimiento ?? null);
        $telefono = valorOpcional($detalle->telefono ?? null);
        $email = valorOpcional($detalle->email ?? null);
        $calle = valorOpcional($detalle->calle ?? null);
        $numero_exterior = valorOpcional($detalle->numero_exterior ?? null);
        $numero_interior = valorOpcional($detalle->numero_interior ?? null);
        $colonia = valorOpcional($detalle->colonia ?? null);
        $codigo_postal = valorOpcional($detalle->codigo_postal ?? null);
        $municipio = valorOpcional($detalle->municipio ?? null);
        $estado_domicilio = valorOpcional($detalle->estado ?? null);
        $referencias = valorOpcional($detalle->referencias ?? null);
        $fecha_ingreso = valorOpcional($detalle->fecha_ingreso ?? null);

        /* Validar longitudes */

        $camposDetalle = [
            "curp" => [$curp, 18],
            "rfc" => [$rfc, 13],
            "teléfono" => [$telefono, 15],
            "correo electrónico" => [$email, 100],
            "calle" => [$calle, 100],
            "número exterior" => [$numero_exterior, 10],
            "número interior" => [$numero_interior, 10],
            "colonia" => [$colonia, 80],
            "código postal" => [$codigo_postal, 5],
            "municipio" => [$municipio, 80],
            "estado del domicilio" => [$estado_domicilio, 50],
            "referencias" => [$referencias, 150]
        ];

        foreach ($camposDetalle as $campo => $config) {
            verificarLongitud($config[0], $config[1], $campo);
        }

        /* Validar CURP */

        if (
            $curp !== null &&
            !preg_match('/^[A-Z0-9]{18}$/i', $curp)
        ) {
            throw new DomainException(
                "La CURP debe contener exactamente 18 caracteres alfanuméricos.",
                400
            );
        }

        if ($curp !== null) {
            $curp = strtoupper($curp);
        }

        /* Validar RFC */

        if (
            $rfc !== null &&
            !preg_match('/^[A-ZÑ&]{3,4}[0-9]{6}[A-Z0-9]{3}$/i', $rfc)
        ) {
            throw new DomainException("El RFC no tiene un formato válido.", 400);
        }

        if ($rfc !== null) {
            $rfc = strtoupper($rfc);
        }

        /* Validar correo */

        if (
            $email !== null &&
            !filter_var($email, FILTER_VALIDATE_EMAIL)
        ) {
            throw new DomainException(
                "El correo electrónico no tiene un formato válido.",
                400
            );
        }

        /* Validar código postal */

        if (
            $codigo_postal !== null &&
            !preg_match('/^[0-9]{5}$/', $codigo_postal)
        ) {
            throw new DomainException(
                "El código postal debe contener exactamente cinco dígitos.",
                400
            );
        }

        /* Validar fechas */

        validarFecha($fecha_nacimiento, "nacimiento");
        validarFecha($fecha_ingreso, "ingreso");

        /* -----------------------------------------
           5.1 Verificar CURP duplicada
        ----------------------------------------- */

        if ($curp !== null) {

            $stmt = $conn->prepare("
                SELECT id_docente
                FROM detalle_docentes
                WHERE curp = ?
                  AND id_docente <> ?
                LIMIT 1
            ");

            $stmt->bind_param("si", $curp, $id_docente);
            $stmt->execute();

            $duplicado = $stmt->get_result()->num_rows > 0;

            $stmt->close();
            $stmt = null;

            if ($duplicado) {
                throw new DomainException(
                    "La CURP ya está registrada por otro docente.",
                    409
                );
            }
        }

        /* -----------------------------------------
           5.2 Verificar RFC duplicado
        ----------------------------------------- */

        if ($rfc !== null) {

            $stmt = $conn->prepare("
                SELECT id_docente
                FROM detalle_docentes
                WHERE rfc = ?
                  AND id_docente <> ?
                LIMIT 1
            ");

            $stmt->bind_param("si", $rfc, $id_docente);
            $stmt->execute();

            $duplicado = $stmt->get_result()->num_rows > 0;

            $stmt->close();
            $stmt = null;

            if ($duplicado) {
                throw new DomainException(
                    "El RFC ya está registrado por otro docente.",
                    409
                );
            }
        }

        /* -----------------------------------------
           5.3 Verificar correo duplicado
        ----------------------------------------- */

        if ($email !== null) {

            $stmt = $conn->prepare("
                SELECT id_docente
                FROM detalle_docentes
                WHERE email = ?
                  AND id_docente <> ?
                LIMIT 1
            ");

            $stmt->bind_param("si", $email, $id_docente);
            $stmt->execute();

            $duplicado = $stmt->get_result()->num_rows > 0;

            $stmt->close();
            $stmt = null;

            if ($duplicado) {
                throw new DomainException(
                    "El correo electrónico ya está registrado por otro docente.",
                    409
                );
            }
        }

        /* -----------------------------------------
           5.4 Consultar detalle existente
        ----------------------------------------- */

        $stmt = $conn->prepare("
            SELECT id_detalle_doc
            FROM detalle_docentes
            WHERE id_docente = ?
            LIMIT 1
            FOR UPDATE
        ");

        $stmt->bind_param("i", $id_docente);
        $stmt->execute();

        $tieneDetalle = $stmt->get_result()->num_rows > 0;

        $stmt->close();
        $stmt = null;

        if ($tieneDetalle) {

            /* Actualizar detalle */

            $stmt = $conn->prepare("
                UPDATE detalle_docentes
                SET curp = ?,
                    rfc = ?,
                    fecha_nacimiento = ?,
                    telefono = ?,
                    email = ?,
                    calle = ?,
                    numero_exterior = ?,
                    numero_interior = ?,
                    colonia = ?,
                    codigo_postal = ?,
                    municipio = ?,
                    estado = ?,
                    referencias = ?,
                    fecha_ingreso = ?
                WHERE id_docente = ?
            ");

            $stmt->bind_param(
                "ssssssssssssssi",
                $curp,
                $rfc,
                $fecha_nacimiento,
                $telefono,
                $email,
                $calle,
                $numero_exterior,
                $numero_interior,
                $colonia,
                $codigo_postal,
                $municipio,
                $estado_domicilio,
                $referencias,
                $fecha_ingreso,
                $id_docente
            );

        } else {

            /* Insertar detalle */

            $stmt = $conn->prepare("
                INSERT INTO detalle_docentes (
                    id_docente,
                    curp,
                    rfc,
                    fecha_nacimiento,
                    telefono,
                    email,
                    calle,
                    numero_exterior,
                    numero_interior,
                    colonia,
                    codigo_postal,
                    municipio,
                    estado,
                    referencias,
                    fecha_ingreso
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->bind_param(
                "issssssssssssss",
                $id_docente,
                $curp,
                $rfc,
                $fecha_nacimiento,
                $telefono,
                $email,
                $calle,
                $numero_exterior,
                $numero_interior,
                $colonia,
                $codigo_postal,
                $municipio,
                $estado_domicilio,
                $referencias,
                $fecha_ingreso
            );
        }

        $stmt->execute();
        $stmt->close();
        $stmt = null;
    }

    /* -----------------------------------------
       6. Confirmar cambios
    ----------------------------------------- */

    $conn->commit();

    responder(200, "Docente actualizado correctamente", [
        "data" => [
            "id_docente" => $id_docente,
            "codigo" => $codigo,
            "estado" => $estado
        ]
    ]);

} catch (DomainException $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    $codigoHTTP = $e->getCode();

    if ($codigoHTTP < 400 || $codigoHTTP > 599) {
        $codigoHTTP = 400;
    }

    responder($codigoHTTP, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log("Error SQL docentes/actualizar.php: " . $e->getMessage());

    if ((int)$e->getCode() === 1062) {
        responder(409, "Uno de los datos únicos ya está registrado.");
    }

    if ((int)$e->getCode() === 1213 || (int)$e->getCode() === 1205) {
        responder(
            409,
            "La operación tuvo un conflicto con otra actualización. Intenta nuevamente."
        );
    }

    responder(500, "Error de base de datos al actualizar el docente.");

} catch (Throwable $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log("Error docentes/actualizar.php: " . $e->getMessage());

    responder(500, "Error interno al actualizar el docente.");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}
?>
