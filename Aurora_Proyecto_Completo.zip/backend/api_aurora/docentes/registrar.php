<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'docentes', 'registrar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

// Convertir cadenas vacías en NULL.
function valorOpcional($valor) {
    if ($valor === null) {
        return null;
    }

    $valor = trim((string)$valor);
    return $valor === '' ? null : $valor;
}

$data = json_decode(file_get_contents("php://input"));

if (!is_object($data)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El formato JSON no es válido"
    ]);
    exit();
}

if (
    !isset($data->codigo) ||
    !isset($data->nombre) ||
    !isset($data->apellidos)
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Faltan datos obligatorios"
    ]);
    exit();
}

// Datos principales.
$codigo = trim((string)$data->codigo);
$cedula = valorOpcional($data->cedula ?? null);
$nombre = trim((string)$data->nombre);
$seg_nombre = valorOpcional($data->seg_nombre ?? null);
$apellidos = trim((string)$data->apellidos);
$titulo_academico = valorOpcional($data->titulo_academico ?? null);
$estado = trim((string)($data->estado ?? 'Activo'));

$estadosPermitidos = ['Activo', 'Inactivo', 'Baja'];

if (
    $codigo === '' ||
    $nombre === '' ||
    $apellidos === '' ||
    !in_array($estado, $estadosPermitidos, true)
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Los datos del docente no son válidos"
    ]);
    exit();
}

// Datos complementarios opcionales.
$detalle = null;

if (isset($data->detalle)) {

    if (!is_object($data->detalle)) {
        http_response_code(400);
        echo json_encode([
            "success" => false,
            "message" => "Los datos complementarios no son válidos"
        ]);
        exit();
    }

    $detalle = $data->detalle;
}

try {

    $conn->begin_transaction();

    // 1. Verificar código de docente.
    $sql = "SELECT id_docente
            FROM docentes
            WHERE codigo = ?
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $codigo);
    $stmt->execute();

    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();
        throw new Exception(
            "El código del docente ya está registrado.",
            409
        );
    }

    $stmt->close();

    // 2. Verificar cédula profesional.
    if ($cedula !== null) {

        $sql = "SELECT id_docente
                FROM docentes
                WHERE cedula = ?
                LIMIT 1";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $cedula);
        $stmt->execute();

        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();
            throw new Exception(
                "La cédula profesional ya está registrada.",
                409
            );
        }

        $stmt->close();
    }

    // 3. Obtener y verificar datos complementarios.
    if ($detalle !== null) {

        $curp = valorOpcional($detalle->curp ?? null);
        $rfc = valorOpcional($detalle->rfc ?? null);
        $fecha_nacimiento = valorOpcional($detalle->fecha_nacimiento ?? null);
        $telefono = valorOpcional($detalle->telefono ?? null);
        $email = valorOpcional($detalle->email ?? null);
        $calle = valorOpcional($detalle->calle ?? null);
        $numero_exterior = valorOpcional($detalle->numero_exterior ?? null);
        $numero_interior = valorOpcional($detalle->numero_interior ?? null);
        $colonia = valorOpcional($detalle->colonia ?? null);
        $codigo_postal = valorOpcional($detalle->codigo_postal ?? null);
        $municipio = valorOpcional($detalle->municipio ?? null);
        $estado_domicilio = valorOpcional($detalle->estado ?? null);
        $referencias = valorOpcional($detalle->referencias ?? null);
        $fecha_ingreso = valorOpcional($detalle->fecha_ingreso ?? null);

        $camposUnicos = [
            "curp" => [
                "valor" => $curp,
                "mensaje" => "La CURP ya está registrada por otro docente."
            ],
            "rfc" => [
                "valor" => $rfc,
                "mensaje" => "El RFC ya está registrado por otro docente."
            ],
            "email" => [
                "valor" => $email,
                "mensaje" => "El correo electrónico ya está registrado por otro docente."
            ]
        ];

        foreach ($camposUnicos as $campo => $informacion) {

            $valor = $informacion["valor"];

            if ($valor === null) {
                continue;
            }

            $sql = "SELECT id_docente
                    FROM detalle_docentes
                    WHERE $campo = ?
                    LIMIT 1";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $valor);
            $stmt->execute();

            if ($stmt->get_result()->num_rows > 0) {
                $stmt->close();
                throw new Exception(
                    $informacion["mensaje"],
                    409
                );
            }

            $stmt->close();
        }
    }

    // 4. Registrar docente.
    $sql = "INSERT INTO docentes (
                codigo,
                cedula,
                nombre,
                seg_nombre,
                apellidos,
                titulo_academico,
                estado
            ) VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "sssssss",
        $codigo,
        $cedula,
        $nombre,
        $seg_nombre,
        $apellidos,
        $titulo_academico,
        $estado
    );

    $stmt->execute();

    $id_docente = $conn->insert_id;

    $stmt->close();

    // 5. Registrar detalle si se recibió.
    if ($detalle !== null) {

        $sql = "INSERT INTO detalle_docentes (
                    id_docente,
                    curp,
                    rfc,
                    fecha_nacimiento,
                    telefono,
                    email,
                    calle,
                    numero_exterior,
                    numero_interior,
                    colonia,
                    codigo_postal,
                    municipio,
                    estado,
                    referencias,
                    fecha_ingreso
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);

        $stmt->bind_param(
            "issssssssssssss",
            $id_docente,
            $curp,
            $rfc,
            $fecha_nacimiento,
            $telefono,
            $email,
            $calle,
            $numero_exterior,
            $numero_interior,
            $colonia,
            $codigo_postal,
            $municipio,
            $estado_domicilio,
            $referencias,
            $fecha_ingreso
        );

        $stmt->execute();
        $stmt->close();
    }

    // 6. Confirmar transacción.
    $conn->commit();

    http_response_code(201);

    echo json_encode([
        "success" => true,
        "message" => "Docente registrado correctamente",
        "data" => [
            "id_docente" => $id_docente,
            "codigo" => $codigo
        ]
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {

    $conn->rollback();

    $mensaje = $e->getMessage();
    $codigoHTTP = 400;

    if ($e instanceof mysqli_sql_exception) {

        if ((int)$e->getCode() === 1062) {

            $codigoHTTP = 409;
            $mensajeSQL = strtolower($mensaje);

            if (strpos($mensajeSQL, 'codigo') !== false) {
                $mensaje = "El código del docente ya está registrado.";

            } elseif (strpos($mensajeSQL, 'cedula') !== false) {
                $mensaje = "La cédula profesional ya está registrada.";

            } elseif (strpos($mensajeSQL, 'curp') !== false) {
                $mensaje = "La CURP ya está registrada.";

            } elseif (strpos($mensajeSQL, 'rfc') !== false) {
                $mensaje = "El RFC ya está registrado.";

            } elseif (strpos($mensajeSQL, 'email') !== false) {
                $mensaje = "El correo electrónico ya está registrado.";

            } else {
                $mensaje = "Uno de los datos únicos ya está registrado.";
            }

        } else {
            $codigoHTTP = 500;
            $mensaje = "Ocurrió un error al guardar el docente.";
        }

    } elseif ($e->getCode() === 409) {
        $codigoHTTP = 409;
    }

    http_response_code($codigoHTTP);

    echo json_encode([
        "success" => false,
        "message" => $mensaje
    ], JSON_UNESCAPED_UNICODE);
}

$conn->close();

?>
