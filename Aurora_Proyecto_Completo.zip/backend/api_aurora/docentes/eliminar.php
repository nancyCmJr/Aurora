<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'docentes', 'eliminar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($status, $mensaje, $datos = []) {
    http_response_code($status);

    echo json_encode(array_merge([
        "success" => $status >= 200 && $status < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

/* -----------------------------------------
   1. Validar JSON
----------------------------------------- */

$data = json_decode(file_get_contents("php://input"));

if (!is_object($data)) {
    responder(400, "El formato JSON no es válido");
}

$id_docente = $data->id_docente ?? null;

if (
    !(is_int($id_docente) && $id_docente > 0) &&
    !(is_string($id_docente) &&
      ctype_digit($id_docente) &&
      filter_var($id_docente, FILTER_VALIDATE_INT) !== false &&
      (int)$id_docente > 0)
) {
    responder(400, "Debes proporcionar un ID de docente válido");
}

$id_docente = (int)$id_docente;

$stmt = null;

try {

    $conn->begin_transaction();

    /* -----------------------------------------
       2. Bloquear y consultar docente
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_docente, estado
        FROM docentes
        WHERE id_docente = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_docente);
    $stmt->execute();

    $docente = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$docente) {
        throw new DomainException(
            "No se encontró el docente",
            404
        );
    }

    if ($docente["estado"] === "Baja") {
        throw new DomainException(
            "El docente ya se encuentra dado de baja",
            409
        );
    }

    /* -----------------------------------------
       3. Verificar contratos activos
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_contrato
        FROM contratos
        WHERE id_docente = ?
          AND status = 'Activo'
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_docente);
    $stmt->execute();

    $contratos = $stmt->get_result();

    $totalContratos = 0;

    while ($contratos->fetch_assoc()) {
        $totalContratos++;
    }

    $stmt->close();
    $stmt = null;

    if ($totalContratos > 0) {
        throw new DomainException(
            "No se puede dar de baja al docente porque tiene contratos activos. Primero debes gestionar sus contratos.",
            409
        );
    }

    /* -----------------------------------------
       4. Verificar grupos planeados o abiertos
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_grupo
        FROM grupos
        WHERE id_docente = ?
          AND estado IN ('Planeado', 'Abierto')
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_docente);
    $stmt->execute();

    $grupos = $stmt->get_result();

    $totalGrupos = 0;

    while ($grupos->fetch_assoc()) {
        $totalGrupos++;
    }

    $stmt->close();
    $stmt = null;

    if ($totalGrupos > 0) {
        throw new DomainException(
            "No se puede dar de baja al docente porque tiene grupos planeados o abiertos. Primero debes reasignarlos o cambiar su estado.",
            409
        );
    }

    /* -----------------------------------------
       5. Realizar baja lógica
    ----------------------------------------- */

    $stmt = $conn->prepare("
        UPDATE docentes
        SET estado = 'Baja'
        WHERE id_docente = ?
          AND estado <> 'Baja'
    ");

    $stmt->bind_param("i", $id_docente);
    $stmt->execute();

    if ($stmt->affected_rows !== 1) {
        throw new DomainException(
            "No fue posible actualizar el estado del docente",
            409
        );
    }

    $stmt->close();
    $stmt = null;

    /* -----------------------------------------
       6. Confirmar transacción
    ----------------------------------------- */

    $conn->commit();

    responder(200, "Docente dado de baja correctamente", [
        "data" => [
            "id_docente" => $id_docente,
            "estado" => "Baja"
        ]
    ]);

} catch (DomainException $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    $codigoHTTP = $e->getCode();

    if ($codigoHTTP < 400 || $codigoHTTP > 599) {
        $codigoHTTP = 400;
    }

    responder($codigoHTTP, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error SQL docentes/eliminar.php: " . $e->getMessage()
    );

    if (
        (int)$e->getCode() === 1213 ||
        (int)$e->getCode() === 1205
    ) {
        responder(
            409,
            "La operación tuvo un conflicto con otra actualización. Intenta nuevamente."
        );
    }

    responder(500, "Error de base de datos al dar de baja al docente");

} catch (Throwable $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error docentes/eliminar.php: " . $e->getMessage()
    );

    responder(500, "Error interno al dar de baja al docente");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
