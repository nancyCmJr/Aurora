<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'docentes', 'listar');


header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$sql = "SELECT
            d.id_docente,
            d.codigo,
            d.cedula,
            d.nombre,
            d.seg_nombre,
            d.apellidos,
            d.titulo_academico,
            d.estado,

            dd.id_detalle_doc,
            dd.curp,
            dd.rfc,
            dd.fecha_nacimiento,
            dd.telefono,
            dd.email,
            dd.calle,
            dd.numero_exterior,
            dd.numero_interior,
            dd.colonia,
            dd.codigo_postal,
            dd.municipio,
            dd.estado AS estado_domicilio,
            dd.referencias,
            dd.fecha_ingreso

        FROM docentes d

        LEFT JOIN detalle_docentes dd
            ON d.id_docente = dd.id_docente

        ORDER BY d.apellidos, d.nombre";

$result = $conn->query($sql);

if ($result) {

    $docentes = [];

    while ($fila = $result->fetch_assoc()) {
        $docentes[] = $fila;
    }

    echo json_encode([
        "success" => true,
        "message" => "Lista de docentes obtenida correctamente",
        "data" => $docentes
    ], JSON_UNESCAPED_UNICODE);

} else {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error al consultar los docentes"
    ]);
}

$conn->close();

?>
