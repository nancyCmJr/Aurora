<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'docentes', 'consultar');


header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

if (
    !isset($_GET['id_docente']) ||
    !ctype_digit($_GET['id_docente']) ||
    (int)$_GET['id_docente'] <= 0
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Debes proporcionar un ID de docente válido"
    ]);
    exit();
}

$id_docente = (int)$_GET['id_docente'];

$sql = "SELECT
            d.id_docente,
            d.codigo,
            d.cedula,
            d.nombre,
            d.seg_nombre,
            d.apellidos,
            d.titulo_academico,
            d.estado,

            dd.id_detalle_doc,
            dd.curp,
            dd.rfc,
            dd.fecha_nacimiento,
            dd.telefono,
            dd.email,
            dd.calle,
            dd.numero_exterior,
            dd.numero_interior,
            dd.colonia,
            dd.codigo_postal,
            dd.municipio,
            dd.estado AS estado_domicilio,
            dd.referencias,
            dd.fecha_ingreso

        FROM docentes d

        LEFT JOIN detalle_docentes dd
            ON d.id_docente = dd.id_docente

        WHERE d.id_docente = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_docente);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {

    $docente = $result->fetch_assoc();

    echo json_encode([
        "success" => true,
        "message" => "Docente encontrado",
        "data" => $docente
    ], JSON_UNESCAPED_UNICODE);

} else {

    http_response_code(404);

    echo json_encode([
        "success" => false,
        "message" => "No se encontró el docente"
    ], JSON_UNESCAPED_UNICODE);
}

$stmt->close();
$conn->close();

?>