<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion=auroraAutorizarEndpoint($conn,'alumnos','eliminar');
require_once __DIR__ . '/../lib/academico.php';
if ($_SERVER['REQUEST_METHOD']!=='POST') auroraResponder(405,'Método no permitido');
$d=auroraJson();$numero=trim((string)($d['numero_control']??''));
if ($numero==='' || mb_strlen($numero)>20) auroraResponder(400,'Número de control inválido');
try {
    $conn->begin_transaction();
    $al=auroraFila($conn,'SELECT numero_control,estado FROM alumnos WHERE numero_control=? FOR UPDATE',[$numero]);
    if (!$al) throw new DomainException('Alumno inexistente',404);
    if ($al['estado']==='Baja definitiva') throw new DomainException('El alumno ya está dado de baja',409);
    $act=auroraFila($conn,"SELECT
      (SELECT COUNT(*) FROM inscripciones WHERE numero_control=? AND estado='En curso') AS inscripciones,
      (SELECT COUNT(*) FROM kardex WHERE numero_control=? AND estado='Cursando') AS materias",[$numero,$numero]);
    if ((int)$act['inscripciones']>0 || (int)$act['materias']>0)
        throw new DomainException('Primero finaliza/cancela las inscripciones y materias cursándose',409);
    auroraModificar($conn,"UPDATE alumnos SET estado='Baja definitiva' WHERE numero_control=?",[$numero]);
    $conn->commit();
    auroraResponder(200,'Alumno dado de baja sin eliminar su historial',['data'=>['numero_control'=>$numero,'estado'=>'Baja definitiva']]);
} catch(Throwable $e){auroraFallo($e,$conn);}
