<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'alumnos', 'actualizar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

function valorOpcional($valor) {
    if ($valor === null) {
        return null;
    }

    $valor = trim((string)$valor);
    return $valor === '' ? null : $valor;
}

$data = json_decode(file_get_contents("php://input"));

if (!is_object($data)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El formato JSON no es válido"
    ]);
    exit();
}

// 1. Validar datos obligatorios.
if (
    !isset($data->numero_control) ||
    !isset($data->nombre) ||
    !isset($data->apellidos) ||
    !isset($data->semestre) ||
    !isset($data->estado)
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Faltan datos obligatorios"
    ]);
    exit();
}

// 2. Obtener información principal.
$numero_control = trim((string)$data->numero_control);
$nombre = trim((string)$data->nombre);
$seg_nombre = valorOpcional($data->seg_nombre ?? null);
$apellidos = trim((string)$data->apellidos);
$semestre = (int)$data->semestre;
$estado = trim((string)$data->estado);

// Estados permitidos según la tabla alumnos.
$estadosPermitidos = [
    'Activo',
    'Baja temporal',
    'Baja definitiva',
    'Egresado',
    'Titulado'
];

if (
    $numero_control === '' ||
    $nombre === '' ||
    $apellidos === '' ||
    $semestre < 1 ||
    $semestre > 20 ||
    !in_array($estado, $estadosPermitidos, true)
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Los datos del alumno no son válidos"
    ]);
    exit();
}

try {

    $conn->begin_transaction();

    // 3. Verificar que el alumno exista y bloquear su registro.
    $sql = "SELECT numero_control
            FROM alumnos
            WHERE numero_control = ?
            LIMIT 1
            FOR UPDATE";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $numero_control);
    $stmt->execute();

    if ($stmt->get_result()->num_rows === 0) {
        $stmt->close();

        throw new Exception(
            "No se encontró el alumno.",
            404
        );
    }

    $stmt->close();

    // 4. Actualizar información principal.
    $sql = "UPDATE alumnos
            SET nombre = ?,
                seg_nombre = ?,
                apellidos = ?,
                semestre = ?,
                estado = ?
            WHERE numero_control = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "sssiss",
        $nombre,
        $seg_nombre,
        $apellidos,
        $semestre,
        $estado,
        $numero_control
    );

    $stmt->execute();
    $stmt->close();

    // 5. Actualizar o insertar datos complementarios.
    if (
        isset($data->detalle) &&
        is_object($data->detalle)
    ) {

        $detalle = $data->detalle;

        $curp = valorOpcional($detalle->curp ?? null);
        $fecha_nacimiento = valorOpcional($detalle->fecha_nacimiento ?? null);
        $telefono = valorOpcional($detalle->telefono ?? null);
        $email = valorOpcional($detalle->email ?? null);
        $calle = valorOpcional($detalle->calle ?? null);
        $numero_exterior = valorOpcional($detalle->numero_exterior ?? null);
        $numero_interior = valorOpcional($detalle->numero_interior ?? null);
        $colonia = valorOpcional($detalle->colonia ?? null);
        $codigo_postal = valorOpcional($detalle->codigo_postal ?? null);
        $municipio = valorOpcional($detalle->municipio ?? null);
        $estado_domicilio = valorOpcional($detalle->estado ?? null);
        $referencias = valorOpcional($detalle->referencias ?? null);
        $datos_contacto = valorOpcional($detalle->datos_contacto ?? null);
        $situacion_academica = valorOpcional($detalle->situacion_academica ?? null);
        $fecha_ingreso = valorOpcional($detalle->fecha_ingreso ?? null);

        // 5.1 Verificar que la CURP no pertenezca a otro alumno.
        if ($curp !== null) {

            $sql = "SELECT numero_control
                    FROM detalle_alumno
                    WHERE curp = ?
                      AND numero_control <> ?
                    LIMIT 1";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ss",
                $curp,
                $numero_control
            );

            $stmt->execute();

            if ($stmt->get_result()->num_rows > 0) {
                $stmt->close();

                throw new Exception(
                    "La CURP ya está registrada por otro alumno.",
                    409
                );
            }

            $stmt->close();
        }

        // 5.2 Verificar que el correo no pertenezca a otro alumno.
        if ($email !== null) {

            $sql = "SELECT numero_control
                    FROM detalle_alumno
                    WHERE email = ?
                      AND numero_control <> ?
                    LIMIT 1";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ss",
                $email,
                $numero_control
            );

            $stmt->execute();

            if ($stmt->get_result()->num_rows > 0) {
                $stmt->close();

                throw new Exception(
                    "El correo electrónico ya está registrado por otro alumno.",
                    409
                );
            }

            $stmt->close();
        }

        // 5.3 Comprobar si ya existen datos complementarios.
        $sql = "SELECT id_detalle_alu
                FROM detalle_alumno
                WHERE numero_control = ?
                LIMIT 1";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $numero_control);
        $stmt->execute();

        $resultado = $stmt->get_result();
        $existeDetalle = $resultado->num_rows > 0;

        $stmt->close();

        if ($existeDetalle) {

            // Actualizar el detalle del mismo alumno.
            $sql = "UPDATE detalle_alumno
                    SET curp = ?,
                        fecha_nacimiento = ?,
                        telefono = ?,
                        email = ?,
                        calle = ?,
                        numero_exterior = ?,
                        numero_interior = ?,
                        colonia = ?,
                        codigo_postal = ?,
                        municipio = ?,
                        estado = ?,
                        referencias = ?,
                        datos_contacto = ?,
                        situacion_academica = ?,
                        fecha_ingreso = ?
                    WHERE numero_control = ?";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssssssssssss",
                $curp,
                $fecha_nacimiento,
                $telefono,
                $email,
                $calle,
                $numero_exterior,
                $numero_interior,
                $colonia,
                $codigo_postal,
                $municipio,
                $estado_domicilio,
                $referencias,
                $datos_contacto,
                $situacion_academica,
                $fecha_ingreso,
                $numero_control
            );

        } else {

            // Insertar el detalle si todavía no existe.
            $sql = "INSERT INTO detalle_alumno (
                        numero_control,
                        curp,
                        fecha_nacimiento,
                        telefono,
                        email,
                        calle,
                        numero_exterior,
                        numero_interior,
                        colonia,
                        codigo_postal,
                        municipio,
                        estado,
                        referencias,
                        datos_contacto,
                        situacion_academica,
                        fecha_ingreso
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                "ssssssssssssssss",
                $numero_control,
                $curp,
                $fecha_nacimiento,
                $telefono,
                $email,
                $calle,
                $numero_exterior,
                $numero_interior,
                $colonia,
                $codigo_postal,
                $municipio,
                $estado_domicilio,
                $referencias,
                $datos_contacto,
                $situacion_academica,
                $fecha_ingreso
            );
        }

        $stmt->execute();
        $stmt->close();
    }

    // 6. La carrera pertenece al historial de INSCRIPCIONES, no a ALUMNOS.
    // Nunca actualizarla aquí: cambiaría (o invalidaría) inscripciones históricas.
    if (isset($data->id_carrera)) {
        $id_carrera = filter_var($data->id_carrera, FILTER_VALIDATE_INT);
        if ($id_carrera === false || $id_carrera < 1) {
            throw new DomainException('La carrera no es válida', 400);
        }
        $stmt = $conn->prepare("SELECT id_carrera FROM inscripciones
            WHERE numero_control = ? ORDER BY anio DESC, id_inscripciones DESC LIMIT 1");
        $stmt->bind_param('s', $numero_control);
        $stmt->execute();
        $inscripcionActual = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if (!$inscripcionActual || (int)$inscripcionActual['id_carrera'] !== (int)$id_carrera) {
            throw new DomainException('Para cambiar de carrera registra una inscripción en un nuevo ciclo; no modifiques el historial', 409);
        }
    }

    // 7. Confirmar cambios.
    $conn->commit();

    echo json_encode([
        "success" => true,
        "message" => "Alumno actualizado correctamente",
        "data" => [
            "numero_control" => $numero_control
        ]
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {

    $conn->rollback();

    $mensaje = $e->getMessage();
    $codigo = 400;

    if ($e instanceof mysqli_sql_exception) {

        if ((int)$e->getCode() === 1062) {

            $codigo = 409;
            $mensajeSQL = strtolower($mensaje);

            if (strpos($mensajeSQL, 'curp') !== false) {
                $mensaje = "La CURP ya está registrada por otro alumno.";

            } elseif (strpos($mensajeSQL, 'email') !== false) {
                $mensaje = "El correo electrónico ya está registrado por otro alumno.";

            } elseif (strpos($mensajeSQL, 'numero_control') !== false) {
                $mensaje = "El número de control ya está registrado.";

            } else {
                $mensaje = "Uno de los datos únicos ya está registrado.";
            }

        } elseif ((int)$e->getCode() === 1452) {
            $mensaje = "No se pudo completar la actualización porque una referencia relacionada no existe.";

        } else {
            $codigo = 500;
            $mensaje = "Ocurrió un error al actualizar el alumno.";
        }

    } elseif (in_array($e->getCode(), [404, 409], true)) {
        $codigo = $e->getCode();
    }

    http_response_code($codigo);

    echo json_encode([
        "success" => false,
        "message" => $mensaje
    ], JSON_UNESCAPED_UNICODE);
}

$conn->close();
?>
