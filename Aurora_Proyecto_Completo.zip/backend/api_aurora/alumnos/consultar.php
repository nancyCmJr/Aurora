<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'alumnos', 'consultar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

if (!isset($_GET['numero_control']) || trim($_GET['numero_control']) === '') {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Debes proporcionar el número de control"
    ]);
    exit();
}

$numero_control = trim($_GET['numero_control']);

$sql = "SELECT
            a.numero_control,
            a.nombre,
            a.seg_nombre,
            a.apellidos,
            a.semestre,
            a.estado,
            a.fecha_registro,

            d.id_detalle_alu,
            d.curp,
            d.fecha_nacimiento,
            d.telefono,
            d.email,
            d.calle,
            d.numero_exterior,
            d.numero_interior,
            d.colonia,
            d.codigo_postal,
            d.municipio,
            d.estado AS estado_domicilio,
            d.referencias,
            d.datos_contacto,
            d.situacion_academica,
            d.fecha_ingreso,

            i.id_inscripciones,
            i.id_carrera,
            i.fecha_inscripcion,
            i.periodo,
            i.anio,
            i.estado AS estado_inscripcion,

            c.nombre AS carrera,
            c.tipo AS tipo_carrera

        FROM alumnos a

        LEFT JOIN detalle_alumno d
            ON a.numero_control = d.numero_control

        LEFT JOIN inscripciones i
            ON a.numero_control = i.numero_control
            AND i.id_inscripciones = (
                SELECT i2.id_inscripciones FROM inscripciones i2
                WHERE i2.numero_control = a.numero_control
                ORDER BY i2.anio DESC, i2.id_inscripciones DESC LIMIT 1
            )

        LEFT JOIN carreras c
            ON i.id_carrera = c.id_carrera

        WHERE a.numero_control = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $numero_control);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows > 0) {

    $alumno = $result->fetch_assoc();
    $stmtHist = $conn->prepare("SELECT id_inscripciones, id_carrera, fecha_inscripcion,
        periodo, anio, estado FROM inscripciones WHERE numero_control = ?
        ORDER BY anio DESC, id_inscripciones DESC");
    $stmtHist->bind_param('s', $numero_control);
    $stmtHist->execute();
    $inscripcionesHistoricas = $stmtHist->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmtHist->close();

    echo json_encode([
        "success" => true,
        "message" => "Alumno encontrado",
        "data" => $alumno,
        "inscripciones" => $inscripcionesHistoricas
    ], JSON_UNESCAPED_UNICODE);

} else {

    http_response_code(404);

    echo json_encode([
        "success" => false,
        "message" => "No se encontró el alumno"
    ], JSON_UNESCAPED_UNICODE);
}

$stmt->close();
$conn->close();

?>
