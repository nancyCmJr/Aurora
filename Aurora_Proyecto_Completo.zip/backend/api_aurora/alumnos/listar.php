<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'alumnos', 'listar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$sql = "SELECT
            a.numero_control,
            a.nombre,
            a.seg_nombre,
            a.apellidos,
            a.semestre,
            a.estado,
            a.fecha_registro,
            d.curp,
            d.fecha_nacimiento,
            d.telefono,
            d.email,
            i.id_inscripciones,
            i.id_carrera,
            i.fecha_inscripcion,
            i.periodo,
            i.anio,
            i.estado AS estado_inscripcion,
            c.nombre AS carrera
        FROM alumnos a
        LEFT JOIN detalle_alumno d
            ON a.numero_control = d.numero_control
        LEFT JOIN inscripciones i
            ON a.numero_control = i.numero_control
            AND i.id_inscripciones = (
                SELECT i2.id_inscripciones FROM inscripciones i2
                WHERE i2.numero_control = a.numero_control
                ORDER BY i2.anio DESC, i2.id_inscripciones DESC LIMIT 1
            )
        LEFT JOIN carreras c
            ON i.id_carrera = c.id_carrera
        ORDER BY a.apellidos, a.nombre";

$result = $conn->query($sql);

if ($result) {

    $alumnos = [];

    while ($fila = $result->fetch_assoc()) {
        $alumnos[] = $fila;
    }

    echo json_encode([
        "success" => true,
        "message" => "Lista de alumnos obtenida correctamente",
        "data" => $alumnos
    ], JSON_UNESCAPED_UNICODE);

} else {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error al consultar los alumnos"
    ]);
}

$conn->close();

?>
