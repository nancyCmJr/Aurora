<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'alumnos', 'registrar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

function valorOpcional($valor) {
    if ($valor === null) {
        return null;
    }

    $valor = trim((string)$valor);
    return $valor === '' ? null : $valor;
}

$data = json_decode(file_get_contents("php://input"));

if (
    !is_object($data) ||
    !isset($data->numero_control) ||
    !isset($data->nombre) ||
    !isset($data->apellidos) ||
    !isset($data->id_carrera)
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Faltan datos obligatorios o el JSON no es válido"
    ]);
    exit();
}

$numero_control = trim((string)$data->numero_control);
$nombre = trim((string)$data->nombre);
$seg_nombre = valorOpcional($data->seg_nombre ?? null);
$apellidos = trim((string)$data->apellidos);
$semestre = isset($data->semestre) ? (int)$data->semestre : 1;
$id_carrera = (int)$data->id_carrera;

// Aurora: el alta del alumno también registra su PRIMERA inscripción académica.
// Los ciclos posteriores se registran exclusivamente en inscripciones/registrar.php.
$periodo = isset($data->periodo) && is_string($data->periodo) ? trim($data->periodo) : '';
$anio = filter_var($data->anio ?? null, FILTER_VALIDATE_INT);
if ($periodo === '' || mb_strlen($periodo, 'UTF-8') > 20 || $anio === false || $anio < 1901 || $anio > 2155) {
    http_response_code(400);
    echo json_encode(['success'=>false,'message'=>'Debes indicar periodo y anio de la primera inscripción'], JSON_UNESCAPED_UNICODE);
    exit();
}


if (
    $numero_control === '' ||
    $nombre === '' ||
    $apellidos === '' ||
    $id_carrera <= 0 ||
    $semestre < 1 ||
    $semestre > 20
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Verifica los datos del alumno"
    ]);
    exit();
}

// Datos complementarios opcionales.
$curp = valorOpcional($data->curp ?? null);
$fecha_nacimiento = valorOpcional($data->fecha_nacimiento ?? null);
$telefono = valorOpcional($data->telefono ?? null);
$email = valorOpcional($data->email ?? null);
$calle = valorOpcional($data->calle ?? null);
$numero_exterior = valorOpcional($data->numero_exterior ?? null);
$numero_interior = valorOpcional($data->numero_interior ?? null);
$colonia = valorOpcional($data->colonia ?? null);
$codigo_postal = valorOpcional($data->codigo_postal ?? null);
$municipio = valorOpcional($data->municipio ?? null);
$estado_domicilio = valorOpcional($data->estado ?? null);
$referencias = valorOpcional($data->referencias ?? null);
$datos_contacto = valorOpcional($data->datos_contacto ?? null);
$situacion_academica = valorOpcional($data->situacion_academica ?? null);
$fecha_ingreso = valorOpcional($data->fecha_ingreso ?? null);

try {

    $conn->begin_transaction();

    // 1. Verificar número de control.
    $sql = "SELECT numero_control
            FROM alumnos
            WHERE numero_control = ?
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $numero_control);
    $stmt->execute();

    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();
        throw new Exception(
            "El número de control ya está registrado.",
            409
        );
    }

    $stmt->close();

    // 2. Verificar CURP y correo electrónico.
    $camposUnicos = [
        "curp" => $curp,
        "email" => $email
    ];

    foreach ($camposUnicos as $campo => $valor) {

        if ($valor === null) {
            continue;
        }

        $sql = "SELECT numero_control
                FROM detalle_alumno
                WHERE $campo = ?
                LIMIT 1";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $valor);
        $stmt->execute();

        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();

            $mensaje = $campo === "curp"
                ? "La CURP ya está registrada."
                : "El correo electrónico ya está registrado.";

            throw new Exception($mensaje, 409);
        }

        $stmt->close();
    }

    // 3. Verificar que la carrera exista y esté activa.
    $sql = "SELECT id_carrera
            FROM carreras
            WHERE id_carrera = ?
              AND estado = 'Activa'
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_carrera);
    $stmt->execute();

    if ($stmt->get_result()->num_rows === 0) {
        $stmt->close();
        throw new Exception(
            "La carrera no existe o se encuentra inactiva."
        );
    }

    $stmt->close();

    // 4. Registrar alumno.
    $sql = "INSERT INTO alumnos (
                numero_control,
                nombre,
                seg_nombre,
                apellidos,
                semestre
            ) VALUES (?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ssssi",
        $numero_control,
        $nombre,
        $seg_nombre,
        $apellidos,
        $semestre
    );

    $stmt->execute();
    $stmt->close();

    // 5. Registrar detalles del alumno.
    $sql = "INSERT INTO detalle_alumno (
                numero_control,
                curp,
                fecha_nacimiento,
                telefono,
                email,
                calle,
                numero_exterior,
                numero_interior,
                colonia,
                codigo_postal,
                municipio,
                estado,
                referencias,
                datos_contacto,
                situacion_academica,
                fecha_ingreso
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ssssssssssssssss",
        $numero_control,
        $curp,
        $fecha_nacimiento,
        $telefono,
        $email,
        $calle,
        $numero_exterior,
        $numero_interior,
        $colonia,
        $codigo_postal,
        $municipio,
        $estado_domicilio,
        $referencias,
        $datos_contacto,
        $situacion_academica,
        $fecha_ingreso
    );

    $stmt->execute();
    $stmt->close();

    // 6. Registrar inscripción.
    $sql = "INSERT INTO inscripciones (
                numero_control,
                id_carrera,
                periodo,
                anio
            ) VALUES (?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sisi", $numero_control, $id_carrera, $periodo, $anio);
    $stmt->execute();
    $stmt->close();

    $conn->commit();

    http_response_code(201);

    echo json_encode([
        "success" => true,
        "message" => "Alumno registrado correctamente",
        "data" => [
            "numero_control" => $numero_control,
            "id_carrera" => $id_carrera,
            "periodo" => $periodo,
            "anio" => $anio
        ]
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {

    $conn->rollback();

    $mensaje = $e->getMessage();
    $codigo = 400;

    if ($e instanceof mysqli_sql_exception) {

        if ((int)$e->getCode() === 1062) {
            $codigo = 409;
            $mensajeSQL = strtolower($mensaje);

            if (strpos($mensajeSQL, 'curp') !== false) {
                $mensaje = "La CURP ya está registrada.";
            } elseif (strpos($mensajeSQL, 'email') !== false) {
                $mensaje = "El correo electrónico ya está registrado.";
            } elseif (
                strpos($mensajeSQL, 'numero_control') !== false ||
                strpos($mensajeSQL, 'primary') !== false
            ) {
                $mensaje = "El número de control ya está registrado.";
            } else {
                $mensaje = "Uno de los datos únicos ya está registrado.";
            }

        } elseif ((int)$e->getCode() === 1452) {
            $mensaje = "No se pudo completar el registro porque una referencia relacionada no existe.";

        } else {
            $codigo = 500;
            $mensaje = "Ocurrió un error al guardar el alumno.";
        }

    } elseif ($e->getCode() === 409) {
        $codigo = 409;
    }

    http_response_code($codigo);

    echo json_encode([
        "success" => false,
        "message" => $mensaje
    ], JSON_UNESCAPED_UNICODE);
}

$conn->close();
?>
