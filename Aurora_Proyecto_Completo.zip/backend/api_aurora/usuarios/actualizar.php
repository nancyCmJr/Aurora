<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'usuarios', 'actualizar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "JSON inválido"
    ]);
    exit();
}

// 1. Obtener datos.
$codigo = trim((string)($data["codigo"] ?? ""));
$nombre_usuario = trim((string)($data["nombre_usuario"] ?? ""));
$rol = $data["rol"] ?? "";
$correo = trim((string)($data["correo"] ?? ""));
$password = $data["password"] ?? "";
$numero_control = $data["numero_control"] ?? null;
$id_docente = $data["id_docente"] ?? null;
$estado = $data["estado"] ?? "";

// Normalizar campos opcionales.
$numero_control = (
    $numero_control === "" || $numero_control === null
) ? null : trim((string)$numero_control);

$id_docente = (
    $id_docente === "" || $id_docente === null
) ? null : filter_var($id_docente, FILTER_VALIDATE_INT);

$rolesPermitidos = ["Admin", "Docente", "Alumno"];
$estadosPermitidos = ["Activo", "Inactivo", "Bloqueado"];

// 2. Validar información general.
if (
    $codigo === "" ||
    $nombre_usuario === "" ||
    strlen($nombre_usuario) > 50 ||
    !in_array($rol, $rolesPermitidos, true) ||
    $correo === "" ||
    strlen($correo) > 100 ||
    !filter_var($correo, FILTER_VALIDATE_EMAIL) ||
    !in_array($estado, $estadosPermitidos, true) ||
    ($password !== "" && (!is_string($password) || strlen($password) < 12 || strlen($password) > 128))
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Verifica los datos enviados"
    ]);
    exit();
}

// El administrador que gestiona usuarios no puede bloquear su propio acceso.
if ($codigo === $usuarioSesion['codigo'] && ($rol !== 'Admin' || $estado !== 'Activo')) {
    http_response_code(409);
    echo json_encode(['success'=>false,'message'=>'No puedes desactivar, bloquear ni quitar tu propio rol administrativo'], JSON_UNESCAPED_UNICODE);
    exit();
}

// 3. Validar relación según el rol.
if (
    ($rol === "Admin" &&
        ($numero_control !== null || $id_docente !== null)) ||

    ($rol === "Alumno" &&
        ($numero_control === null || $id_docente !== null)) ||

    ($rol === "Docente" &&
        ($numero_control !== null ||
         $id_docente === false ||
         $id_docente === null ||
         $id_docente <= 0))
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Los datos vinculados no corresponden al rol seleccionado"
    ]);
    exit();
}

try {

    $conn->begin_transaction();

    // 4. Comprobar que el usuario exista y bloquear su registro.
    $sql = "SELECT codigo
            FROM usuarios
            WHERE codigo = ?
            LIMIT 1
            FOR UPDATE";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $codigo);
    $stmt->execute();

    if ($stmt->get_result()->num_rows === 0) {
        $stmt->close();

        throw new Exception(
            "El usuario no existe.",
            404
        );
    }

    $stmt->close();

    $stmtAdmin = $conn->prepare('SELECT rol, estado FROM usuarios WHERE codigo=?');
    $stmtAdmin->bind_param('s',$codigo);$stmtAdmin->execute();
    $anterior = $stmtAdmin->get_result()->fetch_assoc();$stmtAdmin->close();
    if (($anterior['rol'] ?? '') === 'Admin' && ($anterior['estado'] ?? '') === 'Activo'
        && ($rol !== 'Admin' || $estado !== 'Activo')) {
        $totalAdmin = $conn->query("SELECT COUNT(*) total FROM usuarios WHERE rol='Admin' AND estado='Activo'")->fetch_assoc();
        if ((int)$totalAdmin['total'] < 2) throw new Exception('Debe conservarse al menos un administrador activo',409);
    }

    // 5. Verificar nombre de usuario duplicado.
    $sql = "SELECT codigo
            FROM usuarios
            WHERE nombre_usuario = ?
              AND codigo <> ?
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ss",
        $nombre_usuario,
        $codigo
    );
    $stmt->execute();

    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();

        throw new Exception(
            "El nombre de usuario ya está registrado.",
            409
        );
    }

    $stmt->close();

    // 6. Verificar correo duplicado.
    $sql = "SELECT codigo
            FROM usuarios
            WHERE correo = ?
              AND codigo <> ?
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ss",
        $correo,
        $codigo
    );
    $stmt->execute();

    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();

        throw new Exception(
            "El correo electrónico ya está registrado.",
            409
        );
    }

    $stmt->close();

    // 7. Validar alumno relacionado.
    if ($rol === "Alumno") {

        $sql = "SELECT numero_control
                FROM alumnos
                WHERE numero_control = ?
                LIMIT 1";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $numero_control);
        $stmt->execute();

        if ($stmt->get_result()->num_rows === 0) {
            $stmt->close();

            throw new Exception(
                "El alumno relacionado no existe.",
                400
            );
        }

        $stmt->close();

        // Comprobar que no esté vinculado a otra cuenta.
        $sql = "SELECT codigo
                FROM usuarios
                WHERE numero_control = ?
                  AND codigo <> ?
                LIMIT 1";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "ss",
            $numero_control,
            $codigo
        );
        $stmt->execute();

        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();

            throw new Exception(
                "El alumno ya tiene una cuenta de usuario vinculada.",
                409
            );
        }

        $stmt->close();
    }

    // 8. Validar docente relacionado.
    if ($rol === "Docente") {

        $sql = "SELECT id_docente
                FROM docentes
                WHERE id_docente = ?
                LIMIT 1";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id_docente);
        $stmt->execute();

        if ($stmt->get_result()->num_rows === 0) {
            $stmt->close();

            throw new Exception(
                "El docente relacionado no existe.",
                400
            );
        }

        $stmt->close();

        // Comprobar que no esté vinculado a otra cuenta.
        $sql = "SELECT codigo
                FROM usuarios
                WHERE id_docente = ?
                  AND codigo <> ?
                LIMIT 1";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param(
            "is",
            $id_docente,
            $codigo
        );
        $stmt->execute();

        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();

            throw new Exception(
                "El docente ya tiene una cuenta de usuario vinculada.",
                409
            );
        }

        $stmt->close();
    }

    // 9. Actualizar usuario.
    if ($password !== "") {

        $passwordHash = password_hash(
            $password,
            PASSWORD_DEFAULT
        );

        $sql = "UPDATE usuarios
                SET nombre_usuario = ?,
                    rol = ?,
                    correo = ?,
                    password = ?,
                    numero_control = ?,
                    id_docente = ?,
                    estado = ?
                WHERE codigo = ?";

        $stmt = $conn->prepare($sql);

        $stmt->bind_param(
            "ssssssss",
            $nombre_usuario,
            $rol,
            $correo,
            $passwordHash,
            $numero_control,
            $id_docente,
            $estado,
            $codigo
        );

    } else {

        $sql = "UPDATE usuarios
                SET nombre_usuario = ?,
                    rol = ?,
                    correo = ?,
                    numero_control = ?,
                    id_docente = ?,
                    estado = ?
                WHERE codigo = ?";

        $stmt = $conn->prepare($sql);

        $stmt->bind_param(
            "sssssss",
            $nombre_usuario,
            $rol,
            $correo,
            $numero_control,
            $id_docente,
            $estado,
            $codigo
        );
    }

    $stmt->execute();
    $stmt->close();

    $conn->commit();

    echo json_encode([
        "success" => true,
        "message" => "Usuario actualizado correctamente",
        "data" => [
            "codigo" => $codigo,
            "nombre_usuario" => $nombre_usuario,
            "rol" => $rol
        ]
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {

    $conn->rollback();

    $mensaje = $e->getMessage();
    $codigoHTTP = 400;

    if ($e instanceof mysqli_sql_exception) {

        if ((int)$e->getCode() === 1062) {

            $codigoHTTP = 409;
            $mensajeSQL = strtolower($mensaje);

            if (strpos($mensajeSQL, "nombre_usuario") !== false) {
                $mensaje = "El nombre de usuario ya está registrado.";

            } elseif (strpos($mensajeSQL, "correo") !== false) {
                $mensaje = "El correo electrónico ya está registrado.";

            } elseif (strpos($mensajeSQL, "numero_control") !== false) {
                $mensaje = "El alumno ya tiene una cuenta vinculada.";

            } elseif (strpos($mensajeSQL, "id_docente") !== false) {
                $mensaje = "El docente ya tiene una cuenta vinculada.";

            } else {
                $mensaje = "Uno de los datos únicos ya está registrado.";
            }

        } else {
            $codigoHTTP = 500;
            $mensaje = "Ocurrió un error al actualizar el usuario.";
        }

    } elseif (in_array($e->getCode(), [404, 409], true)) {
        $codigoHTTP = $e->getCode();
    }

    http_response_code($codigoHTTP);

    echo json_encode([
        "success" => false,
        "message" => $mensaje
    ], JSON_UNESCAPED_UNICODE);
}

$conn->close();
?>
