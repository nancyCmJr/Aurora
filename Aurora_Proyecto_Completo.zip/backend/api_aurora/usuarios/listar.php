<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'usuarios', 'listar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

try {

    $sql = "
        SELECT
            u.codigo,
            u.nombre_usuario,
            u.rol,
            u.correo,
            u.numero_control,
            u.id_docente,
            u.estado,
            u.fecha_creacion,

            a.nombre AS nombre_alumno,
            a.seg_nombre AS segundo_nombre_alumno,
            a.apellidos AS apellidos_alumno,

            d.nombre AS nombre_docente,
            d.seg_nombre AS segundo_nombre_docente,
            d.apellidos AS apellidos_docente

        FROM usuarios u

        LEFT JOIN alumnos a
            ON a.numero_control = u.numero_control

        LEFT JOIN docentes d
            ON d.id_docente = u.id_docente

        ORDER BY u.fecha_creacion DESC, u.codigo ASC
    ";

    $resultado = $conn->query($sql);

    if (!$resultado) {
        throw new Exception("Error al ejecutar la consulta");
    }

    $usuarios = [];

    while ($fila = $resultado->fetch_assoc()) {

        // Construir nombre completo según el rol.
        if ($fila["rol"] === "Alumno") {

            $fila["nombre_completo"] = trim(
                ($fila["nombre_alumno"] ?? "") . " " .
                ($fila["segundo_nombre_alumno"] ?? "") . " " .
                ($fila["apellidos_alumno"] ?? "")
            );

        } elseif ($fila["rol"] === "Docente") {

            $fila["nombre_completo"] = trim(
                ($fila["nombre_docente"] ?? "") . " " .
                ($fila["segundo_nombre_docente"] ?? "") . " " .
                ($fila["apellidos_docente"] ?? "")
            );

        } else {

            $fila["nombre_completo"] = $fila["nombre_usuario"];
        }

        $usuarios[] = $fila;
    }

    echo json_encode([
        "success" => true,
        "total" => count($usuarios),
        "usuarios" => $usuarios
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error al consultar los usuarios"
    ], JSON_UNESCAPED_UNICODE);
}

$conn->close();
?>
