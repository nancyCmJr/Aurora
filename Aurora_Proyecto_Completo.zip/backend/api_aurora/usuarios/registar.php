<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'usuarios', 'registar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "JSON inválido"
    ]);
    exit();
}

// 1. Obtener y normalizar datos.
$codigo = isset($data["codigo"]) && is_string($data["codigo"])
    ? trim($data["codigo"]) : "";

$nombre_usuario = isset($data["nombre_usuario"]) && is_string($data["nombre_usuario"])
    ? trim($data["nombre_usuario"]) : "";

$rol = $data["rol"] ?? "";

$correo = isset($data["correo"]) && is_string($data["correo"])
    ? trim($data["correo"]) : "";

$password = $data["password"] ?? "";

$numero_control = $data["numero_control"] ?? null;
$id_docente = $data["id_docente"] ?? null;

// Normalizar número de control.
$numero_control = (
    $numero_control === "" || $numero_control === null
) ? null : (
    is_string($numero_control)
        ? trim($numero_control)
        : false
);

// Normalizar ID del docente.
$id_docente = (
    $id_docente === "" || $id_docente === null
) ? null : filter_var($id_docente, FILTER_VALIDATE_INT);

// 2. Validar campos obligatorios.
$rolesPermitidos = ["Admin", "Docente", "Alumno"];

if (
    $codigo === "" ||
    strlen($codigo) > 30 ||
    $nombre_usuario === "" ||
    strlen($nombre_usuario) > 50 ||
    !in_array($rol, $rolesPermitidos, true) ||
    $correo === "" ||
    strlen($correo) > 100 ||
    !filter_var($correo, FILTER_VALIDATE_EMAIL) ||
    !is_string($password) ||
    strlen($password) < 12 || strlen($password) > 128
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Verifica el código, nombre de usuario, rol, correo y contraseña"
    ]);
    exit();
}

// 3. Validar relación según el rol.
if (
    ($rol === "Admin" &&
        ($numero_control !== null || $id_docente !== null)) ||

    ($rol === "Alumno" &&
        ($numero_control === null ||
         $numero_control === false ||
         $numero_control === "" ||
         $id_docente !== null)) ||

    ($rol === "Docente" &&
        ($numero_control !== null ||
         $id_docente === false ||
         $id_docente === null ||
         $id_docente <= 0))
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Los datos vinculados no corresponden al rol seleccionado"
    ]);
    exit();
}

if (
    $numero_control !== null &&
    strlen($numero_control) > 20
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El número de control no es válido"
    ]);
    exit();
}

$transaccionIniciada = false;

try {

    $conn->begin_transaction();
    $transaccionIniciada = true;

    // 4. Verificar código duplicado.
    $stmt = $conn->prepare("
        SELECT codigo
        FROM usuarios
        WHERE codigo = ?
        LIMIT 1
    ");

    $stmt->bind_param("s", $codigo);
    $stmt->execute();

    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();
        throw new Exception("El código de usuario ya está registrado.", 409);
    }

    $stmt->close();

    // 5. Verificar nombre de usuario duplicado.
    $stmt = $conn->prepare("
        SELECT codigo
        FROM usuarios
        WHERE nombre_usuario = ?
        LIMIT 1
    ");

    $stmt->bind_param("s", $nombre_usuario);
    $stmt->execute();

    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();
        throw new Exception("El nombre de usuario ya está registrado.", 409);
    }

    $stmt->close();

    // 6. Verificar correo duplicado.
    $stmt = $conn->prepare("
        SELECT codigo
        FROM usuarios
        WHERE correo = ?
        LIMIT 1
    ");

    $stmt->bind_param("s", $correo);
    $stmt->execute();

    if ($stmt->get_result()->num_rows > 0) {
        $stmt->close();
        throw new Exception("El correo electrónico ya está registrado.", 409);
    }

    $stmt->close();

    // 7. Validar alumno relacionado.
    if ($rol === "Alumno") {

        $stmt = $conn->prepare("
            SELECT numero_control
            FROM alumnos
            WHERE numero_control = ?
            LIMIT 1
        ");

        $stmt->bind_param("s", $numero_control);
        $stmt->execute();

        if ($stmt->get_result()->num_rows === 0) {
            $stmt->close();
            throw new Exception("El alumno relacionado no existe.", 400);
        }

        $stmt->close();

        // Verificar que el alumno no tenga otra cuenta.
        $stmt = $conn->prepare("
            SELECT codigo
            FROM usuarios
            WHERE numero_control = ?
            LIMIT 1
        ");

        $stmt->bind_param("s", $numero_control);
        $stmt->execute();

        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();
            throw new Exception("El alumno ya tiene una cuenta de usuario vinculada.", 409);
        }

        $stmt->close();
    }

    // 8. Validar docente relacionado.
    if ($rol === "Docente") {

        $stmt = $conn->prepare("
            SELECT id_docente
            FROM docentes
            WHERE id_docente = ?
            LIMIT 1
        ");

        $stmt->bind_param("i", $id_docente);
        $stmt->execute();

        if ($stmt->get_result()->num_rows === 0) {
            $stmt->close();
            throw new Exception("El docente relacionado no existe.", 400);
        }

        $stmt->close();

        // Verificar que el docente no tenga otra cuenta.
        $stmt = $conn->prepare("
            SELECT codigo
            FROM usuarios
            WHERE id_docente = ?
            LIMIT 1
        ");

        $stmt->bind_param("i", $id_docente);
        $stmt->execute();

        if ($stmt->get_result()->num_rows > 0) {
            $stmt->close();
            throw new Exception("El docente ya tiene una cuenta de usuario vinculada.", 409);
        }

        $stmt->close();
    }

    // 9. Generar hash de contraseña.
    $passwordHash = password_hash(
        $password,
        PASSWORD_DEFAULT
    );

    if ($passwordHash === false) {
        throw new Exception("No fue posible procesar la contraseña.", 500);
    }

    // 10. Registrar usuario.
    $stmt = $conn->prepare("
        INSERT INTO usuarios (
            codigo,
            nombre_usuario,
            rol,
            correo,
            password,
            numero_control,
            id_docente
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    // Se utilizan strings para conservar correctamente los NULL
    // de los campos de vinculación opcionales.
    $stmt->bind_param(
        "sssssss",
        $codigo,
        $nombre_usuario,
        $rol,
        $correo,
        $passwordHash,
        $numero_control,
        $id_docente
    );

    $stmt->execute();
    $stmt->close();

    $conn->commit();
    $transaccionIniciada = false;

    http_response_code(201);

    echo json_encode([
        "success" => true,
        "message" => "Usuario registrado correctamente",
        "data" => [
            "codigo" => $codigo,
            "nombre_usuario" => $nombre_usuario,
            "rol" => $rol
        ]
    ], JSON_UNESCAPED_UNICODE);

} catch (mysqli_sql_exception $e) {

    if ($transaccionIniciada) {
        $conn->rollback();
    }

    $codigoHTTP = 500;
    $mensaje = "Error interno al registrar el usuario.";

    if ((int)$e->getCode() === 1062) {

        $codigoHTTP = 409;
        $mensajeSQL = strtolower($e->getMessage());

        if (strpos($mensajeSQL, "codigo") !== false) {
            $mensaje = "El código de usuario ya está registrado.";

        } elseif (strpos($mensajeSQL, "nombre_usuario") !== false) {
            $mensaje = "El nombre de usuario ya está registrado.";

        } elseif (strpos($mensajeSQL, "correo") !== false) {
            $mensaje = "El correo electrónico ya está registrado.";

        } elseif (strpos($mensajeSQL, "numero_control") !== false) {
            $mensaje = "El alumno ya tiene una cuenta vinculada.";

        } elseif (strpos($mensajeSQL, "id_docente") !== false) {
            $mensaje = "El docente ya tiene una cuenta vinculada.";

        } else {
            $mensaje = "Uno de los datos únicos ya está registrado.";
        }

    } elseif ((int)$e->getCode() === 1452) {

        $codigoHTTP = 400;
        $mensaje = "El alumno o docente relacionado no existe.";
    }

    http_response_code($codigoHTTP);

    echo json_encode([
        "success" => false,
        "message" => $mensaje
    ], JSON_UNESCAPED_UNICODE);

} catch (Exception $e) {

    if ($transaccionIniciada) {
        $conn->rollback();
    }

    $codigoHTTP = in_array($e->getCode(), [400, 409, 500], true)
        ? $e->getCode()
        : 400;

    http_response_code($codigoHTTP);

    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {

    if ($transaccionIniciada) {
        $conn->rollback();
    }

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error interno al registrar el usuario"
    ], JSON_UNESCAPED_UNICODE);
}

$conn->close();
?>
