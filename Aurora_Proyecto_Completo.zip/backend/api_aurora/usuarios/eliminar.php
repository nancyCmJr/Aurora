<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'usuarios', 'eliminar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

// 1. Obtener datos.
$data = json_decode(file_get_contents("php://input"), true);

if (!is_array($data)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "JSON inválido"
    ]);
    exit();
}

// 2. Validar código.
$codigo = isset($data["codigo"]) && is_string($data["codigo"])
    ? trim($data["codigo"])
    : "";

if ($codigo === "" || strlen($codigo) > 30) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Se requiere un código de usuario válido"
    ], JSON_UNESCAPED_UNICODE);

    $conn->close();
    exit();
}

$transaccionIniciada = false;

try {

    // 3. Iniciar transacción.
    $conn->begin_transaction();
    $transaccionIniciada = true;

    // 4. Consultar y bloquear usuario.
    $stmt = $conn->prepare("
        SELECT estado
        FROM usuarios
        WHERE codigo = ?
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->bind_param("s", $codigo);
    $stmt->execute();

    $usuario = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$usuario) {
        throw new Exception("El usuario no existe.", 404);
    }

    if ($codigo === $usuarioSesion['codigo']) {
        throw new Exception('No puedes desactivar tu propia cuenta administradora.', 409);
    }
    $stmtAdmin = $conn->prepare("SELECT rol FROM usuarios WHERE codigo = ?");
    $stmtAdmin->bind_param('s', $codigo);
    $stmtAdmin->execute();
    $esAdmin = ($stmtAdmin->get_result()->fetch_assoc()['rol'] ?? '') === 'Admin';
    $stmtAdmin->close();
    if ($esAdmin) {
        $activos = $conn->query("SELECT COUNT(*) AS total FROM usuarios WHERE rol='Admin' AND estado='Activo'")->fetch_assoc();
        if ((int)$activos['total'] < 2) {
            throw new Exception('No es posible desactivar al último administrador activo.', 409);
        }
    }

    if ($usuario["estado"] === "Inactivo") {
        throw new Exception("El usuario ya se encuentra inactivo.", 409);
    }

    // 5. Desactivar usuario.
    $stmt = $conn->prepare("
        UPDATE usuarios
        SET estado = 'Inactivo'
        WHERE codigo = ?
    ");

    $stmt->bind_param("s", $codigo);
    $stmt->execute();

    if ($stmt->affected_rows !== 1) {
        $stmt->close();
        throw new Exception("No fue posible desactivar el usuario.", 500);
    }

    $stmt->close();

    // 6. Confirmar operación.
    $conn->commit();
    $transaccionIniciada = false;

    echo json_encode([
        "success" => true,
        "message" => "Usuario desactivado correctamente",
        "data" => [
            "codigo" => $codigo,
            "estado" => "Inactivo"
        ]
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {

    if ($transaccionIniciada) {
        $conn->rollback();
    }

    $codigoHTTP = in_array($e->getCode(), [404, 409, 500], true)
        ? $e->getCode()
        : 400;

    if ($e instanceof mysqli_sql_exception) {
        $codigoHTTP = 500;
        $mensaje = "Error interno al desactivar el usuario";
    } else {
        $mensaje = $e->getMessage();
    }

    http_response_code($codigoHTTP);

    echo json_encode([
        "success" => false,
        "message" => $mensaje
    ], JSON_UNESCAPED_UNICODE);
}

$conn->close();
?>
