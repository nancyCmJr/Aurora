<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'usuarios', 'consultar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

// 1. Obtener código.
$codigo = isset($_GET["codigo"]) && is_string($_GET["codigo"])
    ? trim($_GET["codigo"])
    : "";

if ($codigo === "" || strlen($codigo) > 30) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Se requiere un código de usuario válido"
    ], JSON_UNESCAPED_UNICODE);

    $conn->close();
    exit();
}

try {

    // 2. Consultar usuario y sus relaciones.
    $sql = "
        SELECT
            u.codigo,
            u.nombre_usuario,
            u.rol,
            u.correo,
            u.numero_control,
            u.id_docente,
            u.estado,
            u.fecha_creacion,

            a.nombre AS nombre_alumno,
            a.seg_nombre AS segundo_nombre_alumno,
            a.apellidos AS apellidos_alumno,

            d.nombre AS nombre_docente,
            d.seg_nombre AS segundo_nombre_docente,
            d.apellidos AS apellidos_docente

        FROM usuarios u

        LEFT JOIN alumnos a
            ON a.numero_control = u.numero_control

        LEFT JOIN docentes d
            ON d.id_docente = u.id_docente

        WHERE u.codigo = ?
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("s", $codigo);
    $stmt->execute();

    $usuario = $stmt->get_result()->fetch_assoc();

    $stmt->close();

    // 3. Comprobar existencia.
    if (!$usuario) {
        http_response_code(404);

        echo json_encode([
            "success" => false,
            "message" => "El usuario no existe"
        ], JSON_UNESCAPED_UNICODE);

        $conn->close();
        exit();
    }

    // 4. Construir nombre completo.
    if ($usuario["rol"] === "Alumno") {

        $usuario["nombre_completo"] = trim(
            ($usuario["nombre_alumno"] ?? "") . " " .
            ($usuario["segundo_nombre_alumno"] ?? "") . " " .
            ($usuario["apellidos_alumno"] ?? "")
        );

    } elseif ($usuario["rol"] === "Docente") {

        $usuario["nombre_completo"] = trim(
            ($usuario["nombre_docente"] ?? "") . " " .
            ($usuario["segundo_nombre_docente"] ?? "") . " " .
            ($usuario["apellidos_docente"] ?? "")
        );

    } else {

        $usuario["nombre_completo"] = $usuario["nombre_usuario"];
    }

    // 5. Respuesta.
    echo json_encode([
        "success" => true,
        "usuario" => $usuario
    ], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error al consultar el usuario"
    ], JSON_UNESCAPED_UNICODE);
}

$conn->close();
?>
