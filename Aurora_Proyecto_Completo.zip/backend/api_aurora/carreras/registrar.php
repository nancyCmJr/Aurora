<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'carreras', 'registrar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if (
    !isset($data->nombre) ||
    !isset($data->tipo) ||
    !isset($data->total_creditos)
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Nombre, tipo y total de créditos son obligatorios"
    ]);
    exit();
}

$nombre = trim($data->nombre);
$tipo = trim($data->tipo);
$total_creditos = filter_var(
    $data->total_creditos,
    FILTER_VALIDATE_INT
);
$estado = isset($data->estado)
    ? trim($data->estado)
    : "Activa";

$tiposPermitidos = [
    "Ingenieria",
    "Licenciatura",
    "Maestria"
];

$estadosPermitidos = [
    "Activa",
    "Inactiva"
];

if ($nombre === '') {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El nombre de la carrera es obligatorio"
    ]);
    exit();
}

if (!in_array($tipo, $tiposPermitidos, true)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El tipo de carrera no es válido"
    ]);
    exit();
}

if ($total_creditos === false || $total_creditos <= 0) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El total de créditos debe ser mayor que cero"
    ]);
    exit();
}

if (!in_array($estado, $estadosPermitidos, true)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El estado de la carrera no es válido"
    ]);
    exit();
}

$sql = "INSERT INTO carreras
        (nombre, tipo, total_creditos, estado)
        VALUES (?, ?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param(
    "ssis",
    $nombre,
    $tipo,
    $total_creditos,
    $estado
);

if ($stmt->execute()) {
    http_response_code(201);

    echo json_encode([
        "success" => true,
        "message" => "Carrera registrada correctamente",
        "id_carrera" => $conn->insert_id
    ]);
} else {
    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "No fue posible registrar la carrera"
    ]);
}

$stmt->close();
$conn->close();

?>
