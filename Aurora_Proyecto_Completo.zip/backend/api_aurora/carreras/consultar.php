<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'carreras', 'consultar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$id_carrera = filter_input(
    INPUT_GET,
    'id_carrera',
    FILTER_VALIDATE_INT
);

if (!$id_carrera || $id_carrera <= 0) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El identificador de la carrera no es válido"
    ]);
    exit();
}

$sql = "SELECT
            id_carrera,
            nombre,
            tipo,
            total_creditos,
            estado
        FROM carreras
        WHERE id_carrera = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_carrera);
$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    http_response_code(404);

    echo json_encode([
        "success" => false,
        "message" => "No se encontró la carrera"
    ]);
} else {
    echo json_encode([
        "success" => true,
        "carrera" => $resultado->fetch_assoc()
    ]);
}

$stmt->close();
$conn->close();

?>
