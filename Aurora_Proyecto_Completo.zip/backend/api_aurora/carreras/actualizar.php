<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'carreras', 'actualizar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if (
    !isset($data->id_carrera) ||
    !isset($data->nombre) ||
    !isset($data->tipo) ||
    !isset($data->total_creditos) ||
    !isset($data->estado)
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Todos los campos son obligatorios"
    ]);
    exit();
}

$id_carrera = filter_var(
    $data->id_carrera,
    FILTER_VALIDATE_INT
);

$nombre = trim($data->nombre);
$tipo = trim($data->tipo);
$total_creditos = filter_var(
    $data->total_creditos,
    FILTER_VALIDATE_INT
);
$estado = trim($data->estado);

$tiposPermitidos = [
    "Ingenieria",
    "Licenciatura",
    "Maestria"
];

$estadosPermitidos = [
    "Activa",
    "Inactiva"
];

if (!$id_carrera || $id_carrera <= 0) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El identificador no es válido"
    ]);
    exit();
}

if ($nombre === '') {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El nombre es obligatorio"
    ]);
    exit();
}

if (!in_array($tipo, $tiposPermitidos, true)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El tipo de carrera no es válido"
    ]);
    exit();
}

if ($total_creditos === false || $total_creditos <= 0) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "Los créditos deben ser mayores que cero"
    ]);
    exit();
}

if (!in_array($estado, $estadosPermitidos, true)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El estado no es válido"
    ]);
    exit();
}

// Comprobar que la carrera exista.
$sqlExiste = "SELECT id_carrera
              FROM carreras
              WHERE id_carrera = ?
              LIMIT 1";

$stmtExiste = $conn->prepare($sqlExiste);
$stmtExiste->bind_param("i", $id_carrera);
$stmtExiste->execute();

$resultado = $stmtExiste->get_result();

if ($resultado->num_rows === 0) {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "La carrera que intentas actualizar no existe"
    ]);

    $stmtExiste->close();
    $conn->close();
    exit();
}

$stmtExiste->close();

// Actualizar carrera.
$sql = "UPDATE carreras
        SET nombre = ?,
            tipo = ?,
            total_creditos = ?,
            estado = ?
        WHERE id_carrera = ?";

$stmt = $conn->prepare($sql);

$stmt->bind_param(
    "ssisi",
    $nombre,
    $tipo,
    $total_creditos,
    $estado,
    $id_carrera
);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Carrera actualizada correctamente"
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "No fue posible actualizar la carrera"
    ]);
}

$stmt->close();
$conn->close();

?>
