<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'carreras', 'listar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$sql = "SELECT
            id_carrera,
            nombre,
            tipo,
            total_creditos,
            estado
        FROM carreras
        ORDER BY nombre ASC";

$resultado = $conn->query($sql);

if ($resultado) {
    $carreras = [];

    while ($fila = $resultado->fetch_assoc()) {
        $carreras[] = $fila;
    }

    echo json_encode([
        "success" => true,
        "total" => count($carreras),
        "carreras" => $carreras
    ]);
} else {
    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error al consultar las carreras"
    ]);
}

$conn->close();

?>
