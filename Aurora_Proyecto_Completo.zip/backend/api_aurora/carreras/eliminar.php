<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'carreras', 'eliminar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$data = json_decode(file_get_contents("php://input"));

if (!isset($data->id_carrera)) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El identificador de la carrera es obligatorio"
    ]);
    exit();
}

$id_carrera = filter_var(
    $data->id_carrera,
    FILTER_VALIDATE_INT
);

if (!$id_carrera || $id_carrera <= 0) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El identificador no es válido"
    ]);
    exit();
}

// Comprobar que exista la carrera.
$sqlExiste = "SELECT estado
              FROM carreras
              WHERE id_carrera = ?
              LIMIT 1";

$stmtExiste = $conn->prepare($sqlExiste);
$stmtExiste->bind_param("i", $id_carrera);
$stmtExiste->execute();

$resultado = $stmtExiste->get_result();

if ($resultado->num_rows === 0) {
    http_response_code(404);

    echo json_encode([
        "success" => false,
        "message" => "La carrera no existe"
    ]);

    $stmtExiste->close();
    $conn->close();
    exit();
}

$carrera = $resultado->fetch_assoc();
$stmtExiste->close();

if ($carrera['estado'] === 'Inactiva') {
    echo json_encode([
        "success" => true,
        "message" => "La carrera ya se encuentra inactiva"
    ]);

    $conn->close();
    exit();
}

// Baja lógica.
$sql = "UPDATE carreras
        SET estado = 'Inactiva'
        WHERE id_carrera = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_carrera);

if ($stmt->execute()) {
    echo json_encode([
        "success" => true,
        "message" => "Carrera desactivada correctamente"
    ]);
} else {
    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "No fue posible desactivar la carrera"
    ]);
}

$stmt->close();
$conn->close();

?>
