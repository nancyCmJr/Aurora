<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'kardex', 'actualizar');
require_once __DIR__ . '/../lib/reglas_academicas.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') auroraResponder(405,'Método no permitido');
$d=auroraJson();
$id=auroraId($d['id_kardex'] ?? null,'id_kardex');
try {
    $conn->begin_transaction();
    $old=auroraFila($conn,'SELECT * FROM kardex WHERE id_kardex = ? FOR UPDATE',[$id]);
    if (!$old) throw new DomainException('Registro de kardex inexistente',404);
    if ($usuarioSesion['rol'] === 'Docente') {
        $asignado = auroraFila($conn,'SELECT id_docente FROM grupos WHERE id_grupo=?',[(int)$old['id_grupo']]);
        if (!$asignado || (int)$asignado['id_docente'] !== (int)$usuarioSesion['id_docente']) {
            throw new DomainException('No puedes calificar grupos de otro docente',403);
        }
    }
    foreach (['numero_control','id_grupo','periodo','anio'] as $key) {
        if (array_key_exists($key,$d) && (string)$d[$key] !== (string)$old[$key])
            throw new DomainException('No se puede cambiar la identidad histórica del kardex',409);
    }
    if (in_array($old['estado'],['Aprobada','Reprobada','Baja'],true))
        throw new DomainException('Registro histórico definitivo: no se sobrescribe su nota o estado',409);
    $estado=auroraEnum($d['estado'] ?? $old['estado'],['Cursando','Aprobada','Reprobada','Baja'],'estado');
    if ($usuarioSesion['rol'] === 'Docente' && $estado === 'Baja') {
        throw new DomainException('La baja académica solo corresponde a administración',403);
    }
    $tipo=auroraEnum($d['tipo_calf'] ?? $old['tipo_calf'],['Ordinario','Recuperacion','No aprobatorio'],'tipo_calf');
    $curso=auroraEnum($d['curso'] ?? $old['curso'],['Ordinario','Repeticion','Especial'],'curso');
    if ($curso !== $old['curso']) throw new DomainException('No se modifica el tipo de curso después del alta',409);
    $nota=auroraValidarNota($estado, $d['calificacion'] ?? $old['calificacion']);
    auroraModificar($conn,'UPDATE kardex SET calificacion=?, tipo_calf=?, estado=? WHERE id_kardex=?', [$nota,$tipo,$estado,$id]);
    $conn->commit();
    auroraResponder(200,'Kardex actualizado sin alterar su identidad histórica',['data'=>['id_kardex'=>$id,'estado'=>$estado,'calificacion'=>$nota]]);
} catch (Throwable $e) {auroraFallo($e,$conn);}
