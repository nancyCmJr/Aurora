<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'kardex', 'por_grupo');
require_once __DIR__ . '/../lib/academico.php';
if ($_SERVER['REQUEST_METHOD'] !== 'GET') auroraResponder(405,'Método no permitido');
$id = auroraId($_GET['id_grupo'] ?? null,'id_grupo');
try {
    $g = auroraFila($conn, 'SELECT id_grupo, clave_grupo, periodo, anio, id_docente,
        id_materia, estado FROM grupos WHERE id_grupo=?', [$id]);
    if (!$g) throw new DomainException('Grupo inexistente',404);
    if ($usuarioSesion['rol'] === 'Docente' && (int)$g['id_docente'] !== (int)$usuarioSesion['id_docente']) {
        throw new DomainException('No tienes acceso a las calificaciones de este grupo',403);
    }
    $datos = auroraFilas($conn, "SELECT k.id_kardex,k.numero_control,a.nombre,a.seg_nombre,a.apellidos,
        k.periodo,k.anio,k.calificacion,k.tipo_calf,k.curso,k.estado
        FROM kardex k JOIN alumnos a ON a.numero_control=k.numero_control
        WHERE k.id_grupo=? ORDER BY a.apellidos,a.nombre,k.id_kardex", [$id]);
    auroraResponder(200,'Kardex del grupo',['grupo'=>$g,'total'=>count($datos),'data'=>$datos]);
} catch(Throwable $e) {auroraFallo($e,$conn);}
