<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'kardex', 'listar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = []) {
    http_response_code($codigo);

    echo json_encode(
        array_merge([
            "success" => $codigo >= 200 && $codigo < 300,
            "message" => $mensaje
        ], $datos),
        JSON_UNESCAPED_UNICODE
    );

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR QUE LOS FILTROS SEAN ESCALARES
// ==========================================

$campos = [
    "numero_control",
    "id_grupo",
    "periodo",
    "anio",
    "estado",
    "curso",
    "tipo_calf"
];

foreach ($campos as $campo) {

    if (
        isset($_GET[$campo]) &&
        !is_string($_GET[$campo]) &&
        !is_numeric($_GET[$campo])
    ) {
        responder(400, "El filtro '$campo' debe ser un valor individual");
    }
}

// ==========================================
// 3. RECIBIR FILTROS
// ==========================================

$numero_control = trim((string)($_GET["numero_control"] ?? ""));
$id_grupo = trim((string)($_GET["id_grupo"] ?? ""));
$periodo = trim((string)($_GET["periodo"] ?? ""));
$anio = trim((string)($_GET["anio"] ?? ""));
$estado = trim((string)($_GET["estado"] ?? ""));
$curso = trim((string)($_GET["curso"] ?? ""));
$tipo_calf = trim((string)($_GET["tipo_calf"] ?? ""));

// ==========================================
// 4. VALIDAR FILTROS
// ==========================================

// Número de control

if (mb_strlen($numero_control, "UTF-8") > 20) {
    responder(400, "El número de control excede la longitud permitida");
}

// ID del grupo

if ($id_grupo !== "") {

    if (!ctype_digit($id_grupo)) {
        responder(400, "ID de grupo no válido");
    }

    $id_grupo = filter_var(
        $id_grupo,
        FILTER_VALIDATE_INT,
        ["options" => ["min_range" => 1]]
    );

    if ($id_grupo === false) {
        responder(400, "ID de grupo no válido");
    }
} else {
    $id_grupo = null;
}

// Periodo

if (mb_strlen($periodo, "UTF-8") > 20) {
    responder(400, "El periodo excede la longitud permitida");
}

// Año

if ($anio !== "") {

    if (!ctype_digit($anio)) {
        responder(400, "Año no válido");
    }

    $anio = filter_var(
        $anio,
        FILTER_VALIDATE_INT,
        ["options" => [
            "min_range" => 1901,
            "max_range" => 2155
        ]]
    );

    if ($anio === false) {
        responder(400, "Año no válido");
    }
} else {
    $anio = null;
}

// Estado académico

$estadosValidos = [
    "Cursando",
    "Aprobada",
    "Reprobada",
    "Baja"
];

if (
    $estado !== "" &&
    !in_array($estado, $estadosValidos, true)
) {
    responder(400, "Estado académico no válido");
}

// Tipo de curso

$cursosValidos = [
    "Ordinario",
    "Repeticion",
    "Especial"
];

if (
    $curso !== "" &&
    !in_array($curso, $cursosValidos, true)
) {
    responder(400, "Tipo de curso no válido");
}

// Tipo de calificación

$tiposValidos = [
    "Ordinario",
    "Recuperacion",
    "No aprobatorio"
];

if (
    $tipo_calf !== "" &&
    !in_array($tipo_calf, $tiposValidos, true)
) {
    responder(400, "Tipo de calificación no válido");
}

// ==========================================
// 5. CONSTRUIR CONSULTA BASE
// ==========================================

$sql = "
    SELECT
        k.id_kardex,
        k.numero_control,

        a.nombre AS nombre_alumno,
        a.seg_nombre,
        a.apellidos,
        a.estado AS estado_alumno,

        k.id_grupo,
        g.clave_grupo,
        g.semestre,
        g.modalidad,
        g.estado AS estado_grupo,

        k.periodo,
        k.anio,
        k.calificacion,
        k.tipo_calf,
        k.curso,
        k.estado,

        m.id_materia,
        m.clave_materia,
        m.nombre AS nombre_materia,
        m.creditos,

        d.id_docente,
        d.codigo AS codigo_docente,
        d.nombre AS nombre_docente,
        d.seg_nombre AS segundo_nombre_docente,
        d.apellidos AS apellidos_docente

    FROM kardex k

    INNER JOIN alumnos a
        ON k.numero_control = a.numero_control

    INNER JOIN grupos g
        ON k.id_grupo = g.id_grupo

    INNER JOIN materias m
        ON g.id_materia = m.id_materia

    INNER JOIN docentes d
        ON g.id_docente = d.id_docente

    WHERE 1 = 1
";

// ==========================================
// 6. AGREGAR FILTROS DINÁMICOS
// ==========================================

$condiciones = [];
$parametros = [];
$tipos = "";

// Número de control

if ($numero_control !== "") {

    $condiciones[] = "k.numero_control = ?";
    $parametros[] = $numero_control;
    $tipos .= "s";
}

// Grupo

if ($id_grupo !== null) {

    $condiciones[] = "k.id_grupo = ?";
    $parametros[] = $id_grupo;
    $tipos .= "i";
}

// Periodo

if ($periodo !== "") {

    $condiciones[] = "k.periodo = ?";
    $parametros[] = $periodo;
    $tipos .= "s";
}

// Año

if ($anio !== null) {

    $condiciones[] = "k.anio = ?";
    $parametros[] = $anio;
    $tipos .= "i";
}

// Estado

if ($estado !== "") {

    $condiciones[] = "k.estado = ?";
    $parametros[] = $estado;
    $tipos .= "s";
}

// Curso

if ($curso !== "") {

    $condiciones[] = "k.curso = ?";
    $parametros[] = $curso;
    $tipos .= "s";
}

// Tipo de calificación

if ($tipo_calf !== "") {

    $condiciones[] = "k.tipo_calf = ?";
    $parametros[] = $tipo_calf;
    $tipos .= "s";
}

// Incorporar condiciones

if (!empty($condiciones)) {
    $sql .= " AND " . implode(" AND ", $condiciones);
}

// ==========================================
// 7. ORDENAR RESULTADOS
// ==========================================

$sql .= "
    ORDER BY
        k.anio DESC,
        k.periodo DESC,
        a.apellidos ASC,
        a.nombre ASC,
        m.nombre ASC
";

// ==========================================
// 8. EJECUTAR CONSULTA
// ==========================================

$stmt = null;

try {

    $stmt = $conn->prepare($sql);

    // Vincular parámetros únicamente cuando existan filtros.

    if (!empty($parametros)) {

        $referencias = [];

        foreach ($parametros as $indice => &$valor) {
            $referencias[$indice] = &$valor;
        }

        unset($valor);

        $stmt->bind_param($tipos, ...$referencias);
    }

    $stmt->execute();

    $resultado = $stmt->get_result();

    $registros = [];

    // ======================================
    // 9. PROCESAR RESULTADOS
    // ======================================

    while ($fila = $resultado->fetch_assoc()) {

        $fila["id_kardex"] = (int)$fila["id_kardex"];
        $fila["id_grupo"] = (int)$fila["id_grupo"];
        $fila["semestre"] = (int)$fila["semestre"];
        $fila["anio"] = (int)$fila["anio"];

        $fila["id_materia"] = (int)$fila["id_materia"];
        $fila["creditos"] = (int)$fila["creditos"];

        $fila["id_docente"] = (int)$fila["id_docente"];

        if ($fila["calificacion"] !== null) {
            $fila["calificacion"] = (int)$fila["calificacion"];
        }

        $registros[] = $fila;
    }

    // Liberar recursos antes de responder.

    $resultado->free();

    $stmt->close();
    $stmt = null;

    $total = count($registros);

    $conn->close();

    // ======================================
    // 10. RESPUESTA JSON
    // ======================================

    responder(200, "Kardex consultado correctamente", [

        "total" => $total,

        "filtros_aplicados" => [
            "numero_control" => $numero_control !== ""
                ? $numero_control
                : null,

            "id_grupo" => $id_grupo,

            "periodo" => $periodo !== ""
                ? $periodo
                : null,

            "anio" => $anio,

            "estado" => $estado !== ""
                ? $estado
                : null,

            "curso" => $curso !== ""
                ? $curso
                : null,

            "tipo_calf" => $tipo_calf !== ""
                ? $tipo_calf
                : null
        ],

        "kardex" => $registros
    ]);

} catch (mysqli_sql_exception $e) {

    if ($stmt !== null) {
        $stmt->close();
        $stmt = null;
    }

    error_log(
        "Error SQL en kardex/listar.php: " . $e->getMessage()
    );

    $conn->close();

    responder(
        500,
        "Error de base de datos al consultar el kardex"
    );

} catch (Throwable $e) {

    if ($stmt !== null) {
        $stmt->close();
        $stmt = null;
    }

    error_log(
        "Error interno en kardex/listar.php: " . $e->getMessage()
    );

    $conn->close();

    responder(
        500,
        "Error interno al consultar el kardex"
    );
}

?>
