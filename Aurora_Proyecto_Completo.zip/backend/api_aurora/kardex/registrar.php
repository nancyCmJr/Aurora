<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'kardex', 'registrar');
require_once __DIR__ . '/../lib/reglas_academicas.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') auroraResponder(405,'Método no permitido');
$d = auroraJson();
$numero = trim((string)($d['numero_control'] ?? ''));
if ($numero === '' || mb_strlen($numero) > 20) auroraResponder(400,'Número de control inválido');
$idGrupo = auroraId($d['id_grupo'] ?? null, 'id_grupo');
$tipo = auroraEnum($d['tipo_calf'] ?? 'Ordinario',['Ordinario','Recuperacion','No aprobatorio'],'tipo_calf');
$curso = auroraEnum($d['curso'] ?? 'Ordinario',['Ordinario','Repeticion','Especial'],'curso');
$estado = auroraEnum($d['estado'] ?? 'Cursando',['Cursando'],'estado');
$nota = auroraValidarNota($estado, $d['calificacion'] ?? null);
try {
    $conn->begin_transaction();
    $g = auroraGrupo($conn, $idGrupo, true);
    if (isset($d['periodo']) && $d['periodo'] !== $g['periodo'])
        throw new DomainException('El periodo debe coincidir con el grupo',409);
    if (isset($d['anio']) && (int)$d['anio'] !== (int)$g['anio'])
        throw new DomainException('El año debe coincidir con el grupo',409);
    auroraElegibilidad($conn, $numero, $g);
    $rows = auroraModificar($conn,'INSERT INTO kardex
        (numero_control,id_grupo,periodo,anio,calificacion,tipo_calf,curso,estado)
        VALUES (?,?,?,?,?,?,?,?)',[$numero,$idGrupo,$g['periodo'],(int)$g['anio'],$nota,$tipo,$curso,$estado]);
    $id = $conn->insert_id;
    $conn->commit();
    auroraResponder(201,'Alumno registrado en el kardex',['data'=>['id_kardex'=>$id,'numero_control'=>$numero,'id_grupo'=>$idGrupo,'periodo'=>$g['periodo'],'anio'=>(int)$g['anio']]]);
} catch (Throwable $e) { auroraFallo($e,$conn); }
