<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'kardex', 'eliminar');
require_once __DIR__ . '/../lib/academico.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') auroraResponder(405,'Método no permitido');
$d=auroraJson(); $id=auroraId($d['id_kardex'] ?? null,'id_kardex');
try {
    $conn->begin_transaction();
    $k=auroraFila($conn,'SELECT id_kardex, estado, calificacion FROM kardex WHERE id_kardex=? FOR UPDATE',[$id]);
    if (!$k) throw new DomainException('Kardex inexistente',404);
    if ($k['estado'] === 'Baja') throw new DomainException('El registro ya está dado de baja',409);
    if ($k['estado'] !== 'Cursando' || $k['calificacion'] !== null)
        throw new DomainException('No se permite dar de baja una calificación final: se conserva el historial',409);
    auroraModificar($conn,"UPDATE kardex SET estado='Baja' WHERE id_kardex=?",[$id]);
    $conn->commit();
    auroraResponder(200,'Baja lógica registrada; el registro se conserva',['data'=>['id_kardex'=>$id,'estado'=>'Baja']]);
} catch (Throwable $e) {auroraFallo($e,$conn);}
