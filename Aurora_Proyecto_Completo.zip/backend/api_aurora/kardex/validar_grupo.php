<?php
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'kardex', 'validar_grupo');
require_once __DIR__ . '/../lib/reglas_academicas.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') auroraResponder(405,'Método no permitido');
$id=auroraId($_GET['id_grupo'] ?? null,'id_grupo');
$numero=trim((string)($_GET['numero_control'] ?? ''));
if ($numero === '' || strlen($numero)>20) auroraResponder(400,'Número de control inválido');
try {
    $g=auroraGrupo($conn,$id);
    $info=['id_grupo'=>$id,'numero_control'=>$numero,'periodo'=>$g['periodo'],'anio'=>(int)$g['anio']];
    try {auroraElegibilidad($conn,$numero,$g);auroraResponder(200,'Alumno elegible',['valido'=>true,'data'=>$info]);}
    catch (DomainException $ex) {auroraResponder(200,'Alumno no elegible',['valido'=>false,'motivo'=>$ex->getMessage(),'data'=>$info]);}
} catch (Throwable $e) {auroraFallo($e,$conn);}
