<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'kardex', 'consultar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

function responder($codigo, $mensaje, $datos = []) {

    http_response_code($codigo);

    echo json_encode(
        array_merge([
            "success" => $codigo >= 200 && $codigo < 300,
            "message" => $mensaje
        ], $datos),
        JSON_UNESCAPED_UNICODE
    );

    exit();
}

// ==========================================
// 1. VALIDAR MÉTODO
// ==========================================

if ($_SERVER["REQUEST_METHOD"] !== "GET") {
    responder(405, "Método no permitido");
}

// ==========================================
// 2. VALIDAR PARÁMETROS ESCALARES
// ==========================================

if (
    isset($_GET["id_kardex"]) &&
    !is_string($_GET["id_kardex"]) &&
    !is_numeric($_GET["id_kardex"])
) {
    responder(400, "El ID de kardex debe ser un valor individual");
}

if (
    isset($_GET["numero_control"]) &&
    !is_string($_GET["numero_control"])
) {
    responder(400, "El número de control debe ser un valor individual");
}

// ==========================================
// 3. RECIBIR PARÁMETROS
// ==========================================

$id_kardex = isset($_GET["id_kardex"])
    ? trim((string)$_GET["id_kardex"])
    : null;

$numero_control = trim(
    (string)($_GET["numero_control"] ?? "")
);

// ==========================================
// 4. VALIDAR PARÁMETROS
// ==========================================

// No permitir ambos parámetros.

if (
    $id_kardex !== null &&
    $numero_control !== ""
) {
    responder(
        400,
        "Consulta por ID de kardex o por número de control, no ambos"
    );
}

// Debe enviarse al menos uno.

if (
    $id_kardex === null &&
    $numero_control === ""
) {
    responder(
        400,
        "Debes proporcionar un ID de kardex o un número de control"
    );
}

// Validar ID de kardex.

if ($id_kardex !== null) {

    if (!ctype_digit($id_kardex)) {
        responder(400, "ID de kardex no válido");
    }

    $id_kardex = filter_var(
        $id_kardex,
        FILTER_VALIDATE_INT,
        ["options" => ["min_range" => 1]]
    );

    if ($id_kardex === false) {
        responder(400, "ID de kardex no válido");
    }
}

// Validar número de control.

if ($numero_control !== "") {

    if (
        mb_strlen($numero_control, "UTF-8") > 20
    ) {
        responder(400, "Número de control no válido");
    }
}

// ==========================================
// 5. CONSTRUIR CONSULTA BASE
// ==========================================

$sql = "
    SELECT
        k.id_kardex,
        k.numero_control,

        a.nombre AS nombre_alumno,
        a.seg_nombre,
        a.apellidos,
        a.estado AS estado_alumno,

        k.id_grupo,
        g.clave_grupo,
        g.semestre,
        g.modalidad,
        g.estado AS estado_grupo,

        k.periodo,
        k.anio,
        k.calificacion,
        k.tipo_calf,
        k.curso,
        k.estado,

        m.id_materia,
        m.clave_materia,
        m.nombre AS nombre_materia,
        m.creditos,

        d.id_docente,
        d.codigo AS codigo_docente,
        d.nombre AS nombre_docente,
        d.seg_nombre AS segundo_nombre_docente,
        d.apellidos AS apellidos_docente

    FROM kardex k

    INNER JOIN alumnos a
        ON k.numero_control = a.numero_control

    INNER JOIN grupos g
        ON k.id_grupo = g.id_grupo

    INNER JOIN materias m
        ON g.id_materia = m.id_materia

    INNER JOIN docentes d
        ON g.id_docente = d.id_docente
";

// ==========================================
// 6. AGREGAR CONDICIÓN
// ==========================================

if ($id_kardex !== null) {

    $sql .= "
        WHERE k.id_kardex = ?
        ORDER BY
            k.anio DESC,
            k.periodo DESC
    ";

} else {

    $sql .= "
        WHERE k.numero_control = ?
        ORDER BY
            k.anio DESC,
            k.periodo DESC,
            g.clave_grupo ASC
    ";
}

// ==========================================
// 7. EJECUTAR CONSULTA
// ==========================================

$stmt = null;

try {

    $stmt = $conn->prepare($sql);

    // Vincular parámetro correspondiente.

    if ($id_kardex !== null) {

        $stmt->bind_param("i", $id_kardex);

    } else {

        $stmt->bind_param("s", $numero_control);
    }

    $stmt->execute();

    $resultado = $stmt->get_result();

    $registros = [];

    // ======================================
    // 8. PROCESAR RESULTADOS
    // ======================================

    while ($fila = $resultado->fetch_assoc()) {

        $fila["id_kardex"] = (int)$fila["id_kardex"];
        $fila["id_grupo"] = (int)$fila["id_grupo"];
        $fila["semestre"] = (int)$fila["semestre"];
        $fila["anio"] = (int)$fila["anio"];

        $fila["id_materia"] = (int)$fila["id_materia"];
        $fila["creditos"] = (int)$fila["creditos"];

        $fila["id_docente"] = (int)$fila["id_docente"];

        if ($fila["calificacion"] !== null) {
            $fila["calificacion"] = (int)$fila["calificacion"];
        }

        $registros[] = $fila;
    }

    $resultado->free();

    $stmt->close();
    $stmt = null;

    // ======================================
    // 9. VERIFICAR RESULTADOS
    // ======================================

    if (empty($registros)) {

        $conn->close();

        if ($id_kardex !== null) {

            responder(404, "Registro de kardex no encontrado", [
                "total" => 0,
                "kardex" => []
            ]);

        } else {

            responder(404, "El alumno no tiene registros en el kardex", [
                "total" => 0,
                "numero_control" => $numero_control,
                "kardex" => []
            ]);
        }
    }

    // ======================================
    // 10. PREPARAR RESPUESTA
    // ======================================

    $total = count($registros);

    $tipoConsulta = $id_kardex !== null
        ? "Registro individual"
        : "Historial académico del alumno";

    $conn->close();

    responder(
        200,
        "Consulta de kardex realizada correctamente",
        [
            "total" => $total,

            "tipo_consulta" => $tipoConsulta,

            "kardex" => $registros
        ]
    );

} catch (mysqli_sql_exception $e) {

    if ($stmt !== null) {
        $stmt->close();
        $stmt = null;
    }

    error_log(
        "Error SQL en kardex/consultar.php: " . $e->getMessage()
    );

    $conn->close();

    responder(
        500,
        "Error de base de datos al consultar el kardex"
    );

} catch (Throwable $e) {

    if ($stmt !== null) {
        $stmt->close();
        $stmt = null;
    }

    error_log(
        "Error interno en kardex/consultar.php: " . $e->getMessage()
    );

    $conn->close();

    responder(
        500,
        "Error interno al consultar el kardex"
    );
}

?>
