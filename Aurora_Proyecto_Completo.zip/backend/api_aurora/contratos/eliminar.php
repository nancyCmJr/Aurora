<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'contratos', 'eliminar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

/* -----------------------------------------
   FUNCIONES
----------------------------------------- */

function responder($status, $mensaje, $datos = []) {

    http_response_code($status);

    echo json_encode(array_merge([
        "success" => $status >= 200 && $status < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

function validarId($valor) {

    if (is_int($valor)) {
        return $valor > 0 ? $valor : false;
    }

    if (
        is_string($valor) &&
        ctype_digit($valor) &&
        filter_var($valor, FILTER_VALIDATE_INT) !== false &&
        (int)$valor > 0
    ) {
        return (int)$valor;
    }

    return false;
}

/* -----------------------------------------
   1. VALIDAR JSON
----------------------------------------- */

$data = json_decode(file_get_contents("php://input"));

if (!is_object($data)) {
    responder(400, "El formato JSON no es válido");
}

/* -----------------------------------------
   2. VALIDAR IDENTIFICADOR
----------------------------------------- */

$id_contrato = validarId($data->id_contrato ?? null);

if (!$id_contrato) {
    responder(400, "El identificador del contrato no es válido");
}

$stmt = null;

try {

    /* -----------------------------------------
       3. INICIAR TRANSACCIÓN
    ----------------------------------------- */

    $conn->begin_transaction();

    /*
     * Consultar el docente relacionado.
     * La consulta inicial no bloquea.
     */

    $stmt = $conn->prepare("
        SELECT id_docente
        FROM contratos
        WHERE id_contrato = ?
    ");

    $stmt->bind_param("i", $id_contrato);
    $stmt->execute();

    $contratoInicial = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$contratoInicial) {
        throw new DomainException("El contrato no existe", 404);
    }

    $id_docente = (int)$contratoInicial["id_docente"];

    /* -----------------------------------------
       4. BLOQUEAR DOCENTE
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_docente
        FROM docentes
        WHERE id_docente = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_docente);
    $stmt->execute();

    $docente = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$docente) {
        throw new DomainException(
            "El docente relacionado con el contrato no existe",
            409
        );
    }

    /* -----------------------------------------
       5. BLOQUEAR CONTRATO
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_contrato, id_docente, status
        FROM contratos
        WHERE id_contrato = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_contrato);
    $stmt->execute();

    $contrato = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$contrato) {
        throw new DomainException("El contrato ya no existe", 404);
    }

    /*
     * Comprobar que el docente relacionado
     * no haya cambiado durante la operación.
     */

    if ((int)$contrato["id_docente"] !== $id_docente) {
        throw new DomainException(
            "El contrato fue modificado por otra operación. Consulta nuevamente sus datos.",
            409
        );
    }

    /* -----------------------------------------
       6. VALIDAR ESTADO ACTUAL
    ----------------------------------------- */

    if ($contrato["status"] === "Inactivo") {
        throw new DomainException(
            "El contrato ya se encuentra inactivo",
            409
        );
    }

    if ($contrato["status"] === "Vencido") {
        throw new DomainException(
            "No se puede desactivar el contrato porque ya se encuentra vencido",
            409
        );
    }

    /* -----------------------------------------
       7. DESACTIVAR CONTRATO
    ----------------------------------------- */

    $stmt = $conn->prepare("
        UPDATE contratos
        SET status = 'Inactivo'
        WHERE id_contrato = ?
          AND status = 'Activo'
    ");

    $stmt->bind_param("i", $id_contrato);
    $stmt->execute();

    if ($stmt->affected_rows !== 1) {
        throw new DomainException(
            "No fue posible desactivar el contrato. Consulta nuevamente su estado.",
            409
        );
    }

    $stmt->close();
    $stmt = null;

    /* -----------------------------------------
       8. CONFIRMAR TRANSACCIÓN
    ----------------------------------------- */

    $conn->commit();

    responder(200, "Contrato desactivado correctamente", [
        "data" => [
            "id_contrato" => $id_contrato,
            "id_docente" => $id_docente,
            "status" => "Inactivo"
        ]
    ]);

} catch (DomainException $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    $codigoHTTP = $e->getCode();

    if ($codigoHTTP < 400 || $codigoHTTP > 599) {
        $codigoHTTP = 400;
    }

    responder($codigoHTTP, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error SQL contratos/eliminar.php: " . $e->getMessage()
    );

    if (
        (int)$e->getCode() === 1213 ||
        (int)$e->getCode() === 1205
    ) {
        responder(
            409,
            "La operación tuvo un conflicto con otra actualización. Intenta nuevamente."
        );
    }

    responder(500, "Error de base de datos al desactivar el contrato.");

} catch (Throwable $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error contratos/eliminar.php: " . $e->getMessage()
    );

    responder(500, "Error interno al desactivar el contrato.");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
