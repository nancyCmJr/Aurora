<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'contratos', 'consultar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

if (
    !isset($_GET['id_contrato']) ||
    !is_numeric($_GET['id_contrato']) ||
    (int)$_GET['id_contrato'] <= 0
) {
    http_response_code(400);
    echo json_encode([
        "success" => false,
        "message" => "El identificador del contrato es obligatorio"
    ]);
    exit();
}

$id_contrato = (int)$_GET['id_contrato'];

$sql = "SELECT
            c.id_contrato,
            c.id_docente,
            d.codigo,
            d.nombre,
            d.seg_nombre,
            d.apellidos,
            c.id_area,
            a.nombre AS nombre_area,
            c.folio_contrato,
            c.horas,
            c.rol,
            c.status,
            c.fecha_inicio,
            c.fecha_fin
        FROM contratos c
        INNER JOIN docentes d
            ON c.id_docente = d.id_docente
        INNER JOIN areas a
            ON c.id_area = a.id_area
        WHERE c.id_contrato = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id_contrato);
$stmt->execute();

$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    http_response_code(404);
    echo json_encode([
        "success" => false,
        "message" => "El contrato no existe"
    ]);
} else {
    echo json_encode([
        "success" => true,
        "contrato" => $resultado->fetch_assoc()
    ]);
}

$stmt->close();
$conn->close();

?>
