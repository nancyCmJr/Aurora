<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'contratos', 'actualizar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

/* -----------------------------------------
   FUNCIONES
----------------------------------------- */

function responder($status, $mensaje, $datos = []) {
    http_response_code($status);

    echo json_encode(array_merge([
        "success" => $status >= 200 && $status < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

function validarId($valor) {

    if (is_int($valor)) {
        return $valor > 0 ? $valor : false;
    }

    if (
        is_string($valor) &&
        ctype_digit($valor) &&
        filter_var($valor, FILTER_VALIDATE_INT) !== false &&
        (int)$valor > 0
    ) {
        return (int)$valor;
    }

    return false;
}

function fechaValida($fecha) {

    if (!is_string($fecha)) {
        return false;
    }

    $formato = DateTime::createFromFormat("!Y-m-d", $fecha);

    return $formato !== false &&
           $formato->format("Y-m-d") === $fecha;
}

/* -----------------------------------------
   1. VALIDAR JSON
----------------------------------------- */

$data = json_decode(file_get_contents("php://input"));

if (!is_object($data)) {
    responder(400, "El formato JSON no es válido");
}

/* -----------------------------------------
   2. VALIDAR IDENTIFICADORES
----------------------------------------- */

$id_contrato = validarId($data->id_contrato ?? null);
$id_docente = validarId($data->id_docente ?? null);
$id_area = validarId($data->id_area ?? null);

if (!$id_contrato || !$id_docente || !$id_area) {
    responder(
        400,
        "Los identificadores del contrato, docente o área no son válidos"
    );
}

/* -----------------------------------------
   3. VALIDAR FOLIO
----------------------------------------- */

if (
    !isset($data->folio_contrato) ||
    !is_string($data->folio_contrato)
) {
    responder(400, "El folio del contrato es obligatorio");
}

$folio = trim($data->folio_contrato);

if ($folio === "" || mb_strlen($folio, "UTF-8") > 30) {
    responder(400, "El folio debe contener entre 1 y 30 caracteres");
}

/* -----------------------------------------
   4. VALIDAR HORAS
----------------------------------------- */

$horas = $data->horas ?? null;

if (
    !(is_int($horas) && $horas > 0) &&
    !(is_string($horas) &&
      ctype_digit($horas) &&
      filter_var($horas, FILTER_VALIDATE_INT) !== false &&
      (int)$horas > 0)
) {
    responder(400, "Las horas deben ser un número entero positivo");
}

$horas = (int)$horas;

/* -----------------------------------------
   5. VALIDAR ROL Y ESTADO
----------------------------------------- */

$rolesPermitidos = [
    "Docente",
    "Profesor honorario",
    "Jefe base"
];

$estadosPermitidos = [
    "Activo",
    "Inactivo",
    "Vencido"
];

$rol = $data->rol ?? null;
$status = $data->status ?? null;

if (
    !is_string($rol) ||
    !in_array($rol, $rolesPermitidos, true)
) {
    responder(400, "El rol del contrato no es válido");
}

if (
    !is_string($status) ||
    !in_array($status, $estadosPermitidos, true)
) {
    responder(400, "El estado del contrato no es válido");
}

/* -----------------------------------------
   6. VALIDAR FECHAS
----------------------------------------- */

$fecha_inicio = $data->fecha_inicio ?? null;

$fecha_fin = isset($data->fecha_fin) && $data->fecha_fin !== ""
    ? $data->fecha_fin
    : null;

if (
    !fechaValida($fecha_inicio) ||
    ($fecha_fin !== null && !fechaValida($fecha_fin))
) {
    responder(400, "Una de las fechas no tiene un formato válido");
}

if (
    $fecha_fin !== null &&
    $fecha_fin < $fecha_inicio
) {
    responder(
        400,
        "La fecha de fin no puede ser anterior a la fecha de inicio"
    );
}

$stmt = null;

try {

    /* -----------------------------------------
       7. INICIAR TRANSACCIÓN
    ----------------------------------------- */

    $conn->begin_transaction();

    /*
     * 7.1 Consultar relación inicial del contrato.
     * Esta consulta no bloquea; se vuelve a comprobar
     * después de bloquear los registros involucrados.
     */

    $stmt = $conn->prepare("
        SELECT id_docente
        FROM contratos
        WHERE id_contrato = ?
    ");

    $stmt->bind_param("i", $id_contrato);
    $stmt->execute();

    $contratoInicial = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$contratoInicial) {
        throw new DomainException("El contrato no existe", 404);
    }

    $docenteAnterior = (int)$contratoInicial["id_docente"];

    /* -----------------------------------------
       8. BLOQUEAR DOCENTES
    ----------------------------------------- */

    $idsDocentes = array_unique([
        $docenteAnterior,
        $id_docente
    ]);

    sort($idsDocentes, SORT_NUMERIC);

    $docentesBloqueados = [];

    foreach ($idsDocentes as $idBloqueo) {

        $stmt = $conn->prepare("
            SELECT id_docente, estado
            FROM docentes
            WHERE id_docente = ?
            FOR UPDATE
        ");

        $stmt->bind_param("i", $idBloqueo);
        $stmt->execute();

        $docenteBloqueado = $stmt->get_result()->fetch_assoc();

        $stmt->close();
        $stmt = null;

        if (!$docenteBloqueado) {
            throw new DomainException(
                "No se encontró uno de los docentes relacionados",
                404
            );
        }

        $docentesBloqueados[$idBloqueo] = $docenteBloqueado;
    }

    /* -----------------------------------------
       9. CONSULTAR EDIFICIO DEL ÁREA
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_edificio
        FROM areas
        WHERE id_area = ?
    ");

    $stmt->bind_param("i", $id_area);
    $stmt->execute();

    $areaInicial = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$areaInicial) {
        throw new DomainException(
            "El área seleccionada no existe",
            404
        );
    }

    $id_edificio = (int)$areaInicial["id_edificio"];

    /* -----------------------------------------
       10. BLOQUEAR EDIFICIO
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_edificio, estado
        FROM edificios
        WHERE id_edificio = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_edificio);
    $stmt->execute();

    $edificio = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$edificio) {
        throw new DomainException(
            "El edificio asociado al área no existe",
            409
        );
    }

    /* -----------------------------------------
       11. BLOQUEAR ÁREA
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_area, id_edificio, estado
        FROM areas
        WHERE id_area = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_area);
    $stmt->execute();

    $area = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$area) {
        throw new DomainException(
            "El área seleccionada ya no existe",
            404
        );
    }

    if ((int)$area["id_edificio"] !== $id_edificio) {
        throw new DomainException(
            "La ubicación del área cambió durante la operación. Consulta nuevamente sus datos.",
            409
        );
    }

    /* -----------------------------------------
       12. BLOQUEAR CONTRATO
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_contrato, id_docente
        FROM contratos
        WHERE id_contrato = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_contrato);
    $stmt->execute();

    $contrato = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$contrato) {
        throw new DomainException("El contrato ya no existe", 404);
    }

    if ((int)$contrato["id_docente"] !== $docenteAnterior) {
        throw new DomainException(
            "El contrato fue modificado por otra operación. Consulta nuevamente sus datos.",
            409
        );
    }

    /* -----------------------------------------
       13. VALIDAR ESTADO DE RELACIONES
    ----------------------------------------- */

    $docente = $docentesBloqueados[$id_docente];

    if ($status === "Activo") {

        if ($docente["estado"] !== "Activo") {
            throw new DomainException(
                "No se puede activar el contrato porque el docente está inactivo o dado de baja.",
                409
            );
        }

        if ($area["estado"] !== "Activo") {
            throw new DomainException(
                "No se puede activar el contrato porque el área está inactiva.",
                409
            );
        }

        if ($edificio["estado"] !== "Activo") {
            throw new DomainException(
                "No se puede activar el contrato porque el edificio está inactivo.",
                409
            );
        }
    }

    /* -----------------------------------------
       14. VERIFICAR FOLIO DUPLICADO
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_contrato
        FROM contratos
        WHERE folio_contrato = ?
          AND id_contrato <> ?
        LIMIT 1
    ");

    $stmt->bind_param("si", $folio, $id_contrato);
    $stmt->execute();

    $duplicado = $stmt->get_result()->num_rows > 0;

    $stmt->close();
    $stmt = null;

    if ($duplicado) {
        throw new DomainException(
            "El folio del contrato ya está registrado",
            409
        );
    }

    /* -----------------------------------------
       15. ACTUALIZAR CONTRATO
    ----------------------------------------- */

    $stmt = $conn->prepare("
        UPDATE contratos
        SET id_docente = ?,
            id_area = ?,
            folio_contrato = ?,
            horas = ?,
            rol = ?,
            status = ?,
            fecha_inicio = ?,
            fecha_fin = ?
        WHERE id_contrato = ?
    ");

    $stmt->bind_param(
        "iisissssi",
        $id_docente,
        $id_area,
        $folio,
        $horas,
        $rol,
        $status,
        $fecha_inicio,
        $fecha_fin,
        $id_contrato
    );

    $stmt->execute();

    $stmt->close();
    $stmt = null;

    /* -----------------------------------------
       16. CONFIRMAR TRANSACCIÓN
    ----------------------------------------- */

    $conn->commit();

    responder(200, "Contrato actualizado correctamente", [
        "data" => [
            "id_contrato" => $id_contrato,
            "id_docente" => $id_docente,
            "id_area" => $id_area,
            "folio_contrato" => $folio,
            "horas" => $horas,
            "rol" => $rol,
            "status" => $status,
            "fecha_inicio" => $fecha_inicio,
            "fecha_fin" => $fecha_fin
        ]
    ]);

} catch (DomainException $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    $codigoHTTP = $e->getCode();

    if ($codigoHTTP < 400 || $codigoHTTP > 599) {
        $codigoHTTP = 400;
    }

    responder($codigoHTTP, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error SQL contratos/actualizar.php: " . $e->getMessage()
    );

    if ((int)$e->getCode() === 1062) {
        responder(409, "El folio del contrato ya está registrado.");
    }

    if (
        (int)$e->getCode() === 1213 ||
        (int)$e->getCode() === 1205
    ) {
        responder(
            409,
            "La operación tuvo un conflicto con otra actualización. Intenta nuevamente."
        );
    }

    if ((int)$e->getCode() === 1452) {
        responder(
            409,
            "No se puede actualizar el contrato porque uno de los registros relacionados ya no existe."
        );
    }

    responder(500, "Error de base de datos al actualizar el contrato.");

} catch (Throwable $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error contratos/actualizar.php: " . $e->getMessage()
    );

    responder(500, "Error interno al actualizar el contrato.");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
