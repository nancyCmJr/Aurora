<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'contratos', 'listar');

header("Access-Control-Allow-Methods: GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once __DIR__ . "/../conn.php";

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

$sql = "SELECT
            c.id_contrato,
            c.id_docente,
            d.codigo,
            d.nombre,
            d.seg_nombre,
            d.apellidos,
            c.id_area,
            a.nombre AS nombre_area,
            c.folio_contrato,
            c.horas,
            c.rol,
            c.status,
            c.fecha_inicio,
            c.fecha_fin
        FROM contratos c
        INNER JOIN docentes d
            ON c.id_docente = d.id_docente
        INNER JOIN areas a
            ON c.id_area = a.id_area
        ORDER BY c.fecha_inicio DESC, c.id_contrato DESC";

$resultado = $conn->query($sql);

if ($resultado) {

    $contratos = [];

    while ($fila = $resultado->fetch_assoc()) {
        $contratos[] = $fila;
    }

    echo json_encode([
        "success" => true,
        "total" => count($contratos),
        "contratos" => $contratos
    ]);

} else {

    http_response_code(500);

    echo json_encode([
        "success" => false,
        "message" => "Error al consultar los contratos"
    ]);
}

$conn->close();

?>
