<?php
// Aurora: CORS con cookies de sesión, autenticación y autorización por rol.
require_once __DIR__ . '/../auth/autorizar.php';
auroraIniciarSesion();
require_once __DIR__ . '/../conn.php';
$usuarioSesion = auroraAutorizarEndpoint($conn, 'contratos', 'registar');

header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    http_response_code(405);
    echo json_encode([
        "success" => false,
        "message" => "Método no permitido"
    ]);
    exit();
}

require_once __DIR__ . "/../conn.php";

/* -----------------------------------------
   FUNCIONES
----------------------------------------- */

function responder($status, $mensaje, $datos = []) {
    http_response_code($status);

    echo json_encode(array_merge([
        "success" => $status >= 200 && $status < 300,
        "message" => $mensaje
    ], $datos), JSON_UNESCAPED_UNICODE);

    exit();
}

function validarId($valor) {

    if (is_int($valor)) {
        return $valor > 0 ? $valor : false;
    }

    if (
        is_string($valor) &&
        ctype_digit($valor) &&
        filter_var($valor, FILTER_VALIDATE_INT) !== false &&
        (int)$valor > 0
    ) {
        return (int)$valor;
    }

    return false;
}

function fechaValida($fecha) {

    if (!is_string($fecha)) {
        return false;
    }

    $formato = DateTime::createFromFormat("!Y-m-d", $fecha);

    return $formato &&
           $formato->format("Y-m-d") === $fecha;
}

/* -----------------------------------------
   1. VALIDAR JSON
----------------------------------------- */

$data = json_decode(file_get_contents("php://input"));

if (!is_object($data)) {
    responder(400, "El formato JSON no es válido");
}

/* -----------------------------------------
   2. VALIDAR IDENTIFICADORES
----------------------------------------- */

$id_docente = validarId($data->id_docente ?? null);
$id_area = validarId($data->id_area ?? null);

if (!$id_docente || !$id_area) {
    responder(
        400,
        "Debes proporcionar un ID de docente y un ID de área válidos"
    );
}

/* -----------------------------------------
   3. VALIDAR FOLIO
----------------------------------------- */

if (
    !isset($data->folio_contrato) ||
    !is_string($data->folio_contrato)
) {
    responder(400, "El folio del contrato es obligatorio");
}

$folio = trim($data->folio_contrato);

if ($folio === "" || mb_strlen($folio, "UTF-8") > 30) {
    responder(
        400,
        "El folio es obligatorio y no debe superar los 30 caracteres"
    );
}

/* -----------------------------------------
   4. VALIDAR HORAS
----------------------------------------- */

$horas = $data->horas ?? null;

if (
    !(is_int($horas) && $horas > 0) &&
    !(is_string($horas) &&
      ctype_digit($horas) &&
      filter_var($horas, FILTER_VALIDATE_INT) !== false &&
      (int)$horas > 0)
) {
    responder(
        400,
        "Las horas deben ser un número entero positivo"
    );
}

$horas = (int)$horas;

/* -----------------------------------------
   5. VALIDAR ROL
----------------------------------------- */

$rol = $data->rol ?? null;

if (
    !is_string($rol) ||
    !in_array($rol, [
        "Docente",
        "Profesor honorario",
        "Jefe base"
    ], true)
) {
    responder(400, "El rol del contrato no es válido");
}

/* -----------------------------------------
   6. VALIDAR ESTADO
----------------------------------------- */

$status = $data->status ?? "Activo";

if (
    !is_string($status) ||
    !in_array($status, [
        "Activo",
        "Inactivo",
        "Vencido"
    ], true)
) {
    responder(400, "El estado del contrato no es válido");
}

/* -----------------------------------------
   7. VALIDAR FECHAS
----------------------------------------- */

$fecha_inicio = $data->fecha_inicio ?? null;

$fecha_fin = isset($data->fecha_fin) &&
             $data->fecha_fin !== ""
    ? $data->fecha_fin
    : null;

if (!fechaValida($fecha_inicio)) {
    responder(400, "La fecha de inicio no es válida");
}

if ($fecha_fin !== null && !fechaValida($fecha_fin)) {
    responder(400, "La fecha de fin no es válida");
}

if (
    $fecha_fin !== null &&
    $fecha_fin < $fecha_inicio
) {
    responder(
        400,
        "La fecha de fin no puede ser anterior a la fecha de inicio"
    );
}

$stmt = null;

try {

    $conn->begin_transaction();

    /* -----------------------------------------
       8. BLOQUEAR Y VALIDAR DOCENTE
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_docente, estado
        FROM docentes
        WHERE id_docente = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_docente);
    $stmt->execute();

    $docente = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$docente) {
        throw new DomainException(
            "El docente seleccionado no existe",
            404
        );
    }

    /*
     * Un contrato activo requiere
     * que el docente esté activo.
     */

    if (
        $status === "Activo" &&
        $docente["estado"] !== "Activo"
    ) {
        throw new DomainException(
            "No se puede registrar un contrato activo para un docente inactivo o dado de baja.",
            409
        );
    }

    /* -----------------------------------------
       9. CONSULTAR EDIFICIO DEL ÁREA
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_edificio
        FROM areas
        WHERE id_area = ?
    ");

    $stmt->bind_param("i", $id_area);
    $stmt->execute();

    $areaInicial = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$areaInicial) {
        throw new DomainException(
            "El área seleccionada no existe",
            404
        );
    }

    $id_edificio = (int)$areaInicial["id_edificio"];

    /* -----------------------------------------
       10. BLOQUEAR EDIFICIO
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_edificio, estado
        FROM edificios
        WHERE id_edificio = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_edificio);
    $stmt->execute();

    $edificio = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$edificio) {
        throw new DomainException(
            "El edificio asociado al área no existe",
            409
        );
    }

    /* -----------------------------------------
       11. BLOQUEAR Y VALIDAR ÁREA
    ----------------------------------------- */

    $stmt = $conn->prepare("
        SELECT id_area, id_edificio, estado
        FROM areas
        WHERE id_area = ?
        FOR UPDATE
    ");

    $stmt->bind_param("i", $id_area);
    $stmt->execute();

    $area = $stmt->get_result()->fetch_assoc();

    $stmt->close();
    $stmt = null;

    if (!$area) {
        throw new DomainException(
            "El área seleccionada ya no existe",
            404
        );
    }

    if ((int)$area["id_edificio"] !== $id_edificio) {
        throw new DomainException(
            "La ubicación del área cambió durante la operación. Consulta nuevamente sus datos.",
            409
        );
    }

    /*
     * Los contratos activos solamente
     * pueden pertenecer a áreas y edificios activos.
     */

    if ($status === "Activo") {

        if ($area["estado"] !== "Activo") {
            throw new DomainException(
                "No se puede registrar un contrato activo en un área inactiva.",
                409
            );
        }

        if ($edificio["estado"] !== "Activo") {
            throw new DomainException(
                "No se puede registrar un contrato activo en un edificio inactivo.",
                409
            );
        }
    }

    /* -----------------------------------------
       12. REGISTRAR CONTRATO
    ----------------------------------------- */

    $stmt = $conn->prepare("
        INSERT INTO contratos (
            id_docente,
            id_area,
            folio_contrato,
            horas,
            rol,
            status,
            fecha_inicio,
            fecha_fin
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "iisissss",
        $id_docente,
        $id_area,
        $folio,
        $horas,
        $rol,
        $status,
        $fecha_inicio,
        $fecha_fin
    );

    $stmt->execute();

    $id_contrato = $conn->insert_id;

    $stmt->close();
    $stmt = null;

    /* -----------------------------------------
       13. CONFIRMAR TRANSACCIÓN
    ----------------------------------------- */

    $conn->commit();

    responder(201, "Contrato registrado correctamente", [
        "data" => [
            "id_contrato" => $id_contrato,
            "id_docente" => $id_docente,
            "id_area" => $id_area,
            "folio_contrato" => $folio,
            "horas" => $horas,
            "rol" => $rol,
            "status" => $status,
            "fecha_inicio" => $fecha_inicio,
            "fecha_fin" => $fecha_fin
        ]
    ]);

} catch (DomainException $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    $codigoHTTP = $e->getCode();

    if ($codigoHTTP < 400 || $codigoHTTP > 599) {
        $codigoHTTP = 400;
    }

    responder($codigoHTTP, $e->getMessage());

} catch (mysqli_sql_exception $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error SQL contratos/registrar.php: " . $e->getMessage()
    );

    if ((int)$e->getCode() === 1062) {
        responder(
            409,
            "El folio del contrato ya se encuentra registrado."
        );
    }

    if ((int)$e->getCode() === 1452) {
        responder(
            409,
            "No se pudo registrar el contrato porque el docente o el área ya no existen."
        );
    }

    if (
        (int)$e->getCode() === 1213 ||
        (int)$e->getCode() === 1205
    ) {
        responder(
            409,
            "La operación tuvo un conflicto con otra actualización. Intenta nuevamente."
        );
    }

    responder(500, "Error de base de datos al registrar el contrato.");

} catch (Throwable $e) {

    try {
        $conn->rollback();
    } catch (Throwable $ignored) {
    }

    error_log(
        "Error contratos/registrar.php: " . $e->getMessage()
    );

    responder(500, "Error interno al registrar el contrato.");

} finally {

    if ($stmt) {
        $stmt->close();
    }

    $conn->close();
}

?>
