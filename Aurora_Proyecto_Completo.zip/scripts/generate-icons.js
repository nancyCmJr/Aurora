const fs = require('fs');
const path = require('path');

const icons = {
  'aurora-star': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="starGold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FEF08A"/>
      <stop offset="50%" stop-color="#F59E0B"/>
      <stop offset="100%" stop-color="#B45309"/>
    </linearGradient>
    <filter id="glowStar" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="0.8" result="glow"/>
      <feComposite in="SourceGraphic" in2="glow" operator="over"/>
    </filter>
  </defs>
  <path d="M12 2 Q12 12 2 12 Q12 12 12 22 Q12 12 22 12 Q12 12 12 2 Z" fill="url(#starGold)" filter="url(#glowStar)"/>
  <path d="M19 4 Q19 7 16 7 Q19 7 19 10 Q19 7 22 7 Q19 7 19 4 Z" fill="#FDE68A" opacity="0.85"/>
  <circle cx="12" cy="12" r="1.8" fill="#FFFFFF"/>
</svg>`,

  'aurora-gear': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="gearGoldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE68A"/>
      <stop offset="40%" stop-color="#F59E0B"/>
      <stop offset="100%" stop-color="#B45309"/>
    </linearGradient>
  </defs>
  <path fill-rule="evenodd" clip-rule="evenodd" d="M10.2 2.5C10.4 2.2 10.7 2 11.1 2H12.9C13.3 2 13.6 2.2 13.8 2.5L14.4 3.7C14.9 4 15.4 4.3 15.9 4.7L17.2 4.3C17.6 4.2 18 4.4 18.2 4.7L19.5 6.2C19.7 6.5 19.8 6.9 19.6 7.3L18.9 8.4C19.1 9 19.3 9.5 19.4 10.1L20.7 10.4C21.1 10.5 21.4 10.8 21.4 11.2V12.8C21.4 13.2 21.1 13.5 20.7 13.6L19.4 13.9C19.3 14.5 19.1 15 18.9 15.6L19.6 16.7C19.8 17.1 19.7 17.5 19.5 17.8L18.2 19.3C18 19.6 17.6 19.8 17.2 19.7L15.9 19.3C15.4 19.7 14.9 20 14.4 20.3L13.8 21.5C13.6 21.8 13.3 22 12.9 22H11.1C10.7 22 10.4 21.8 10.2 21.5L9.6 20.3C9.1 20 8.6 19.7 8.1 19.3L6.8 19.7C6.4 19.8 6 19.6 5.8 19.3L4.5 17.8C4.3 17.5 4.2 17.1 4.4 16.7L5.1 15.6C4.9 15 4.7 14.5 4.6 13.9L3.3 13.6C2.9 13.5 2.6 13.2 2.6 12.8V11.2C2.6 10.8 2.9 10.5 3.3 10.4L4.6 10.1C4.7 9.5 4.9 9 5.1 8.4L4.4 7.3C4.2 6.9 4.3 6.5 4.5 6.2L5.8 4.7C6 4.4 6.4 4.2 6.8 4.3L8.1 4.7C8.6 4.3 9.1 4 9.6 3.7L10.2 2.5ZM12 8C9.79 8 8 9.79 8 12C8 14.21 9.79 16 12 16C14.21 16 16 14.21 16 12C16 9.79 14.21 8 12 8Z" fill="url(#gearGoldGrad)"/>
  <circle cx="12" cy="12" r="2.8" fill="#1E1338" opacity="0.4"/>
</svg>`,

  'aurora-logo-mark': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="ribbonGold" x1="0%" y1="100%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#D97706"/>
      <stop offset="60%" stop-color="#F59E0B"/>
      <stop offset="100%" stop-color="#FDE68A"/>
    </linearGradient>
    <linearGradient id="ribbonPurple" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#C084FC"/>
      <stop offset="50%" stop-color="#9333EA"/>
      <stop offset="100%" stop-color="#581C87"/>
    </linearGradient>
  </defs>
  <path d="M5.5 19C4 18 3.5 15.5 5 13L10.5 4.5C11.2 3.4 12.8 3.4 13.5 4.5L15 7C14 8.5 12 11 9 12C6.5 12.8 5 15 5.5 17C6 19 8 20 10.5 19.5C13 19 14.5 17.5 15.5 16" stroke="url(#ribbonGold)" stroke-width="2.8" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M11 5.5L16.5 14C17.8 16 19.5 17.5 20.5 16C21.5 14.5 20 12 18.5 10L14 3.5" stroke="url(#ribbonPurple)" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M19.5 2.5 Q19.5 5 17 5 Q19.5 5 19.5 7.5 Q19.5 5 22 5 Q19.5 5 19.5 2.5 Z" fill="#FDE68A"/>
</svg>`,

  'aurora-shield': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="shieldBorder" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE68A"/>
      <stop offset="100%" stop-color="#D97706"/>
    </linearGradient>
    <linearGradient id="shieldFill" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="rgba(124, 58, 237, 0.45)"/>
      <stop offset="100%" stop-color="rgba(30, 19, 56, 0.75)"/>
    </linearGradient>
  </defs>
  <path d="M12 2L4 5V11C4 16.5 7.4 21.5 12 22C16.6 21.5 20 16.5 20 11V5L12 2Z" fill="url(#shieldFill)" stroke="url(#shieldBorder)" stroke-width="1.8" stroke-linejoin="round"/>
  <path d="M12 7 Q12 12 7 12 Q12 12 12 17 Q12 12 17 12 Q12 12 12 7 Z" fill="#FDE68A"/>
  <circle cx="12" cy="12" r="1.2" fill="#FFFFFF"/>
</svg>`,

  'aurora-carreras': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="capGold" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE68A"/>
      <stop offset="100%" stop-color="#D97706"/>
    </linearGradient>
    <linearGradient id="capPurple" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#C084FC"/>
      <stop offset="100%" stop-color="#7C3AED"/>
    </linearGradient>
  </defs>
  <path d="M12 3L2 8L12 13L22 8L12 3Z" fill="url(#capPurple)" stroke="url(#capGold)" stroke-width="1.5" stroke-linejoin="round"/>
  <path d="M6 10.5V15.5C6 17.5 8.7 19.5 12 19.5C15.3 19.5 18 17.5 18 15.5V10.5" stroke="url(#capPurple)" stroke-width="2" stroke-linecap="round"/>
  <path d="M22 8V14C22 15 21 16 20 16" stroke="url(#capGold)" stroke-width="1.5" stroke-linecap="round"/>
  <circle cx="20" cy="16.5" r="1.5" fill="#FDE68A"/>
</svg>`,

  'aurora-materias': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="bookGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE68A"/>
      <stop offset="50%" stop-color="#C084FC"/>
      <stop offset="100%" stop-color="#7C3AED"/>
    </linearGradient>
  </defs>
  <path d="M4 19.5V6C4 4.9 4.9 4 6 4C8.5 4 10.5 4.8 12 6.5C13.5 4.8 15.5 4 18 4C19.1 4 20 4.9 20 6V19.5C18.5 18.5 16 18 14 18C13 18 12.3 18.2 12 18.5C11.7 18.2 11 18 10 18C8 18 5.5 18.5 4 19.5Z" fill="rgba(124, 58, 237, 0.2)" stroke="url(#bookGrad)" stroke-width="1.8" stroke-linejoin="round"/>
  <path d="M12 6.5V18.5" stroke="#F59E0B" stroke-width="1.8" stroke-linecap="round"/>
  <path d="M12 6.5V12L14 10L16 12V6.5" fill="#F59E0B" opacity="0.9"/>
</svg>`,

  'aurora-edificios': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="campusGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE68A"/>
      <stop offset="100%" stop-color="#F59E0B"/>
    </linearGradient>
  </defs>
  <path d="M2 8L12 2L22 8H2Z" fill="url(#campusGrad)" stroke="#D97706" stroke-width="1"/>
  <path d="M4 8V18M8 8V18M12 8V18M16 8V18M20 8V18M2 18H22M1 21H23" stroke="url(#campusGrad)" stroke-width="1.8" stroke-linecap="round"/>
  <circle cx="12" cy="5.5" r="1" fill="#FFFFFF"/>
</svg>`,

  'aurora-alumnos': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="userGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE68A"/>
      <stop offset="50%" stop-color="#C084FC"/>
      <stop offset="100%" stop-color="#7C3AED"/>
    </linearGradient>
  </defs>
  <circle cx="12" cy="7" r="4" stroke="url(#userGrad)" stroke-width="1.8" fill="rgba(245, 158, 11, 0.15)"/>
  <path d="M4 21C4 16.5 7.5 14 12 14C16.5 14 20 16.5 20 21" stroke="url(#userGrad)" stroke-width="1.8" stroke-linecap="round"/>
  <path d="M15 16.5 Q15 18 13.5 18 Q15 18 15 19.5 Q15 18 16.5 18 Q15 18 15 16.5 Z" fill="#FDE68A"/>
</svg>`,

  'aurora-docentes': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="docGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE68A"/>
      <stop offset="100%" stop-color="#F59E0B"/>
    </linearGradient>
  </defs>
  <rect x="3" y="3" width="18" height="12" rx="2" stroke="url(#docGrad)" stroke-width="1.8" fill="rgba(124, 58, 237, 0.2)"/>
  <path d="M7 8H13M7 11H10" stroke="#FDE68A" stroke-width="1.5" stroke-linecap="round"/>
  <circle cx="17" cy="9" r="2" fill="#F59E0B"/>
  <path d="M14 14C14 12.5 15.5 12 17 12C18.5 12 20 12.5 20 14" stroke="#F59E0B" stroke-width="1.5" stroke-linecap="round"/>
  <path d="M12 15V21M8 21H16" stroke="url(#docGrad)" stroke-width="1.8" stroke-linecap="round"/>
</svg>`,

  'aurora-periodos': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="calGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE68A"/>
      <stop offset="50%" stop-color="#F59E0B"/>
      <stop offset="100%" stop-color="#D97706"/>
    </linearGradient>
  </defs>
  <rect x="3" y="4" width="18" height="17" rx="3" stroke="url(#calGrad)" stroke-width="1.8" fill="rgba(30, 19, 56, 0.6)"/>
  <path d="M3 9H21M8 2V5M16 2V5" stroke="url(#calGrad)" stroke-width="1.8" stroke-linecap="round"/>
  <circle cx="7.5" cy="13.5" r="1.2" fill="#C084FC"/>
  <circle cx="12" cy="13.5" r="1.2" fill="#C084FC"/>
  <path d="M16.5 12 Q16.5 13.5 15 13.5 Q16.5 13.5 16.5 15 Q16.5 13.5 18 13.5 Q16.5 13.5 16.5 12 Z" fill="#FDE68A"/>
  <circle cx="7.5" cy="17" r="1.2" fill="#C084FC"/>
  <circle cx="12" cy="17" r="1.2" fill="#F59E0B"/>
</svg>`,

  'aurora-kardex': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="karGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE68A"/>
      <stop offset="50%" stop-color="#C084FC"/>
      <stop offset="100%" stop-color="#7C3AED"/>
    </linearGradient>
  </defs>
  <path d="M5 3H15L19 7V20C19 20.6 18.6 21 18 21H5C4.4 21 4 20.6 4 20V4C4 3.4 4.4 3 5 3Z" stroke="url(#karGrad)" stroke-width="1.8" fill="rgba(30, 19, 56, 0.5)"/>
  <path d="M15 3V7H19" stroke="url(#karGrad)" stroke-width="1.8"/>
  <path d="M8 10H13M8 13H15M8 16H11" stroke="#CBD5E1" stroke-width="1.5" stroke-linecap="round"/>
  <circle cx="15" cy="16" r="2.5" fill="#F59E0B" stroke="#FDE68A" stroke-width="1"/>
</svg>`,

  'aurora-lock': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <defs>
    <linearGradient id="lockGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FDE68A"/>
      <stop offset="100%" stop-color="#D97706"/>
    </linearGradient>
  </defs>
  <rect x="5" y="10" width="14" height="11" rx="2.5" stroke="url(#lockGrad)" stroke-width="1.8" fill="rgba(30, 19, 56, 0.7)"/>
  <path d="M8 10V6.5C8 4.5 9.8 3 12 3C14.2 3 16 4.5 16 6.5V10" stroke="url(#lockGrad)" stroke-width="1.8" stroke-linecap="round"/>
  <circle cx="12" cy="15" r="1.5" fill="#FDE68A"/>
  <path d="M12 16.5V18.5" stroke="#FDE68A" stroke-width="1.5" stroke-linecap="round"/>
</svg>`,

  'aurora-sparkles': `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="24" height="24" fill="none">
  <path d="M9.5 2 Q9.5 9.5 2 9.5 Q9.5 9.5 9.5 17 Q9.5 9.5 17 9.5 Q9.5 9.5 9.5 2 Z" fill="#FDE68A"/>
  <path d="M18 13 Q18 16.5 14.5 16.5 Q18 16.5 18 20 Q18 16.5 21.5 16.5 Q18 16.5 18 13 Z" fill="#C084FC"/>
  <circle cx="18" cy="6" r="1.5" fill="#67E8F9"/>
</svg>`
};

const dir = path.join(__dirname, '..', 'src', 'assets', 'brand', 'icons');
if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

for (const [name, svg] of Object.entries(icons)) {
  fs.writeFileSync(path.join(dir, `${name}.svg`), svg, 'utf8');
}

// Generate Sprite
let sprite = '<svg xmlns="http://www.w3.org/2000/svg" style="display: none;">\n';
for (const [name, svg] of Object.entries(icons)) {
  const inner = svg.replace(/<\?xml.*?\?>/, '').replace(/<svg.*?>/, '').replace(/<\/svg>/, '').trim();
  sprite += `  <symbol id="${name}" viewBox="0 0 24 24">\n    ${inner}\n  </symbol>\n`;
}
sprite += '</svg>\n';
fs.writeFileSync(path.join(dir, 'aurora-icons.svg'), sprite, 'utf8');

console.log('Successfully generated ' + Object.keys(icons).length + ' icons and sprite!');
