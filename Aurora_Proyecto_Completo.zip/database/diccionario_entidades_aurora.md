# DICCIONARIO DE ENTIDADES Y ATRIBUTOS - SISTEMA AURORA
> **Versión:** 2.2 (Normalizada y Depurada - Sin redundancias)  
> **Total de Entidades:** 17  
> **Total de Relaciones:** 20  
> **Estructura:** Diccionario de Datos Normalizado (1FN / 2FN / 3FN) con domicilios atómicos y contratos centralizados.

---

## 1. MÓDULO DE INFRAESTRUCTURA FÍSICA

### 1. EDIFICIOS
*Representa las instalaciones físicas principales del plantel educativo.*
- `id_edificio` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador único del edificio.
- `clave_edificio` | **VARCHAR(10)** | `UNIQUE` | `NOT NULL` | Clave física o código (ej. `'EDIF-A'`, `'EDIF-K'`).
- `nombre` | **VARCHAR(80)** | - | `NOT NULL` | Nombre descriptivo del inmueble (ej. `'Edificio de Sistemas y Computación'`).

### 2. AREAS
*Departamentos, jefaturas o academias ubicadas dentro de un edificio.*
- `id_area` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador único del área académica o administrativa.
- `clave_area` | **VARCHAR(15)** | `UNIQUE` | `NOT NULL` | Clave institucional (ej. `'DSC'`, `'CIENC_BAS'`).
- `nombre` | **VARCHAR(120)** | - | `NOT NULL` | Nombre del departamento (ej. `'Departamento de Sistemas y Computación'`).
- `id_edificio` | **INT** | `FK -> edificios(id_edificio)` | `NOT NULL` | Edificio físico donde se encuentra ubicada.

### 3. SALONES
*Espacios físicos específicos destinados a clases teóricas, prácticas o eventos.*
- `id_salon` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador único del salón.
- `clave_salon` | **VARCHAR(15)** | `UNIQUE` | `NOT NULL` | Clave o identificador del espacio (ej. `'LC1'`, `'AULA-101'`).
- `nombre` | **VARCHAR(80)** | - | `NOT NULL` | Nombre común del aula o laboratorio.
- `tipo` | **ENUM('Aula', 'Laboratorio', 'Taller', 'Auditorio')** | - | `DEFAULT 'Aula'` | Clasificación del espacio físico.
- `capacidad` | **INT** | - | `NOT NULL` | Número de alumnos o asientos disponibles.
- `id_edificio` | **INT** | `FK -> edificios(id_edificio)` | `NOT NULL` | Edificio físico al que pertenece.
- `id_area` | **INT** | `FK -> areas(id_area)` | `NOT NULL` | Área o departamento académico que administra el espacio.

---

## 2. MÓDULO DE PERSONAL DOCENTE Y ASIGNACIONES

### 4. DOCENTES
*Registro principal del personal académico del instituto.*
- `id_docente` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador único interno del profesor.
- `codigo` | **VARCHAR(20)** | `UNIQUE` | `NOT NULL` | Número de empleado o clave de nómina (ej. `'DOC-2026-01'`).
- `cedula` | **VARCHAR(20)** | `UNIQUE` | `NOT NULL` | Cédula profesional oficial registrada ante la SEP/DGP.
- `nombre` | **VARCHAR(60)** | - | `NOT NULL` | Primer nombre del profesor.
- `seg_nombre` | **VARCHAR(60)** | - | `NULL` | Segundo nombre del profesor (opcional).
- `apellidos` | **VARCHAR(100)** | - | `NOT NULL` | Apellidos paterno y materno.
- `titulo_academico` | **VARCHAR(100)** | - | `NULL` | Grado o especialidad académica (ej. `'Mtro. en Ciencias'`).
- `estado` | **VARCHAR(20)** | - | `NOT NULL (DEFAULT 'Activo')` | Situación laboral operativa (`'Activo'`, `'Licencia'`, `'Baja'`).

### 5. DETALLE_DOCENTES
*Extensión 1:1 con Docentes para resguardar exclusivamente datos personales y de contacto sin duplicar información laboral.*
- `id_docente` | **INT** | `PK, FK -> docentes(id_docente)` | `NOT NULL (ON DELETE CASCADE)` | Llave primaria compartida (Relación 1 a 1).
- `curp` | **VARCHAR(18)** | `UNIQUE` | `NOT NULL` | Clave Única de Registro de Población.
- `rfc` | **VARCHAR(13)** | `UNIQUE` | `NULL` | Registro Federal de Contribuyentes con homoclave.
- `fecha_nacimiento` | **DATE** | - | `NULL` | Fecha de nacimiento del docente.
- `telefono` | **VARCHAR(15)** | - | `NULL` | Teléfono móvil o de contacto.
- `email` | **VARCHAR(100)** | - | `NULL` | Correo electrónico personal.
- `calle` | **VARCHAR(100)** | - | `NOT NULL` | Nombre de la vialidad, calle, avenida o calzada.
- `numero_exterior` | **VARCHAR(10)** | - | `NOT NULL` | Número exterior oficial (ej. `'124'`, `'102-B'`, `'S/N'`).
- `numero_interior` | **VARCHAR(10)** | - | `NULL` | Departamento, piso o interior (ej. `'Depto 3B'`, `'Int 2'`).
- `colonia` | **VARCHAR(80)** | - | `NOT NULL` | Colonia, fraccionamiento o barrio (ej. `'Fracc. Las Palmas'`).
- `codigo_postal` | **CHAR(5)** | - | `NOT NULL` | Código postal oficial de 5 dígitos (ej. `'83000'`).
- `municipio` | **VARCHAR(80)** | - | `NOT NULL` | Municipio, delegación o alcaldía (ej. `'Hermosillo'`).
- `estado` | **VARCHAR(50)** | - | `NOT NULL` | Entidad federativa o estado (ej. `'Sonora'`).
- `referencias` | **VARCHAR(150)** | - | `NULL` | Referencias descriptivas para localización del domicilio.
- `fecha_ingreso` | **DATE** | - | `NULL` | Fecha en que el docente ingresó por primera vez a laborar al instituto.

### 6. CONTRATOS
*Tabla asociativa (M:N) que administra los contratos, roles, horas y vigencias por área sin duplicidad.*
- `id_contrato` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador único del contrato.
- `id_docente` | **INT** | `FK -> docentes(id_docente)` | `NOT NULL (ON DELETE RESTRICT)` | Docente contratado.
- `id_area` | **INT** | `FK -> areas(id_area)` | `NOT NULL (ON DELETE RESTRICT)` | Área o departamento de adscripción.
- `folio_contrato` | **VARCHAR(30)** | `UNIQUE` | `NOT NULL` | Folio oficial del contrato administrativo.
- `horas` | **INT** | - | `NOT NULL` | Horas contratadas para esta área académica específica.
- `rol` | **ENUM('Docente', 'Profesor_honorario', 'Jefe_base')** | - | `DEFAULT 'Docente'` | Cargo o nombramiento desempeñado en el área.
- `status` | **ENUM('Activo', 'Inactivo', 'Vencido')** | - | `DEFAULT 'Activo'` | Estatus de vigencia del contrato.
- `fecha_inicio` | **DATE** | - | `NOT NULL` | Fecha de inicio de labores en el área según contrato.
- `fecha_fin` | **DATE** | - | `NULL` | Fecha de conclusión del contrato (o NULL si es nombramiento definitivo).

---

## 3. MÓDULO DE OFERTA ACADÉMICA Y PLANES DE ESTUDIO

### 7. CARRERAS
*Programas educativos ofrecidos por la institución.*
- `id_carrera` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador de la carrera.
- `clave_carrera` | **VARCHAR(20)** | `UNIQUE` | `NOT NULL` | Clave oficial del programa (ej. `'ISIC-2010-224'`).
- `nombre` | **VARCHAR(120)** | - | `NOT NULL` | Nombre oficial (ej. `'Ingeniería en Sistemas Computacionales'`).
- `nivel` | **VARCHAR(30)** | - | `NOT NULL (DEFAULT 'Licenciatura')` | Nivel académico (`'Licenciatura'`, `'Maestría'`, `'Doctorado'`).
- `total_creditos` | **INT** | - | `NOT NULL (DEFAULT 260)` | Total de créditos requeridos para titulación.

### 8. RETICULAS
*Versiones o planes curriculares por cohorte y año de una carrera.*
- `id_reticula` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador único de la retícula.
- `clave_reticula` | **VARCHAR(25)** | `UNIQUE` | `NOT NULL` | Clave identificadora (ej. `'RET-ISIC-2024'`).
- `anio` | **INT** | - | `NOT NULL` | Año de aprobación o vigencia del plan (ej. `2024`).
- `id_carrera` | **INT** | `FK -> carreras(id_carrera)` | `NOT NULL (ON DELETE RESTRICT)` | Carrera a la que corresponde.

### 9. MATERIAS
*Catálogo de asignaturas impartidas en el instituto con recursividad de seriación.*
- `id_materia` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador único de la asignatura.
- `clave_materia` | **VARCHAR(15)** | `UNIQUE` | `NOT NULL` | Clave oficial (ej. `'SCD-1015'`).
- `nombre` | **VARCHAR(150)** | - | `NOT NULL` | Nombre oficial de la materia (ej. `'Estructura de Datos'`).
- `creditos` | **INT** | - | `NOT NULL` | Valor en créditos SATCA.
- `horas_teoricas` | **INT** | - | `NOT NULL (DEFAULT 0)` | Horas de docencia teórica semanal.
- `horas_practicas` | **INT** | - | `NOT NULL (DEFAULT 0)` | Horas de taller/laboratorio semanal.
- `id_materia_requisito` | **INT** | `FK -> materias(id_materia)` | `NULL (ON DELETE SET NULL)` | **Recursividad:** Materia antecedente requerida (prerrequisito seriado).

### 10. RETICULA_MATERIA
*Tabla asociativa (M:N) que posiciona cada materia dentro de una retícula específica.*
- `id_reticula` | **INT** | `PK, FK -> reticulas(id_reticula)` | `NOT NULL (ON DELETE CASCADE)` | Retícula correspondiente.
- `id_materia` | **INT** | `PK, FK -> materias(id_materia)` | `NOT NULL (ON DELETE RESTRICT)` | Materia incluida en el mapa curricular.
- `semestre` | **INT** | - | `NOT NULL` | Semestre sugerido para cursarla (1 al 9).

---

## 4. MÓDULO DE ALUMNOS E INSCRIPCIONES

### 11. ALUMNOS
*Padrón principal de estudiantes inscritos.*
- `numero_control` | **VARCHAR(20)** | `PK` | `NOT NULL` | Número de control institucional (ej. `'21070045'`).
- `nombre` | **VARCHAR(60)** | - | `NOT NULL` | Primer nombre del estudiante.
- `seg_nombre` | **VARCHAR(60)** | - | `NULL` | Segundo nombre del estudiante (opcional).
- `apellidos` | **VARCHAR(100)** | - | `NOT NULL` | Apellidos paterno y materno.
- `semestre` | **INT** | - | `NOT NULL (DEFAULT 1)` | Semestre en curso actual.

### 12. DETALLE_ALUMNO
*Extensión 1:1 con Alumnos para resguardar información personal, médica y de contacto.*
- `numero_control` | **VARCHAR(20)** | `PK, FK -> alumnos(numero_control)` | `NOT NULL (ON DELETE CASCADE)` | Llave primaria compartida (Relación 1 a 1).
- `curp` | **VARCHAR(18)** | `UNIQUE` | `NOT NULL` | CURP oficial del estudiante.
- `fecha_nacimiento` | **DATE** | - | `NULL` | Fecha de nacimiento.
- `telefono` | **VARCHAR(15)** | - | `NULL` | Teléfono personal del estudiante.
- `email` | **VARCHAR(100)** | - | `NULL` | Correo electrónico personal.
- `calle` | **VARCHAR(100)** | - | `NOT NULL` | Nombre de la vialidad, calle, avenida o calzada.
- `numero_exterior` | **VARCHAR(10)** | - | `NOT NULL` | Número exterior oficial (ej. `'124'`, `'102-B'`, `'S/N'`).
- `numero_interior` | **VARCHAR(10)** | - | `NULL` | Departamento, piso o interior (ej. `'Depto 3B'`, `'Int 2'`).
- `colonia` | **VARCHAR(80)** | - | `NOT NULL` | Colonia, fraccionamiento o barrio (ej. `'Fracc. Las Palmas'`).
- `codigo_postal` | **CHAR(5)** | - | `NOT NULL` | Código postal oficial de 5 dígitos (ej. `'83000'`).
- `municipio` | **VARCHAR(80)** | - | `NOT NULL` | Municipio, delegación o alcaldía (ej. `'Hermosillo'`).
- `estado` | **VARCHAR(50)** | - | `NOT NULL` | Entidad federativa o estado (ej. `'Sonora'`).
- `referencias` | **VARCHAR(150)** | - | `NULL` | Referencias descriptivas de ubicación del domicilio.
- `datos_contacto` | **VARCHAR(255)** | - | `NULL` | Nombre y teléfono de emergencia / tutor legal.
- `situacion_academica` | **VARCHAR(30)** | - | `NOT NULL (DEFAULT 'Regular')` | Estado académico (`'Regular'`, `'Especial'`, `'Baja'`).
- `fecha_ingreso` | **DATE** | - | `NULL` | Fecha de primer ingreso a la institución.

### 13. INSCRIPCIONES
*Tabla asociativa (M:N) entre Alumnos y Carreras.*
- `numero_control` | **VARCHAR(20)** | `PK, FK -> alumnos(numero_control)` | `NOT NULL (ON DELETE CASCADE)` | Alumno registrado.
- `id_carrera` | **INT** | `PK, FK -> carreras(id_carrera)` | `NOT NULL (ON DELETE RESTRICT)` | Carrera cursada.
- `fecha_inscripcion` | **DATE** | - | `NOT NULL` | Fecha de alta en el programa.
- `periodo` | **VARCHAR(20)** | - | `NOT NULL` | Periodo escolar de inicio (ej. `'2024-1'`).
- `estado` | **ENUM('Finalizada', 'En curso')** | - | `DEFAULT 'En curso'` | Situación curricular en el programa.

---

## 5. MÓDULO DE KÁRDEX, GRUPOS Y HORARIOS

### 14. KARDEX
*Historial académico oficial con calificaciones, docente titular y salón evaluador.*
- `id_kardex` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador del registro curricular de acreditación.
- `numero_control` | **VARCHAR(20)** | `FK -> alumnos(numero_control)` | `NOT NULL (ON DELETE RESTRICT)` | Alumno que cursó la asignatura.
- `id_materia` | **INT** | `FK -> materias(id_materia)` | `NOT NULL (ON DELETE RESTRICT)` | Materia cursada.
- `id_salon` | **INT** | `FK -> salones(id_salon)` | `NOT NULL (ON DELETE RESTRICT)` | Salón donde se impartió la materia.
- `id_docente` | **INT** | `FK -> docentes(id_docente)` | `NOT NULL (ON DELETE RESTRICT)` | Docente titular que impartió y calificó.
- `calificacion` | **DECIMAL(5,2)** | - | `NOT NULL` | Calificación final obtenida (0.00 a 100.00).
- `periodo` | **VARCHAR(20)** | - | `NOT NULL` | Ciclo escolar cursado (ej. `'Ene-Jun 2026'`).
- `anio` | **INT** | - | `NOT NULL` | Año en que se cursó.
- `tipo_calf` | **ENUM('Ordinario', 'Recuperacion', 'No aprobatorio')** | - | `DEFAULT 'Ordinario'` | Modalidad de acreditación.

### 15. GRUPOS
*Agrupación de estudiantes para la asignación de materias (según el esquema del docente).*
- `id_grupo` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador único del grupo.
- `clave_grupo` | **VARCHAR(15)** | - | `NOT NULL` | Clave o identificador del grupo (ej. `'7A'`, `'3B'`).
- `capacidad` | **INT** | - | `NOT NULL (DEFAULT 40)` | Cupo máximo de alumnos.
- `id_kardex` | **INT** | `FK -> kardex(id_kardex)` | `NOT NULL (ON DELETE CASCADE)` | Asignación curricular según registro del curso.
- `turno` | **VARCHAR(20)** | - | `NULL` | Turno de clases (`'Matutino'`, `'Vespertino'`).
- `semestre` | **INT** | - | `NULL` | Semestre al que pertenece el grupo.

### 16. HORARIOS
*Estructura de asignación de días y bloques horarios a grupos y aulas.*
- `id_horario` | **INT** | `PK` | `AUTO_INCREMENT` | Identificador único del bloque horario.
- `id_grupo` | **INT** | `FK -> grupos(id_grupo)` | `NOT NULL (ON DELETE CASCADE)` | Grupo que recibe la sesión.
- `id_salon` | **INT** | `FK -> salones(id_salon)` | `NOT NULL (ON DELETE RESTRICT)` | Salón asignado para el bloque.
- `dia_semana` | **VARCHAR(15)** | - | `NOT NULL` | Día de la clase (`'Lunes'`, `'Martes'`, etc.).
- `hora_inicio` | **TIME** | - | `NOT NULL` | Hora de inicio (ej. `'07:00:00'`).
- `hora_fin` | **TIME** | - | `NOT NULL` | Hora de finalización (ej. `'09:00:00'`).

---

## 6. MÓDULO DE SEGURIDAD Y ACCESO (RBAC)

### 17. USUARIOS
*Control de acceso y autenticación para la aplicación móvil y panel web.*
- `codigo` | **VARCHAR(30)** | `PK` | `NOT NULL` | Identificador de acceso (número de control de alumno o código de nómina docente/admin).
- `nombre_usuario` | **VARCHAR(50)** | `UNIQUE` | `NOT NULL` | Nickname o username para inicio de sesión.
- `rol` | **ENUM('Admin', 'Docente', 'Alumno')** | - | `NOT NULL` | Rol de permisos RBAC en el sistema.
- `correo` | **VARCHAR(100)** | - | `NOT NULL` | Correo de recuperación e institucional.
- `password` | **VARCHAR(255)** | - | `NOT NULL` | Hash seguro de contraseña encriptada (`bcrypt`).
- `estado` | **VARCHAR(20)** | - | `NOT NULL (DEFAULT 'Activo')` | Estado de la cuenta (`'Activo'`, `'Suspendido'`).

---

## 7. RESUMEN FORMAL DE RELACIONES (20 RELACIONES EXACTAS)

1. **Docentes (1) ──── (1) Detalle_Docentes**  
   `detalle_docentes.id_docente` $\rightarrow$ `docentes.id_docente` *(1:1 - Datos bio-demográficos y personales)*
2. **Docentes (1) ──── (M) Contratos**  
   `contratos.id_docente` $\rightarrow$ `docentes.id_docente` *(1:N - Adscripción, rol, vigencia y horas por área)*
3. **Áreas (1) ──── (M) Contratos**  
   `contratos.id_area` $\rightarrow$ `areas.id_area` *(1:N - Docentes adscritos al área/academia)*
4. **Docentes (1) ──── (M) Kardex**  
   `kardex.id_docente` $\rightarrow$ `docentes.id_docente` *(1:N - Docente titular que impartió y evaluó)*
5. **Edificios (1) ──── (M) Áreas**  
   `areas.id_edificio` $\rightarrow$ `edificios.id_edificio` *(1:N - Departamentos ubicados en el edificio)*
6. **Edificios (1) ──── (M) Salones**  
   `salones.id_edificio` $\rightarrow$ `edificios.id_edificio` *(1:N - Aulas físicas dentro del edificio)*
7. **Áreas (1) ──── (M) Salones**  
   `salones.id_area` $\rightarrow$ `areas.id_area` *(1:N - Academia o jefatura que administra el salón)*
8. **Salones (1) ──── (M) Kardex**  
   `kardex.id_salon` $\rightarrow$ `salones.id_salon` *(1:N - Aula física donde se impartió la materia)*
9. **Salones (1) ──── (M) Horarios**  
   `horarios.id_salon` $\rightarrow$ `salones.id_salon` *(1:N - Salón ocupado en un bloque horario)*
10. **Carreras (1) ──── (M) Retículas**  
    `reticulas.id_carrera` $\rightarrow$ `carreras.id_carrera` *(1:N - Planes de estudio de la carrera)*
11. **Carreras (1) ──── (M) Inscripciones**  
    `inscripciones.id_carrera` $\rightarrow$ `carreras.id_carrera` *(1:N - Matrícula de la carrera)*
12. **Alumnos (1) ──── (M) Inscripciones**  
    `inscripciones.numero_control` $\rightarrow$ `alumnos.numero_control` *(1:N - Carreras en las que está inscrito el alumno)*
13. **Alumnos (1) ──── (1) Detalle_Alumno**  
    `detalle_alumno.numero_control` $\rightarrow$ `alumnos.numero_control` *(1:1 - Información personal, domicilio y contacto)*
14. **Alumnos (1) ──── (M) Kardex**  
    `kardex.numero_control` $\rightarrow$ `alumnos.numero_control` *(1:N - Historial de calificaciones del alumno)*
15. **Retículas (1) ──── (M) Retícula_Materia**  
    `reticula_materia.id_reticula` $\rightarrow$ `reticulas.id_reticula` *(1:N - Materias que pertenecen al plan de estudios)*
16. **Materias (1) ──── (M) Retícula_Materia**  
    `reticula_materia.id_materia` $\rightarrow$ `materias.id_materia` *(1:N - Asignación de la materia en retículas)*
17. **Materias (1) ──── (M) Materias**  
    `materias.id_materia_requisito` $\rightarrow$ `materias.id_materia` *(1:N Recursiva - Prerrequisitos y seriación)*
18. **Materias (1) ──── (M) Kardex**  
    `kardex.id_materia` $\rightarrow$ `materias.id_materia` *(1:N - Materia cursada y asentada en el kárdex)*
19. **Kardex (1) ──── (M) Grupos**  
    `grupos.id_kardex` $\rightarrow$ `kardex.id_kardex` *(1:N - Asignación de grupo vinculada a registro de curso)*
20. **Grupos (1) ──── (M) Horarios**  
    `horarios.id_grupo` $\rightarrow$ `grupos.id_grupo` *(1:N - Bloques de horarios asignados al grupo)*
