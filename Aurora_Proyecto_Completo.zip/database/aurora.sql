CREATE DATABASE IF NOT EXISTS aurora
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE aurora;
SET NAMES utf8mb4;

CREATE TABLE edificios (
    id_edificio INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(30) NOT NULL UNIQUE,
    estado ENUM('Activo','Inactivo') NOT NULL DEFAULT 'Activo'
) ENGINE=InnoDB;

CREATE TABLE areas (
    id_area INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    id_edificio INT NOT NULL,
    estado ENUM('Activo','Inactivo') NOT NULL DEFAULT 'Activo',
    CONSTRAINT uq_area_edificio_nombre UNIQUE (id_edificio, nombre),
    CONSTRAINT uq_area_edificio_id UNIQUE (id_area, id_edificio),

    CONSTRAINT fk_areas_edificios
        FOREIGN KEY (id_edificio)
        REFERENCES edificios(id_edificio)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE salones (
    id_salon INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    tipo ENUM('Aula','Laboratorio','Taller','Auditorio')
        NOT NULL DEFAULT 'Aula',
    capacidad INT NOT NULL,
    id_edificio INT NOT NULL,
    id_area INT NOT NULL,
    estado ENUM('Activo','Inactivo') NOT NULL DEFAULT 'Activo',
    CONSTRAINT uq_salon_edificio_nombre UNIQUE (id_edificio, nombre),

    CONSTRAINT chk_salon_capacidad CHECK (capacidad > 0),

    CONSTRAINT fk_salones_edificios
        FOREIGN KEY (id_edificio)
        REFERENCES edificios(id_edificio)
        ON UPDATE CASCADE ON DELETE RESTRICT,

    CONSTRAINT fk_salones_area_edificio
        FOREIGN KEY (id_area, id_edificio)
        REFERENCES areas(id_area, id_edificio)
        ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE=InnoDB;

-- =========================================================
-- 2. CARRERAS Y ALUMNOS
-- =========================================================

CREATE TABLE carreras (
    id_carrera INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(120) NOT NULL,
    tipo ENUM('Ingenieria','Licenciatura','Maestria') NOT NULL,
    total_creditos INT NOT NULL,
    estado ENUM('Activa','Inactiva') NOT NULL DEFAULT 'Activa',

    CONSTRAINT chk_carrera_creditos CHECK (total_creditos > 0),
    CONSTRAINT uq_carrera_nombre_tipo UNIQUE (nombre, tipo)
) ENGINE=InnoDB;

CREATE TABLE alumnos (
    numero_control VARCHAR(20) PRIMARY KEY,
    nombre VARCHAR(60) NOT NULL,
    seg_nombre VARCHAR(60) NULL,
    apellidos VARCHAR(100) NOT NULL,
    semestre INT NOT NULL DEFAULT 1,

    estado ENUM(
        'Activo',
        'Baja temporal',
        'Baja definitiva',
        'Egresado',
        'Titulado'
    ) NOT NULL DEFAULT 'Activo',

    fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_alumno_semestre
        CHECK (semestre BETWEEN 1 AND 20)
) ENGINE=InnoDB;

CREATE TABLE detalle_alumno (
    id_detalle_alu INT AUTO_INCREMENT PRIMARY KEY,
    numero_control VARCHAR(20) NOT NULL UNIQUE,
    curp CHAR(18) NULL UNIQUE,
    fecha_nacimiento DATE NULL,
    telefono VARCHAR(15) NULL,
    email VARCHAR(100) NULL UNIQUE,
    calle VARCHAR(100) NULL,
    numero_exterior VARCHAR(10) NULL,
    numero_interior VARCHAR(10) NULL,
    colonia VARCHAR(80) NULL,
    codigo_postal CHAR(5) NULL,
    municipio VARCHAR(80) NULL,
    estado VARCHAR(50) NULL,
    referencias VARCHAR(150) NULL,
    datos_contacto VARCHAR(255) NULL,
    situacion_academica VARCHAR(30) NULL,
    fecha_ingreso DATE NULL,

    CONSTRAINT chk_alumno_curp
        CHECK (curp IS NULL OR curp REGEXP '^[A-Z0-9]{18}$'),

    CONSTRAINT chk_alumno_cp
        CHECK (codigo_postal IS NULL OR codigo_postal REGEXP '^[0-9]{5}$'),

    CONSTRAINT fk_detalle_alumno
        FOREIGN KEY (numero_control)
        REFERENCES alumnos(numero_control)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE inscripciones (
    id_inscripciones INT AUTO_INCREMENT PRIMARY KEY,
    numero_control VARCHAR(20) NOT NULL,
    id_carrera INT NOT NULL,
    fecha_inscripcion DATE NOT NULL DEFAULT (CURRENT_DATE),
    periodo VARCHAR(20) NOT NULL,
    anio YEAR NOT NULL,

    estado ENUM('Finalizada','En curso','Cancelada')
        NOT NULL DEFAULT 'En curso',

    numero_control_en_curso VARCHAR(20) GENERATED ALWAYS AS
        (CASE WHEN estado = 'En curso' THEN numero_control ELSE NULL END) STORED,
    CONSTRAINT uq_inscripcion_alumno_ciclo UNIQUE (numero_control, periodo, anio),
    CONSTRAINT uq_inscripcion_unica_en_curso UNIQUE (numero_control_en_curso),
    CONSTRAINT chk_inscripcion_periodo CHECK (CHAR_LENGTH(TRIM(periodo)) > 0),

    CONSTRAINT fk_inscripcion_alumno
        FOREIGN KEY (numero_control)
        REFERENCES alumnos(numero_control)
        ON UPDATE CASCADE ON DELETE RESTRICT,

    CONSTRAINT fk_inscripcion_carrera
        FOREIGN KEY (id_carrera)
        REFERENCES carreras(id_carrera)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- =========================================================
-- 3. DOCENTES Y CONTRATOS
-- =========================================================

CREATE TABLE docentes (
    id_docente INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(20) NOT NULL UNIQUE,
    cedula VARCHAR(20) NULL UNIQUE,
    nombre VARCHAR(60) NOT NULL,
    seg_nombre VARCHAR(60) NULL,
    apellidos VARCHAR(100) NOT NULL,
    titulo_academico VARCHAR(100) NULL,

    estado ENUM('Activo','Inactivo','Baja')
        NOT NULL DEFAULT 'Activo'
) ENGINE=InnoDB;

CREATE TABLE detalle_docentes (
    id_detalle_doc INT AUTO_INCREMENT PRIMARY KEY,
    id_docente INT NOT NULL UNIQUE,
    curp CHAR(18) NULL UNIQUE,
    rfc VARCHAR(13) NULL UNIQUE,
    fecha_nacimiento DATE NULL,
    telefono VARCHAR(15) NULL,
    email VARCHAR(100) NULL UNIQUE,
    calle VARCHAR(100) NULL,
    numero_exterior VARCHAR(10) NULL,
    numero_interior VARCHAR(10) NULL,
    colonia VARCHAR(80) NULL,
    codigo_postal CHAR(5) NULL,
    municipio VARCHAR(80) NULL,
    estado VARCHAR(50) NULL,
    referencias VARCHAR(150) NULL,
    fecha_ingreso DATE NULL,

    CONSTRAINT chk_docente_curp
        CHECK (curp IS NULL OR curp REGEXP '^[A-Z0-9]{18}$'),

    CONSTRAINT chk_docente_cp
        CHECK (codigo_postal IS NULL OR codigo_postal REGEXP '^[0-9]{5}$'),

    CONSTRAINT fk_detalle_docente
        FOREIGN KEY (id_docente)
        REFERENCES docentes(id_docente)
        ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE contratos (
    id_contrato INT AUTO_INCREMENT PRIMARY KEY,
    id_docente INT NOT NULL,
    id_area INT NOT NULL,
    folio_contrato VARCHAR(30) NOT NULL UNIQUE,
    horas INT NOT NULL,

    rol ENUM('Docente','Profesor honorario','Jefe base') NOT NULL,

    status ENUM('Activo','Inactivo','Vencido')
        NOT NULL DEFAULT 'Activo',

    fecha_inicio DATE NOT NULL,
    fecha_fin DATE NULL,

    CONSTRAINT chk_contrato_horas CHECK (horas > 0),

    CONSTRAINT chk_contrato_fechas
        CHECK (fecha_fin IS NULL OR fecha_fin >= fecha_inicio),

    CONSTRAINT fk_contrato_docente
        FOREIGN KEY (id_docente)
        REFERENCES docentes(id_docente)
        ON UPDATE CASCADE ON DELETE RESTRICT,

    CONSTRAINT fk_contrato_area
        FOREIGN KEY (id_area)
        REFERENCES areas(id_area)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- =========================================================
-- 4. MATERIAS Y RETÍCULAS
-- =========================================================

CREATE TABLE materias (
    id_materia INT AUTO_INCREMENT PRIMARY KEY,
    clave_materia VARCHAR(15) NOT NULL UNIQUE,
    nombre VARCHAR(150) NOT NULL,
    creditos INT NOT NULL,
    horas_teoricas INT NOT NULL DEFAULT 0,
    horas_practicas INT NOT NULL DEFAULT 0,
    id_materia_requisito INT NULL,

    estado ENUM('Activa','Inactiva')
        NOT NULL DEFAULT 'Activa',

    CONSTRAINT chk_materia_creditos
        CHECK (creditos BETWEEN 3 AND 6),

    CONSTRAINT chk_materia_horas
        CHECK (
            horas_teoricas >= 0
            AND horas_practicas >= 0
        ),

    CONSTRAINT fk_materia_requisito
        FOREIGN KEY (id_materia_requisito)
        REFERENCES materias(id_materia)
        ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE reticulas (
    id_reticula INT AUTO_INCREMENT PRIMARY KEY,
    anio YEAR NOT NULL,
    id_carrera INT NOT NULL,

    estado ENUM('Vigente','No vigente')
        NOT NULL DEFAULT 'Vigente',
    id_carrera_vigente INT GENERATED ALWAYS AS
        (CASE WHEN estado = 'Vigente' THEN id_carrera ELSE NULL END) STORED,
    CONSTRAINT uq_reticula_carrera_anio UNIQUE (id_carrera, anio),
    CONSTRAINT uq_reticula_una_vigente UNIQUE (id_carrera_vigente),

    CONSTRAINT fk_reticula_carrera
        FOREIGN KEY (id_carrera)
        REFERENCES carreras(id_carrera)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE reticula_materia (
    id_reticula INT NOT NULL,
    id_materia INT NOT NULL,
    semestre INT NOT NULL,

    PRIMARY KEY (id_reticula, id_materia),

    CONSTRAINT chk_reticula_semestre
        CHECK (semestre BETWEEN 1 AND 20),

    CONSTRAINT fk_rm_reticula
        FOREIGN KEY (id_reticula)
        REFERENCES reticulas(id_reticula)
        ON UPDATE RESTRICT ON DELETE RESTRICT,

    CONSTRAINT fk_rm_materia
        FOREIGN KEY (id_materia)
        REFERENCES materias(id_materia)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;


-- =========================================================
-- 6. GRUPOS
-- =========================================================

CREATE TABLE grupos (
    id_grupo INT AUTO_INCREMENT PRIMARY KEY,
    clave_grupo VARCHAR(20) NOT NULL,
    capacidad INT NOT NULL,
    semestre INT NOT NULL,
    id_materia INT NOT NULL,
    id_docente INT NOT NULL,
    periodo VARCHAR(20) NOT NULL,
    anio YEAR NOT NULL,

    modalidad ENUM('Entre semana','Sabado')
        NOT NULL DEFAULT 'Entre semana',

    estado ENUM('Planeado','Abierto','Cerrado','Cancelado')
        NOT NULL DEFAULT 'Planeado',

    CONSTRAINT uq_grupo_clave_ciclo
        UNIQUE (clave_grupo, periodo, anio),
    CONSTRAINT uq_grupo_identidad_ciclo
        UNIQUE (id_grupo, periodo, anio),
    CONSTRAINT chk_grupo_periodo CHECK (CHAR_LENGTH(TRIM(periodo)) > 0),

    CONSTRAINT chk_grupo_capacidad
        CHECK (capacidad > 0),

    CONSTRAINT chk_grupo_semestre
        CHECK (semestre BETWEEN 1 AND 20),

    CONSTRAINT fk_grupo_materia
        FOREIGN KEY (id_materia)
        REFERENCES materias(id_materia)
        ON UPDATE CASCADE ON DELETE RESTRICT,

    CONSTRAINT fk_grupo_docente
        FOREIGN KEY (id_docente)
        REFERENCES docentes(id_docente)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;


-- =========================================================
-- 7. HORARIOS
-- =========================================================

CREATE TABLE horarios (
    id_horario INT AUTO_INCREMENT PRIMARY KEY,
    id_grupo INT NOT NULL,
    id_salon INT NOT NULL,

    dia_semana ENUM(
        'Lunes',
        'Martes',
        'Miercoles',
        'Jueves',
        'Viernes',
        'Sabado'
    ) NOT NULL,

    hora_inicio TIME NOT NULL,
    hora_fin TIME NOT NULL,
    estado ENUM('Activo','Cancelado') NOT NULL DEFAULT 'Activo',

    CONSTRAINT chk_horario_horas
        CHECK (hora_fin > hora_inicio),

    CONSTRAINT fk_horario_grupo
        FOREIGN KEY (id_grupo)
        REFERENCES grupos(id_grupo)
        ON UPDATE RESTRICT ON DELETE RESTRICT,

    CONSTRAINT fk_horario_salon
        FOREIGN KEY (id_salon)
        REFERENCES salones(id_salon)
        ON UPDATE CASCADE ON DELETE RESTRICT,

    CONSTRAINT uq_horario_intervalo_grupo UNIQUE (id_grupo, dia_semana, hora_inicio, hora_fin),

    INDEX ix_horario_salon_dia
        (id_salon, dia_semana, hora_inicio, hora_fin),

    INDEX ix_horario_grupo_dia
        (id_grupo, dia_semana, hora_inicio, hora_fin)
) ENGINE=InnoDB;

-- =========================================================
-- 8. KARDEX Y CALIFICACIONES
-- =========================================================

CREATE TABLE kardex (
    id_kardex INT AUTO_INCREMENT PRIMARY KEY,
    numero_control VARCHAR(20) NOT NULL,
    id_grupo INT NOT NULL,

    periodo VARCHAR(20) NOT NULL,
    anio YEAR NOT NULL,

    calificacion INT NULL,

    tipo_calf ENUM(
        'Ordinario',
        'Recuperacion',
        'No aprobatorio'
    ) NOT NULL DEFAULT 'Ordinario',

    curso ENUM(
        'Ordinario',
        'Repeticion',
        'Especial'
    ) NOT NULL DEFAULT 'Ordinario',

    estado ENUM(
        'Cursando',
        'Aprobada',
        'Reprobada',
        'Baja'
    ) NOT NULL DEFAULT 'Cursando',

    CONSTRAINT uq_kardex_alumno_grupo
        UNIQUE (numero_control, id_grupo),
    CONSTRAINT chk_kardex_periodo CHECK (CHAR_LENGTH(TRIM(periodo)) > 0),
    CONSTRAINT chk_kardex_estado_nota CHECK (
        (estado = 'Cursando' AND calificacion IS NULL)
        OR (estado IN ('Aprobada', 'Reprobada') AND calificacion IS NOT NULL)
        OR estado = 'Baja'
    ),

    CONSTRAINT chk_kardex_calificacion
        CHECK (
            calificacion IS NULL
            OR calificacion BETWEEN 0 AND 100
        ),

    CONSTRAINT fk_kardex_alumno
        FOREIGN KEY (numero_control)
        REFERENCES alumnos(numero_control)
        ON UPDATE CASCADE ON DELETE RESTRICT,

    CONSTRAINT fk_kardex_grupo_ciclo
        FOREIGN KEY (id_grupo, periodo, anio)
        REFERENCES grupos(id_grupo, periodo, anio)
        ON UPDATE RESTRICT ON DELETE RESTRICT
) ENGINE=InnoDB;

-- =========================================================
-- 9. USUARIOS DEL SISTEMA
-- =========================================================

CREATE TABLE usuarios (
    codigo VARCHAR(30) PRIMARY KEY,
    nombre_usuario VARCHAR(50) NOT NULL UNIQUE,

    rol ENUM('Admin','Docente','Alumno') NOT NULL,

    correo VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,

    numero_control VARCHAR(20) NULL UNIQUE,
    id_docente INT NULL UNIQUE,

    estado ENUM('Activo','Inactivo','Bloqueado')
        NOT NULL DEFAULT 'Activo',

    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_usuario_vinculo CHECK (
        (rol = 'Admin' AND numero_control IS NULL AND id_docente IS NULL)
        OR
        (rol = 'Alumno' AND numero_control IS NOT NULL AND id_docente IS NULL)
        OR
        (rol = 'Docente' AND numero_control IS NULL AND id_docente IS NOT NULL)
    ),

    CONSTRAINT fk_usuario_alumno
        FOREIGN KEY (numero_control)
        REFERENCES alumnos(numero_control)
        ON UPDATE CASCADE ON DELETE RESTRICT,

    CONSTRAINT fk_usuario_docente
        FOREIGN KEY (id_docente)
        REFERENCES docentes(id_docente)
        ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- ============================================================================
-- TRIGGERS: REGLAS ENTRE TABLAS E HISTORIAL
-- ============================================================================
DELIMITER $$

-- 1) No permitir requisitos circulares (A -> B -> ... -> A).
CREATE TRIGGER trg_materia_requisito_insert
BEFORE INSERT ON materias
FOR EACH ROW
BEGIN
    IF NEW.id_materia_requisito IS NOT NULL
       AND NEW.id_materia_requisito = NEW.id_materia THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Una materia no puede requerirse a si misma';
    END IF;
END$$

CREATE TRIGGER trg_materia_requisito_update
BEFORE UPDATE ON materias
FOR EACH ROW
BEGIN
    DECLARE v_actual INT DEFAULT NULL;
    DECLARE v_siguiente INT DEFAULT NULL;
    DECLARE v_pasos INT DEFAULT 0;
    DECLARE v_limite INT DEFAULT 0;

    SET v_actual = NEW.id_materia_requisito;
    SELECT COUNT(*) + 1 INTO v_limite FROM materias;

    WHILE v_actual IS NOT NULL DO
        IF v_actual = NEW.id_materia THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El requisito produciria un ciclo entre materias';
        END IF;
        IF v_pasos >= v_limite THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'La cadena de requisitos contiene un ciclo';
        END IF;
        SET v_siguiente = NULL;
        SELECT id_materia_requisito INTO v_siguiente
          FROM materias WHERE id_materia = v_actual;
        SET v_actual = v_siguiente;
        SET v_pasos = v_pasos + 1;
    END WHILE;
END$$

-- 2) Una inscripción por alumno y periodo; la columna generada UNIQUE
--    impide además más de una inscripción 'En curso' del mismo alumno.
CREATE TRIGGER trg_inscripcion_insert
BEFORE INSERT ON inscripciones
FOR EACH ROW
BEGIN
    DECLARE v_alumno VARCHAR(25) DEFAULT NULL;
    DECLARE v_carrera VARCHAR(25) DEFAULT NULL;

    IF NEW.estado = 'En curso' THEN
        SELECT estado INTO v_alumno
          FROM alumnos WHERE numero_control = NEW.numero_control;
        SELECT estado INTO v_carrera
          FROM carreras WHERE id_carrera = NEW.id_carrera;
        IF v_alumno IS NULL OR v_alumno <> 'Activo'
           OR v_carrera IS NULL OR v_carrera <> 'Activa' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'La inscripción activa requiere alumno y carrera activos';
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_inscripcion_update
BEFORE UPDATE ON inscripciones
FOR EACH ROW
BEGIN
    DECLARE v_alumno VARCHAR(25) DEFAULT NULL;
    DECLARE v_carrera VARCHAR(25) DEFAULT NULL;
    IF NEW.numero_control <> OLD.numero_control
       OR NEW.id_carrera <> OLD.id_carrera
       OR NEW.periodo <> OLD.periodo
       OR NEW.anio <> OLD.anio
       OR NEW.fecha_inscripcion <> OLD.fecha_inscripcion THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'No se puede cambiar la identidad histórica de una inscripción';
    END IF;
    IF OLD.estado <> 'En curso' AND NEW.estado = 'En curso' THEN
        SELECT estado INTO v_alumno
          FROM alumnos WHERE numero_control = NEW.numero_control;
        SELECT estado INTO v_carrera
          FROM carreras WHERE id_carrera = NEW.id_carrera;
        IF v_alumno IS NULL OR v_alumno <> 'Activo'
           OR v_carrera IS NULL OR v_carrera <> 'Activa' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'La inscripción activa requiere alumno y carrera activos';
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_inscripcion_no_delete
BEFORE DELETE ON inscripciones
FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se borra el historial: cambie el estado de la inscripción';
END$$

-- 3) Mantener datos de grupos usados en horarios y kardex.
CREATE TRIGGER trg_grupo_update
BEFORE UPDATE ON grupos
FOR EACH ROW
BEGIN
    DECLARE v_inscritos INT DEFAULT 0;

    IF EXISTS (SELECT 1 FROM horarios WHERE id_grupo = OLD.id_grupo)
       OR EXISTS (SELECT 1 FROM kardex WHERE id_grupo = OLD.id_grupo) THEN
        IF NEW.clave_grupo <> OLD.clave_grupo
           OR NEW.id_materia <> OLD.id_materia
           OR NEW.id_docente <> OLD.id_docente
           OR NEW.semestre <> OLD.semestre
           OR NEW.periodo <> OLD.periodo
           OR NEW.anio <> OLD.anio
           OR NEW.modalidad <> OLD.modalidad THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El grupo tiene historial; no cambie sus datos académicos';
        END IF;
    END IF;

    SELECT COUNT(*) INTO v_inscritos FROM kardex
     WHERE id_grupo = OLD.id_grupo AND estado <> 'Baja';
    IF NEW.capacidad < v_inscritos THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'La nueva capacidad es inferior a los alumnos registrados';
    END IF;

    IF NEW.capacidad <> OLD.capacidad AND EXISTS (
        SELECT 1 FROM horarios h JOIN salones s ON s.id_salon = h.id_salon
         WHERE h.id_grupo = OLD.id_grupo AND h.estado = 'Activo'
           AND s.capacidad < NEW.capacidad
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'La nueva capacidad supera la de un salón asignado';
    END IF;

    IF OLD.estado IN ('Cerrado','Cancelado')
       AND NEW.estado IN ('Planeado','Abierto') THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'No se reabren grupos historicos cerrados o cancelados';
    END IF;
END$$

-- 4) No reducir capacidad de un salón por debajo de grupos programados.
CREATE TRIGGER trg_salon_update
BEFORE UPDATE ON salones
FOR EACH ROW
BEGIN
    IF (NEW.id_edificio <> OLD.id_edificio OR NEW.id_area <> OLD.id_area)
       AND EXISTS (SELECT 1 FROM horarios WHERE id_salon = OLD.id_salon) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'El salón tiene historial: no cambie su ubicación';
    END IF;
    IF EXISTS (
        SELECT 1 FROM horarios h
        JOIN grupos g ON g.id_grupo = h.id_grupo
        WHERE h.id_salon = OLD.id_salon
          AND h.estado = 'Activo'
          AND g.estado IN ('Planeado','Abierto')
          AND g.capacidad > NEW.capacidad
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'La capacidad es insuficiente para grupos programados';
    END IF;
END$$

-- 5) Validación de horarios (INSERT/UPDATE): capacidad, modalidad, estados y empalmes por ciclo.
CREATE TRIGGER trg_horario_insert
BEFORE INSERT ON horarios
FOR EACH ROW
BEGIN
    DECLARE v_modalidad VARCHAR(20) DEFAULT NULL;
    DECLARE v_estado_grupo VARCHAR(20) DEFAULT NULL;
    DECLARE v_capacidad_grupo INT DEFAULT NULL;
    DECLARE v_estado_docente VARCHAR(20) DEFAULT NULL;
    DECLARE v_id_docente INT DEFAULT NULL;
    DECLARE v_estado_salon VARCHAR(20) DEFAULT NULL;
    DECLARE v_capacidad_salon INT DEFAULT NULL;
    DECLARE v_estado_edificio VARCHAR(20) DEFAULT NULL;
    DECLARE v_estado_area VARCHAR(20) DEFAULT NULL;
    DECLARE v_periodo VARCHAR(20) DEFAULT NULL;
    DECLARE v_anio INT DEFAULT NULL;

    -- Se bloquean las filas de grupo, docente y salón mientras se valida.
    -- Esto reduce condiciones de carrera en inserciones simultáneas.
    SELECT g.modalidad, g.estado, g.capacidad,
           d.estado, d.id_docente,
           s.estado, s.capacidad, e.estado, a.estado,
           g.periodo, g.anio
      INTO v_modalidad, v_estado_grupo, v_capacidad_grupo,
           v_estado_docente, v_id_docente,
           v_estado_salon, v_capacidad_salon, v_estado_edificio,
           v_estado_area, v_periodo, v_anio
      FROM grupos g
      INNER JOIN docentes d ON d.id_docente = g.id_docente
      INNER JOIN salones s ON s.id_salon = NEW.id_salon
      INNER JOIN edificios e ON e.id_edificio = s.id_edificio
      INNER JOIN areas a ON a.id_area = s.id_area
                         AND a.id_edificio = s.id_edificio
     WHERE g.id_grupo = NEW.id_grupo
     FOR UPDATE;

    IF v_periodo IS NULL OR v_estado_salon IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Grupo o salón no disponible';
    END IF;

    -- El historial cancelado puede conservarse sin ocupar salón.
    IF NEW.estado = 'Activo' THEN
        IF v_estado_grupo NOT IN ('Planeado','Abierto') THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El grupo está cerrado o cancelado';
        END IF;
        IF (NEW.dia_semana = 'Sabado' AND v_modalidad <> 'Sabado')
           OR (NEW.dia_semana <> 'Sabado' AND v_modalidad <> 'Entre semana') THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El día no corresponde a la modalidad del grupo';
        END IF;
        IF v_estado_docente <> 'Activo' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El docente asignado está inactivo';
        END IF;
        IF v_estado_salon <> 'Activo' OR v_estado_edificio <> 'Activo'
           OR v_estado_area <> 'Activo' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El salón, área o edificio está inactivo';
        END IF;
        IF v_capacidad_salon < v_capacidad_grupo THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Capacidad de salón insuficiente';
        END IF;

        -- Empalmes de salón únicamente en el MISMO periodo y año.
        IF EXISTS (
            SELECT 1 FROM horarios h
            INNER JOIN grupos g2 ON g2.id_grupo = h.id_grupo
            WHERE h.id_salon = NEW.id_salon
              AND h.dia_semana = NEW.dia_semana
              AND h.estado = 'Activo'
              AND g2.estado IN ('Planeado','Abierto')
              AND g2.periodo = v_periodo AND g2.anio = v_anio
              AND NEW.hora_inicio < h.hora_fin
              AND NEW.hora_fin > h.hora_inicio
              
        ) THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El salón está ocupado en ese horario y ciclo';
        END IF;

        -- Empalmes del docente en grupos distintos de un mismo ciclo.
        IF EXISTS (
            SELECT 1 FROM horarios h
            INNER JOIN grupos g2 ON g2.id_grupo = h.id_grupo
            WHERE g2.id_docente = v_id_docente
              AND h.dia_semana = NEW.dia_semana
              AND h.estado = 'Activo'
              AND g2.estado IN ('Planeado','Abierto')
              AND g2.periodo = v_periodo AND g2.anio = v_anio
              AND NEW.hora_inicio < h.hora_fin
              AND NEW.hora_fin > h.hora_inicio
              
        ) THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El docente está ocupado en ese horario y ciclo';
        END IF;

        -- No solapamiento de bloques del mismo grupo.
        IF EXISTS (
            SELECT 1 FROM horarios h
            WHERE h.id_grupo = NEW.id_grupo
              AND h.dia_semana = NEW.dia_semana
              AND h.estado = 'Activo'
              AND NEW.hora_inicio < h.hora_fin
              AND NEW.hora_fin > h.hora_inicio
              
        ) THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El grupo ya tiene clase en ese intervalo';
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_horario_update
BEFORE UPDATE ON horarios
FOR EACH ROW
BEGIN
    DECLARE v_modalidad VARCHAR(20) DEFAULT NULL;
    DECLARE v_estado_grupo VARCHAR(20) DEFAULT NULL;
    DECLARE v_capacidad_grupo INT DEFAULT NULL;
    DECLARE v_estado_docente VARCHAR(20) DEFAULT NULL;
    DECLARE v_id_docente INT DEFAULT NULL;
    DECLARE v_estado_salon VARCHAR(20) DEFAULT NULL;
    DECLARE v_capacidad_salon INT DEFAULT NULL;
    DECLARE v_estado_edificio VARCHAR(20) DEFAULT NULL;
    DECLARE v_estado_area VARCHAR(20) DEFAULT NULL;
    DECLARE v_periodo VARCHAR(20) DEFAULT NULL;
    DECLARE v_anio INT DEFAULT NULL;

    -- Se bloquean las filas de grupo, docente y salón mientras se valida.
    -- Esto reduce condiciones de carrera en inserciones simultáneas.
    SELECT g.modalidad, g.estado, g.capacidad,
           d.estado, d.id_docente,
           s.estado, s.capacidad, e.estado, a.estado,
           g.periodo, g.anio
      INTO v_modalidad, v_estado_grupo, v_capacidad_grupo,
           v_estado_docente, v_id_docente,
           v_estado_salon, v_capacidad_salon, v_estado_edificio,
           v_estado_area, v_periodo, v_anio
      FROM grupos g
      INNER JOIN docentes d ON d.id_docente = g.id_docente
      INNER JOIN salones s ON s.id_salon = NEW.id_salon
      INNER JOIN edificios e ON e.id_edificio = s.id_edificio
      INNER JOIN areas a ON a.id_area = s.id_area
                         AND a.id_edificio = s.id_edificio
     WHERE g.id_grupo = NEW.id_grupo
     FOR UPDATE;

    IF v_periodo IS NULL OR v_estado_salon IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Grupo o salón no disponible';
    END IF;

    -- El historial cancelado puede conservarse sin ocupar salón.
    IF NEW.estado = 'Activo' THEN
        IF v_estado_grupo NOT IN ('Planeado','Abierto') THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El grupo está cerrado o cancelado';
        END IF;
        IF (NEW.dia_semana = 'Sabado' AND v_modalidad <> 'Sabado')
           OR (NEW.dia_semana <> 'Sabado' AND v_modalidad <> 'Entre semana') THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El día no corresponde a la modalidad del grupo';
        END IF;
        IF v_estado_docente <> 'Activo' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El docente asignado está inactivo';
        END IF;
        IF v_estado_salon <> 'Activo' OR v_estado_edificio <> 'Activo'
           OR v_estado_area <> 'Activo' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El salón, área o edificio está inactivo';
        END IF;
        IF v_capacidad_salon < v_capacidad_grupo THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Capacidad de salón insuficiente';
        END IF;

        -- Empalmes de salón únicamente en el MISMO periodo y año.
        IF EXISTS (
            SELECT 1 FROM horarios h
            INNER JOIN grupos g2 ON g2.id_grupo = h.id_grupo
            WHERE h.id_salon = NEW.id_salon
              AND h.dia_semana = NEW.dia_semana
              AND h.estado = 'Activo'
              AND g2.estado IN ('Planeado','Abierto')
              AND g2.periodo = v_periodo AND g2.anio = v_anio
              AND NEW.hora_inicio < h.hora_fin
              AND NEW.hora_fin > h.hora_inicio
              AND h.id_horario <> OLD.id_horario
        ) THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El salón está ocupado en ese horario y ciclo';
        END IF;

        -- Empalmes del docente en grupos distintos de un mismo ciclo.
        IF EXISTS (
            SELECT 1 FROM horarios h
            INNER JOIN grupos g2 ON g2.id_grupo = h.id_grupo
            WHERE g2.id_docente = v_id_docente
              AND h.dia_semana = NEW.dia_semana
              AND h.estado = 'Activo'
              AND g2.estado IN ('Planeado','Abierto')
              AND g2.periodo = v_periodo AND g2.anio = v_anio
              AND NEW.hora_inicio < h.hora_fin
              AND NEW.hora_fin > h.hora_inicio
              AND h.id_horario <> OLD.id_horario
        ) THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El docente está ocupado en ese horario y ciclo';
        END IF;

        -- No solapamiento de bloques del mismo grupo.
        IF EXISTS (
            SELECT 1 FROM horarios h
            WHERE h.id_grupo = NEW.id_grupo
              AND h.dia_semana = NEW.dia_semana
              AND h.estado = 'Activo'
              AND NEW.hora_inicio < h.hora_fin
              AND NEW.hora_fin > h.hora_inicio
              AND h.id_horario <> OLD.id_horario
        ) THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El grupo ya tiene clase en ese intervalo';
        END IF;
    END IF;
END$$

-- 6) Kardex: la combinación alumno/grupo es única; se valida capacidad
--    en altas, y se inmovilizan los identificadores históricos al editar.
CREATE TRIGGER trg_kardex_insert
BEFORE INSERT ON kardex
FOR EACH ROW
BEGIN
    DECLARE v_materia INT DEFAULT NULL;
    DECLARE v_capacidad INT DEFAULT NULL;
    DECLARE v_grupo_estado VARCHAR(20) DEFAULT NULL;
    DECLARE v_alumno_estado VARCHAR(25) DEFAULT NULL;
    DECLARE v_materia_estado VARCHAR(20) DEFAULT NULL;
    DECLARE v_inscripcion INT DEFAULT 0;
    DECLARE v_ocupados INT DEFAULT 0;

    -- Siempre se comprueba la equivalencia de ciclo con la clave foránea
    -- compuesta; la inscripción se compara con el mismo periodo del grupo.
    SELECT g.id_materia, g.capacidad, g.estado, a.estado,
           m.estado
      INTO v_materia, v_capacidad, v_grupo_estado,
           v_alumno_estado, v_materia_estado
      FROM grupos g
      JOIN materias m ON m.id_materia = g.id_materia
      JOIN alumnos a ON a.numero_control = NEW.numero_control
     WHERE g.id_grupo = NEW.id_grupo
     FOR UPDATE;

    IF v_materia IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Grupo, materia o alumno no encontrados';
    END IF;

    IF NEW.estado <> 'Baja' THEN
        IF v_grupo_estado <> 'Abierto' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El grupo no está abierto para registrar alumnos';
        END IF;
        IF v_alumno_estado <> 'Activo' OR v_materia_estado <> 'Activa' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El alumno o la materia no se encuentran activos';
        END IF;

        SELECT COUNT(*) INTO v_inscripcion
          FROM inscripciones i
          WHERE i.numero_control = NEW.numero_control
            AND i.periodo = NEW.periodo
            AND i.anio = NEW.anio
            AND i.estado = 'En curso';
        IF v_inscripcion = 0 THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El alumno no tiene inscripción activa para este ciclo';
        END IF;

        SELECT COUNT(*) INTO v_ocupados
          FROM kardex k WHERE k.id_grupo = NEW.id_grupo
            AND k.estado <> 'Baja'
            ;
        IF v_ocupados >= v_capacidad THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Capacidad del grupo agotada';
        END IF;

        -- Un alumno no puede cursar la misma materia dos veces en el
        -- mismo periodo en secciones distintas; Baja permite corrección.
        IF EXISTS (
            SELECT 1 FROM kardex k
            JOIN grupos g2 ON g2.id_grupo = k.id_grupo
            WHERE k.numero_control = NEW.numero_control
              AND k.periodo = NEW.periodo
              AND k.anio = NEW.anio
              AND g2.id_materia = v_materia
              AND k.estado <> 'Baja'
              
        ) THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'El alumno ya cursa esta materia en el mismo ciclo';
        END IF;
    END IF;
END$$

CREATE TRIGGER trg_kardex_update
BEFORE UPDATE ON kardex
FOR EACH ROW
BEGIN
    DECLARE v_capacidad INT DEFAULT NULL;
    DECLARE v_grupo_estado VARCHAR(20) DEFAULT NULL;
    DECLARE v_ocupados INT DEFAULT 0;

    IF NEW.numero_control <> OLD.numero_control
       OR NEW.id_grupo <> OLD.id_grupo
       OR NEW.periodo <> OLD.periodo
       OR NEW.anio <> OLD.anio THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'No se puede cambiar la identidad histórica del kardex';
    END IF;
    IF OLD.estado = 'Baja' AND NEW.estado <> 'Baja' THEN
        SELECT capacidad, estado INTO v_capacidad, v_grupo_estado
          FROM grupos WHERE id_grupo = NEW.id_grupo FOR UPDATE;
        IF v_grupo_estado <> 'Abierto' THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'No se puede reactivar un registro de un grupo cerrado';
        END IF;
        SELECT COUNT(*) INTO v_ocupados
          FROM kardex WHERE id_grupo = NEW.id_grupo AND estado <> 'Baja'
            AND id_kardex <> OLD.id_kardex;
        IF v_ocupados >= v_capacidad THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'No hay capacidad para reactivar esta inscripción al grupo';
        END IF;
    END IF;
END$$

-- 7) Historial no destructivo: cancelar/baja/finalizar en vez de DELETE.
CREATE TRIGGER trg_kardex_no_delete
BEFORE DELETE ON kardex
FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se puede borrar el historial de calificaciones';
END$$

CREATE TRIGGER trg_horario_no_delete
BEFORE DELETE ON horarios
FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se borra el historial: cancele el horario';
END$$

CREATE TRIGGER trg_contrato_no_delete
BEFORE DELETE ON contratos
FOR EACH ROW
BEGIN
    SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'No se borra el historial contractual: cambie el status';
END$$

DELIMITER ;

-- ============================================================================
-- VISTAS (son las 3 originales, ampliadas con identificadores del ciclo)
-- ============================================================================

CREATE OR REPLACE VIEW vw_horario_grupo AS
SELECT
    h.id_horario,
    g.id_grupo,
    g.clave_grupo,
    g.semestre,
    g.modalidad,
    m.clave_materia,
    m.nombre AS materia,
    m.creditos,
    CONCAT_WS(' ', d.nombre, d.seg_nombre, d.apellidos) AS docente,
    s.id_salon,
    s.nombre AS salon,
    s.tipo AS tipo_salon,
    e.nombre AS edificio,
    a.nombre AS area,
    h.dia_semana,
    h.hora_inicio,
    h.hora_fin,
    g.estado AS estado_grupo,
    g.periodo AS periodo,
    g.anio AS anio,
    h.estado AS estado_horario
FROM horarios h
INNER JOIN grupos g
    ON h.id_grupo = g.id_grupo
INNER JOIN materias m
    ON g.id_materia = m.id_materia
INNER JOIN docentes d
    ON g.id_docente = d.id_docente
INNER JOIN salones s
    ON h.id_salon = s.id_salon
INNER JOIN edificios e
    ON s.id_edificio = e.id_edificio
INNER JOIN areas a
    ON s.id_area = a.id_area;

CREATE OR REPLACE VIEW vw_kardex_alumno AS
SELECT
    k.id_kardex,
    al.numero_control,
    CONCAT_WS(
        ' ',
        al.nombre,
        al.seg_nombre,
        al.apellidos
    ) AS alumno,
    m.clave_materia,
    m.nombre AS materia,
    m.creditos,
    g.clave_grupo,
    CONCAT_WS(
        ' ',
        d.nombre,
        d.seg_nombre,
        d.apellidos
    ) AS docente,
    k.periodo,
    k.calificacion,
    k.anio,
    k.tipo_calf,
    k.curso,
    k.estado AS estado_kardex,
    g.id_grupo,
    g.id_materia
FROM kardex k
INNER JOIN alumnos al
    ON k.numero_control = al.numero_control
INNER JOIN grupos g
    ON k.id_grupo = g.id_grupo
INNER JOIN materias m
    ON g.id_materia = m.id_materia
INNER JOIN docentes d
    ON g.id_docente = d.id_docente;

CREATE OR REPLACE VIEW vw_alumnos_inscritos AS
SELECT
    i.id_inscripciones,
    a.numero_control,
    CONCAT_WS(
        ' ',
        a.nombre,
        a.seg_nombre,
        a.apellidos
    ) AS alumno,
    a.semestre,
    c.id_carrera,
    c.nombre AS carrera,
    c.tipo AS tipo_carrera,
    i.fecha_inscripcion,
    i.estado AS estado_inscripcion,
    a.estado AS estado_alumno,
    i.periodo,
    i.anio
FROM inscripciones i
INNER JOIN alumnos a
    ON i.numero_control = a.numero_control
INNER JOIN carreras c
    ON i.id_carrera = c.id_carrera;

-- ============================================================================
-- PROCEDIMIENTO ORIGINAL: EL CONTROL DE NEGOCIO SE EJECUTA EN LOS TRIGGERS.
-- Se mantienen los 5 parámetros de sp_registrar_horario.
-- ============================================================================
DELIMITER $$
CREATE PROCEDURE sp_registrar_horario(
    IN p_id_grupo INT,
    IN p_id_salon INT,
    IN p_dia_semana VARCHAR(15),
    IN p_hora_inicio TIME,
    IN p_hora_fin TIME
)
BEGIN
    DECLARE v_id_horario INT DEFAULT NULL;
    DECLARE v_id_docente INT DEFAULT NULL;
    DECLARE v_docente_bloqueado INT DEFAULT NULL;
    DECLARE v_docente_confirmado INT DEFAULT NULL;
    DECLARE v_salon_bloqueado INT DEFAULT NULL;

    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    START TRANSACTION;

    -- Lectura inicial para conocer el docente. El disparador volverá a
    -- validar de forma transaccional los datos en el momento del INSERT.
    SELECT id_docente INTO v_id_docente
      FROM grupos WHERE id_grupo = p_id_grupo;
    IF v_id_docente IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Grupo inexistente';
    END IF;

    SELECT id_docente INTO v_docente_bloqueado
      FROM docentes WHERE id_docente = v_id_docente FOR UPDATE;
    SELECT id_docente INTO v_docente_confirmado
      FROM grupos WHERE id_grupo = p_id_grupo FOR UPDATE;
    IF v_docente_confirmado <> v_id_docente THEN
        SIGNAL SQLSTATE '45000'
          SET MESSAGE_TEXT = 'El docente del grupo cambió; vuelva a intentar';
    END IF;
    SELECT id_salon INTO v_salon_bloqueado
      FROM salones WHERE id_salon = p_id_salon FOR UPDATE;
    IF v_salon_bloqueado IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Salón inexistente';
    END IF;

    INSERT INTO horarios (id_grupo, id_salon, dia_semana, hora_inicio, hora_fin)
    VALUES (p_id_grupo, p_id_salon, p_dia_semana, p_hora_inicio, p_hora_fin);

    SET v_id_horario = LAST_INSERT_ID();
    COMMIT;
    SELECT 'Horario registrado correctamente' AS mensaje, v_id_horario AS id_horario;
END$$
DELIMITER ;

-- FIN DEL SCRIPT DE INSTALACIÓN INICIAL AURORA.
