/**
 * AURORA INTERACTIVE ERD VIEWER (Modelo Simplificado y Optimizado)
 * Renderizado dinámico, zoom, paneo, navegación y conexiones Pata de Gallo (Crow's Foot)
 * Paleta oficial: Violet Night & Golden Amber
 */

(function () {
  const tables = [
  {
    "id": "T_EDIFICIOS",
    "name": "edificios",
    "module": "Infraestructura",
    "tone": "purple",
    "x": 60,
    "y": 60,
    "width": 280,
    "height": 138,
    "columns": [
      {
        "name": "id_edificio",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "clave_edificio",
        "type": "VARCHAR(10)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "nombre",
        "type": "VARCHAR(80)",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_AREAS",
    "name": "areas",
    "module": "Infraestructura",
    "tone": "purple",
    "x": 60,
    "y": 240,
    "width": 280,
    "height": 164,
    "columns": [
      {
        "name": "id_area",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "clave_area",
        "type": "VARCHAR(15)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "nombre",
        "type": "VARCHAR(120)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_edificio",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_SALONES",
    "name": "salones",
    "module": "Infraestructura",
    "tone": "purple",
    "x": 60,
    "y": 440,
    "width": 280,
    "height": 242,
    "columns": [
      {
        "name": "id_salon",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "clave_salon",
        "type": "VARCHAR(15)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "nombre",
        "type": "VARCHAR(80)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "tipo",
        "type": "ENUM('Aula', 'Laboratorio', 'Taller', 'Auditorio')",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "capacidad",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_edificio",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_area",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_DOCENTES",
    "name": "docentes",
    "module": "Docentes",
    "tone": "purple",
    "x": 390,
    "y": 60,
    "width": 280,
    "height": 268,
    "columns": [
      {
        "name": "id_docente",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "codigo",
        "type": "VARCHAR(20)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "cedula",
        "type": "VARCHAR(20)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "nombre",
        "type": "VARCHAR(60)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "seg_nombre",
        "type": "VARCHAR(60)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "apellidos",
        "type": "VARCHAR(100)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "titulo_academico",
        "type": "VARCHAR(100)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "estado",
        "type": "VARCHAR(20)",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_DETALLE_DOCENTES",
    "name": "detalle_docentes",
    "module": "Docentes",
    "tone": "purple",
    "x": 390,
    "y": 360,
    "width": 280,
    "height": 450,
    "columns": [
      {
        "name": "id_docente",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "curp",
        "type": "VARCHAR(18)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "rfc",
        "type": "VARCHAR(13)",
        "pk": false,
        "null": true,
        "uniq": true
      },
      {
        "name": "fecha_nacimiento",
        "type": "DATE",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "telefono",
        "type": "VARCHAR(15)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "email",
        "type": "VARCHAR(100)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "calle",
        "type": "VARCHAR(100)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "numero_exterior",
        "type": "VARCHAR(10)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "numero_interior",
        "type": "VARCHAR(10)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "colonia",
        "type": "VARCHAR(80)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "codigo_postal",
        "type": "CHAR(5)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "municipio",
        "type": "VARCHAR(80)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "estado",
        "type": "VARCHAR(50)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "referencias",
        "type": "VARCHAR(150)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "fecha_ingreso",
        "type": "DATE",
        "pk": false,
        "null": true,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_CONTRATOS",
    "name": "contratos",
    "module": "Docentes",
    "tone": "purple",
    "x": 390,
    "y": 800,
    "width": 280,
    "height": 294,
    "columns": [
      {
        "name": "id_contrato",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "id_docente",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_area",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "folio_contrato",
        "type": "VARCHAR(30)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "horas",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "rol",
        "type": "ENUM('Docente', 'Profesor_honorario', 'Jefe_base')",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "status",
        "type": "ENUM('Activo', 'Inactivo', 'Vencido')",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "fecha_inicio",
        "type": "DATE",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "fecha_fin",
        "type": "DATE",
        "pk": false,
        "null": true,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_CARRERAS",
    "name": "carreras",
    "module": "Academico",
    "tone": "purple",
    "x": 720,
    "y": 60,
    "width": 280,
    "height": 190,
    "columns": [
      {
        "name": "id_carrera",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "clave_carrera",
        "type": "VARCHAR(20)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "nombre",
        "type": "VARCHAR(120)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "nivel",
        "type": "VARCHAR(30)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "total_creditos",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_RETICULAS",
    "name": "reticulas",
    "module": "Academico",
    "tone": "purple",
    "x": 720,
    "y": 280,
    "width": 280,
    "height": 164,
    "columns": [
      {
        "name": "id_reticula",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "clave_reticula",
        "type": "VARCHAR(25)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "anio",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_carrera",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_MATERIAS",
    "name": "materias",
    "module": "Academico",
    "tone": "purple",
    "x": 720,
    "y": 660,
    "width": 280,
    "height": 242,
    "columns": [
      {
        "name": "id_materia",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "clave_materia",
        "type": "VARCHAR(15)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "nombre",
        "type": "VARCHAR(150)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "creditos",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "horas_teoricas",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "horas_practicas",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_materia_requisito",
        "type": "INT",
        "pk": false,
        "null": true,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_RETICULA_MATERIA",
    "name": "reticula_materia",
    "module": "Academico",
    "tone": "purple",
    "x": 720,
    "y": 480,
    "width": 280,
    "height": 138,
    "columns": [
      {
        "name": "id_reticula",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "id_materia",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "semestre",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_ALUMNOS",
    "name": "alumnos",
    "module": "Alumnos",
    "tone": "amber",
    "x": 1050,
    "y": 60,
    "width": 280,
    "height": 190,
    "columns": [
      {
        "name": "numero_control",
        "type": "VARCHAR(20)",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "nombre",
        "type": "VARCHAR(60)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "seg_nombre",
        "type": "VARCHAR(60)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "apellidos",
        "type": "VARCHAR(100)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "semestre",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_DETALLE_ALUMNO",
    "name": "detalle_alumno",
    "module": "Alumnos",
    "tone": "amber",
    "x": 1050,
    "y": 280,
    "width": 280,
    "height": 476,
    "columns": [
      {
        "name": "numero_control",
        "type": "VARCHAR(20)",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "curp",
        "type": "VARCHAR(18)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "fecha_nacimiento",
        "type": "DATE",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "telefono",
        "type": "VARCHAR(15)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "email",
        "type": "VARCHAR(100)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "calle",
        "type": "VARCHAR(100)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "numero_exterior",
        "type": "VARCHAR(10)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "numero_interior",
        "type": "VARCHAR(10)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "colonia",
        "type": "VARCHAR(80)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "codigo_postal",
        "type": "CHAR(5)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "municipio",
        "type": "VARCHAR(80)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "estado",
        "type": "VARCHAR(50)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "referencias",
        "type": "VARCHAR(150)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "datos_contacto",
        "type": "VARCHAR(255)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "situacion_academica",
        "type": "VARCHAR(30)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "fecha_ingreso",
        "type": "DATE",
        "pk": false,
        "null": true,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_INSCRIPCIONES",
    "name": "inscripciones",
    "module": "Alumnos",
    "tone": "amber",
    "x": 1050,
    "y": 740,
    "width": 280,
    "height": 190,
    "columns": [
      {
        "name": "numero_control",
        "type": "VARCHAR(20)",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "id_carrera",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "fecha_inscripcion",
        "type": "DATE",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "periodo",
        "type": "VARCHAR(20)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "estado",
        "type": "ENUM('Finalizada', 'En curso')",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_KARDEX",
    "name": "kardex",
    "module": "Kardex",
    "tone": "amber",
    "x": 1380,
    "y": 60,
    "width": 280,
    "height": 294,
    "columns": [
      {
        "name": "id_kardex",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "numero_control",
        "type": "VARCHAR(20)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_materia",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_salon",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_docente",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "calificacion",
        "type": "DECIMAL(5,2)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "periodo",
        "type": "VARCHAR(20)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "anio",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "tipo_calf",
        "type": "ENUM('Ordinario', 'Recuperacion', 'No aprobatorio')",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_GRUPOS",
    "name": "grupos",
    "module": "Kardex",
    "tone": "amber",
    "x": 1380,
    "y": 380,
    "width": 280,
    "height": 216,
    "columns": [
      {
        "name": "id_grupo",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "clave_grupo",
        "type": "VARCHAR(15)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "capacidad",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_kardex",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "turno",
        "type": "VARCHAR(20)",
        "pk": false,
        "null": true,
        "uniq": false
      },
      {
        "name": "semestre",
        "type": "INT",
        "pk": false,
        "null": true,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_HORARIOS",
    "name": "horarios",
    "module": "Kardex",
    "tone": "amber",
    "x": 1380,
    "y": 620,
    "width": 280,
    "height": 216,
    "columns": [
      {
        "name": "id_horario",
        "type": "INT",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "id_grupo",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "id_salon",
        "type": "INT",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "dia_semana",
        "type": "VARCHAR(15)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "hora_inicio",
        "type": "TIME",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "hora_fin",
        "type": "TIME",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  },
  {
    "id": "T_USUARIOS",
    "name": "usuarios",
    "module": "Seguridad",
    "tone": "purple",
    "x": 1380,
    "y": 860,
    "width": 280,
    "height": 216,
    "columns": [
      {
        "name": "codigo",
        "type": "VARCHAR(30)",
        "pk": true,
        "null": false,
        "uniq": true
      },
      {
        "name": "nombre_usuario",
        "type": "VARCHAR(50)",
        "pk": false,
        "null": false,
        "uniq": true
      },
      {
        "name": "rol",
        "type": "ENUM('Admin', 'Docente', 'Alumno')",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "correo",
        "type": "VARCHAR(100)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "password",
        "type": "VARCHAR(255)",
        "pk": false,
        "null": false,
        "uniq": false
      },
      {
        "name": "estado",
        "type": "VARCHAR(20)",
        "pk": false,
        "null": false,
        "uniq": false
      }
    ]
  }
];

  const references = [
  {
    "from": "T_DOCENTES",
    "to": "T_DETALLE_DOCENTES",
    "from_col": "id_docente",
    "to_col": "id_docente",
    "card": "1 a 1",
    "tone": "purple",
    "color": "#7a5498"
  },
  {
    "from": "T_DOCENTES",
    "to": "T_CONTRATOS",
    "from_col": "id_docente",
    "to_col": "id_docente",
    "card": "1 a N",
    "tone": "purple",
    "color": "#7a5498"
  },
  {
    "from": "T_AREAS",
    "to": "T_CONTRATOS",
    "from_col": "id_area",
    "to_col": "id_area",
    "card": "1 a N",
    "tone": "purple",
    "color": "#7a5498"
  },
  {
    "from": "T_DOCENTES",
    "to": "T_KARDEX",
    "from_col": "id_docente",
    "to_col": "id_docente",
    "card": "1 a N",
    "tone": "purple",
    "color": "#7a5498"
  },
  {
    "from": "T_EDIFICIOS",
    "to": "T_AREAS",
    "from_col": "id_edificio",
    "to_col": "id_edificio",
    "card": "1 a N",
    "tone": "purple",
    "color": "#4d2f70"
  },
  {
    "from": "T_EDIFICIOS",
    "to": "T_SALONES",
    "from_col": "id_edificio",
    "to_col": "id_edificio",
    "card": "1 a N",
    "tone": "purple",
    "color": "#4d2f70"
  },
  {
    "from": "T_AREAS",
    "to": "T_SALONES",
    "from_col": "id_area",
    "to_col": "id_area",
    "card": "1 a N",
    "tone": "purple",
    "color": "#4d2f70"
  },
  {
    "from": "T_SALONES",
    "to": "T_KARDEX",
    "from_col": "id_salon",
    "to_col": "id_salon",
    "card": "1 a N",
    "tone": "purple",
    "color": "#7a5498"
  },
  {
    "from": "T_SALONES",
    "to": "T_HORARIOS",
    "from_col": "id_salon",
    "to_col": "id_salon",
    "card": "1 a N",
    "tone": "purple",
    "color": "#7a5498"
  },
  {
    "from": "T_CARRERAS",
    "to": "T_RETICULAS",
    "from_col": "id_carrera",
    "to_col": "id_carrera",
    "card": "1 a N",
    "tone": "purple",
    "color": "#804a8a"
  },
  {
    "from": "T_CARRERAS",
    "to": "T_INSCRIPCIONES",
    "from_col": "id_carrera",
    "to_col": "id_carrera",
    "card": "1 a N",
    "tone": "purple",
    "color": "#804a8a"
  },
  {
    "from": "T_ALUMNOS",
    "to": "T_INSCRIPCIONES",
    "from_col": "matricula",
    "to_col": "matricula",
    "card": "1 a N",
    "tone": "amber",
    "color": "#c88b00"
  },
  {
    "from": "T_ALUMNOS",
    "to": "T_DETALLE_ALUMNO",
    "from_col": "matricula",
    "to_col": "matricula",
    "card": "1 a 1",
    "tone": "amber",
    "color": "#f59e51"
  },
  {
    "from": "T_ALUMNOS",
    "to": "T_KARDEX",
    "from_col": "matricula",
    "to_col": "matricula",
    "card": "1 a N",
    "tone": "amber",
    "color": "#c88b00"
  },
  {
    "from": "T_RETICULAS",
    "to": "T_RETICULA_MATERIA",
    "from_col": "id_reticula",
    "to_col": "id_reticula",
    "card": "1 a N",
    "tone": "purple",
    "color": "#804a8a"
  },
  {
    "from": "T_MATERIAS",
    "to": "T_RETICULA_MATERIA",
    "from_col": "id_materia",
    "to_col": "id_materia",
    "card": "1 a N",
    "tone": "purple",
    "color": "#804a8a"
  },
  {
    "from": "T_MATERIAS",
    "to": "T_KARDEX",
    "from_col": "id_materia",
    "to_col": "id_materia",
    "card": "1 a N",
    "tone": "purple",
    "color": "#804a8a"
  },
  {
    "from": "T_MATERIAS",
    "to": "T_MATERIAS",
    "from_col": "id_materia",
    "to_col": "id_materia_requisito",
    "card": "1 a N",
    "tone": "purple",
    "color": "#804a8a"
  },
  {
    "from": "T_KARDEX",
    "to": "T_GRUPOS",
    "from_col": "id_kardex",
    "to_col": "id_kardex",
    "card": "1 a N",
    "tone": "amber",
    "color": "#f59e51"
  },
  {
    "from": "T_GRUPOS",
    "to": "T_HORARIOS",
    "from_col": "id_grupo",
    "to_col": "id_grupo",
    "card": "1 a N",
    "tone": "amber",
    "color": "#f59e51"
  }
];

  let scale = 0.75;
  let panX = 40;
  let panY = 20;
  let isPanning = false;
  let startX = 0;
  let startY = 0;
  let hasMoved = false;

  const viewport = document.getElementById('viewport');
  const container = document.getElementById('canvas-container');
  const tablesLayer = document.getElementById('tables-layer');
  const linesGroup = document.getElementById('svg-lines-group');
  const detailPanel = document.getElementById('detail-panel');

  function updateTransform() {
    viewport.style.transform = `translate(${panX}px, ${panY}px) scale(${scale})`;
  }

  // Renderiza las 17 tablas en el DOM con identificadores de fila para conexiones exactas
  function renderTables() {
    tablesLayer.innerHTML = '';
    tables.forEach(t => {
      const el = document.createElement('div');
      el.className = 'table-card';
      el.id = 'table-' + t.id;
      el.style.left = t.x + 'px';
      el.style.top = t.y + 'px';
      el.style.width = t.width + 'px';

      if (t.tone === 'amber') {
        el.style.borderColor = '#c88b00';
      } else {
        el.style.borderColor = '#4d2f70';
      }

      let colsHtml = '';
      t.columns.forEach(c => {
        const pkIcon = c.pk 
          ? '<span class="col-icon-pk" title="Primary Key (Llave Primaria)">🔑</span>' 
          : (c.name.startsWith('id_') || c.name.startsWith('fk_') || c.name === 'matricula' && !c.pk ? '<span class="col-icon-fk" title="Foreign Key (Llave Foránea)">🔗</span>' : '');
        const uniqIcon = c.uniq && !c.pk 
          ? '<span class="col-icon-uniq" title="Campo Único (Unique)">★</span>' 
          : '';

        colsHtml += `
          <div class="col-row" id="row-${t.id}-${c.name}" data-table="${t.id}" data-col="${c.name}">
            <span class="col-name">${pkIcon}${uniqIcon}${c.name}</span>
            <span class="col-type">${c.type}</span>
          </div>
        `;
      });

      const badgeColor = t.tone === 'amber' ? 'color:#f8d299;' : 'color:#b8a5cf;';
      el.innerHTML = `
        <div class="table-header header-${t.module}">
          <span>${t.name}</span>
          <span style="font-size:9.5px;font-weight:normal;${badgeColor}text-transform:uppercase;letter-spacing:0.5px;">${t.module}</span>
        </div>
        <div>${colsHtml}</div>
      `;

      // Interacciones de hover y selección
      el.addEventListener('mouseenter', () => highlightTable(t.id));
      el.addEventListener('mouseleave', () => resetHighlight());
      
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        selectAndShowTable(t);
      });

      tablesLayer.appendChild(el);
    });
  }

  // Traza las líneas de relación exactamente de la fila PK a la fila FK con Pata de Gallo (Crow's Foot)
  function renderReferences() {
    linesGroup.innerHTML = '';
    const tableMap = Object.fromEntries(tables.map(t => [t.id, t]));

    references.forEach((ref, refIdx) => {
      const t1 = tableMap[ref.from];
      const t2 = tableMap[ref.to];
      if (!t1 || !t2) return;

      const fromRow = document.getElementById(`row-${ref.from}-${ref.from_col}`);
      const toRow = document.getElementById(`row-${ref.to}-${ref.to_col}`);

      let startY = t1.y + 40;
      if (fromRow) {
        startY = t1.y + fromRow.offsetTop + (fromRow.offsetHeight / 2);
      } else {
        const idx1 = t1.columns.findIndex(c => c.name === ref.from_col);
        startY = t1.y + 32 + (idx1 >= 0 ? idx1 : 0) * 23.5 + 11.5;
      }

      let endY = t2.y + 40;
      if (toRow) {
        endY = t2.y + toRow.offsetTop + (toRow.offsetHeight / 2);
      } else {
        const idx2 = t2.columns.findIndex(c => c.name === ref.to_col);
        endY = t2.y + 32 + (idx2 >= 0 ? idx2 : 0) * 23.5 + 11.5;
      }

      let startX, endX, pathData;

      if (ref.from === ref.to) {
        // Recursividad (Materias -> Materias)
        startX = t1.x + t1.width;
        endX = t1.x + t1.width;
        const loopW = 38;
        pathData = `M ${startX} ${startY} C ${startX + loopW} ${startY}, ${endX + loopW} ${endY}, ${endX} ${endY}`;
      } else if (t1.x === t2.x) {
        // Mismo eje de columna
        startX = t1.x + t1.width;
        endX = t2.x + t2.width;
        const arcOffset = 36 + ((refIdx % 4) * 14);
        pathData = `M ${startX} ${startY} C ${startX + arcOffset} ${startY}, ${endX + arcOffset} ${endY}, ${endX} ${endY}`;
      } else if (t2.x > t1.x) {
        // La tabla foránea está a la derecha
        startX = t1.x + t1.width;
        endX = t2.x;
        const delta = Math.max(35, Math.abs(endX - startX) * 0.44);
        pathData = `M ${startX} ${startY} C ${startX + delta} ${startY}, ${endX - delta} ${endY}, ${endX} ${endY}`;
      } else {
        // La tabla foránea está a la izquierda
        startX = t1.x;
        endX = t2.x + t2.width;
        const delta = Math.max(35, Math.abs(startX - endX) * 0.44);
        pathData = `M ${startX} ${startY} C ${startX - delta} ${startY}, ${endX + delta} ${endY}, ${endX} ${endY}`;
      }

      const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', pathData);
      path.setAttribute('class', 'rel-line');
      path.setAttribute('id', `rel-${ref.from}-${ref.to}-${ref.to_col}`);
      path.setAttribute('data-from', ref.from);
      path.setAttribute('data-to', ref.to);
      path.setAttribute('data-from-col', ref.from_col);
      path.setAttribute('data-to-col', ref.to_col);
      path.setAttribute('stroke', ref.color || '#7a5498');

      // Pata de Gallo (Crow's Foot) en FK, círculo de origen en PK
      const endMarker = ref.tone === 'amber' ? 'url(#crows-foot-amber)' : 'url(#crows-foot)';
      const startMarker = ref.tone === 'amber' ? 'url(#origin-pk-amber)' : 'url(#origin-pk)';
      
      path.setAttribute('marker-start', startMarker);
      path.setAttribute('marker-end', endMarker);

      linesGroup.appendChild(path);
    });
  }

  // Resalta las relaciones y filas conectadas
  function highlightTable(tableId) {
    const connectedTables = new Set([tableId]);

    document.querySelectorAll('.rel-line').forEach(line => {
      const from = line.getAttribute('data-from');
      const to = line.getAttribute('data-to');
      const fromCol = line.getAttribute('data-from-col');
      const toCol = line.getAttribute('data-to-col');

      if (from === tableId || to === tableId) {
        line.classList.add('highlighted');
        line.classList.remove('dimmed');
        line.setAttribute('marker-start', 'url(#origin-pk-active)');
        line.setAttribute('marker-end', 'url(#crows-foot-active)');
        connectedTables.add(from);
        connectedTables.add(to);

        const r1 = document.getElementById(`row-${from}-${fromCol}`);
        const r2 = document.getElementById(`row-${to}-${toCol}`);
        if (r1) r1.classList.add('col-active');
        if (r2) r2.classList.add('col-active');
      } else {
        line.classList.add('dimmed');
        line.classList.remove('highlighted');
      }
    });

    document.querySelectorAll('.table-card').forEach(card => {
      const id = card.id.replace('table-', '');
      if (connectedTables.has(id)) {
        card.classList.add('highlighted');
        card.classList.remove('dimmed');
      } else {
        card.classList.add('dimmed');
        card.classList.remove('highlighted');
      }
    });
  }

  // Restaura el estado visual de todas las conexiones
  function resetHighlight() {
    document.querySelectorAll('.rel-line').forEach(line => {
      line.classList.remove('highlighted', 'dimmed');
      const from = line.getAttribute('data-from');
      const refObj = references.find(r => r.from === from && r.to === line.getAttribute('data-to') && r.to_col === line.getAttribute('data-to-col'));
      const endMarker = (refObj && refObj.tone === 'amber') ? 'url(#crows-foot-amber)' : 'url(#crows-foot)';
      const startMarker = (refObj && refObj.tone === 'amber') ? 'url(#origin-pk-amber)' : 'url(#origin-pk)';
      line.setAttribute('marker-start', startMarker);
      line.setAttribute('marker-end', endMarker);
    });

    document.querySelectorAll('.table-card').forEach(card => {
      card.classList.remove('highlighted', 'dimmed');
    });

    document.querySelectorAll('.col-row').forEach(row => {
      row.classList.remove('col-active');
    });
  }

  function centerOnTable(t) {
    const cw = container.clientWidth;
    const ch = container.clientHeight;
    scale = 0.85;
    panX = (cw / 2) - (t.x + t.width / 2) * scale - 120;
    panY = (ch / 2) - (t.y + t.height / 2) * scale;
    updateTransform();
    highlightTable(t.id);
  }

  function selectAndShowTable(t) {
    highlightTable(t.id);
    showTableDetails(t);
  }

  function showTableDetails(t) {
    detailPanel.classList.add('open');
    document.getElementById('panel-title').innerText = t.name;

    const incoming = references.filter(r => r.to === t.id);
    const outgoing = references.filter(r => r.from === t.id);

    let incomingHtml = incoming.length > 0
      ? incoming.map(r => `
          <li style="margin-bottom:6px;display:flex;align-items:center;justify-content:space-between;background:#241538;padding:6px 10px;border-radius:6px;border:1px solid #4d2f70;">
            <div>
              <span class="rel-link" data-target="${r.from}" style="color:#f59e51;font-weight:bold;cursor:pointer;text-decoration:underline;">
                ${tables.find(x => x.id === r.from)?.name || r.from}
              </span>
              <span style="color:#b8a5cf;font-size:10px;display:block;">(${r.from_col} ➔ ${r.to_col})</span>
            </div>
            <span style="font-size:10px;background:rgba(200,139,0,0.2);color:#f8d299;padding:1px 6px;border-radius:10px;">${r.card}</span>
          </li>
        `).join('')
      : '<p style="color:#7d6896;font-style:italic;margin:4px 0;font-size:11px;">No tiene tablas padre dependientes.</p>';

    let outgoingHtml = outgoing.length > 0
      ? outgoing.map(r => `
          <li style="margin-bottom:6px;display:flex;align-items:center;justify-content:space-between;background:#241538;padding:6px 10px;border-radius:6px;border:1px solid #4d2f70;">
            <div>
              <span class="rel-link" data-target="${r.to}" style="color:#f8d299;font-weight:bold;cursor:pointer;text-decoration:underline;">
                ${tables.find(x => x.id === r.to)?.name || r.to}
              </span>
              <span style="color:#b8a5cf;font-size:10px;display:block;">(${r.from_col} ➔ ${r.to_col})</span>
            </div>
            <span style="font-size:10px;background:rgba(122,84,152,0.25);color:#b8a5cf;padding:1px 6px;border-radius:10px;">${r.card}</span>
          </li>
        `).join('')
      : '<p style="color:#7d6896;font-style:italic;margin:4px 0;font-size:11px;">No tiene tablas hijas subordinadas.</p>';

    let colsDetail = t.columns.map(c => `
      <tr style="border-bottom:1px solid rgba(77,47,112,0.3);">
        <td style="padding:4px 0;font-family:monospace;color:#fdfbf7;">
          ${c.pk ? '<span style="color:#f59e51;" title="PK">🔑 </span>' : (c.name.startsWith('id_') || c.name.startsWith('fk_') ? '<span style="color:#e1b983;" title="FK">🔗 </span>' : '')}
          ${c.uniq && !c.pk ? '<span style="color:#f8d299;" title="Unique">★ </span>' : ''}
          ${c.name}
        </td>
        <td style="padding:4px 0;color:#b8a5cf;font-family:monospace;font-size:10px;">${c.type}</td>
        <td style="padding:4px 0;text-align:right;font-size:10px;color:#7d6896;">
          ${c.pk ? '<span style="color:#f59e51;font-weight:bold;">PK</span>' : (c.name.startsWith('id_') || c.name.startsWith('fk_') ? '<span style="color:#e1b983;">FK</span>' : (c.null ? 'NULL' : 'NOT NULL'))}
        </td>
      </tr>
    `).join('');

    const badgeClass = t.tone === 'amber' ? 'badge-amber' : 'badge-purple';

    document.getElementById('panel-content').innerHTML = `
      <div style="background:#201331;padding:10px 14px;border-radius:8px;border:1px solid #4d2f70;display:flex;align-items:center;justify-content:space-between;">
        <div>
          <span style="color:#7d6896;display:block;font-size:10px;text-transform:uppercase;letter-spacing:0.5px;">Módulo / Categoría:</span>
          <span style="font-weight:bold;color:#fdfbf7;font-size:12px;">${t.module}</span>
        </div>
        <span class="${badgeClass}" style="padding:2px 8px;border-radius:12px;font-size:10px;font-weight:600;text-transform:uppercase;">
          ${t.tone === 'amber' ? 'Gama Ámbar' : 'Gama Morado'}
        </span>
      </div>

      <button id="btn-focus-table" style="background:linear-gradient(135deg, #4d2f70 0%, #2d1c42 100%);border:1px solid #7a5498;color:#fdfbf7;padding:7px 10px;border-radius:6px;font-size:11px;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:6px;width:100%;font-weight:600;transition:all 0.15s;">
        🎯 Centrar y enfocar en diagrama
      </button>

      <div>
        <h4 style="font-weight:bold;color:#f8d299;margin:0 0 6px 0;font-size:11.5px;display:flex;align-items:center;justify-content:space-between;">
          <span>Estructura de Columnas</span>
          <span style="font-size:10px;color:#7d6896;">${t.columns.length} campos</span>
        </h4>
        <table style="width:100%;text-align:left;font-size:11px;">
          <thead>
            <tr style="color:#7d6896;font-size:10px;border-bottom:1px solid #4d2f70;">
              <th>Campo</th><th>Tipo</th><th style="text-align:right;">Atributo</th>
            </tr>
          </thead>
          <tbody>${colsDetail}</tbody>
        </table>
      </div>

      <div>
        <h4 style="font-weight:bold;color:#f8d299;margin:0 0 6px 0;font-size:11.5px;">Relaciones Entrantes (Padres):</h4>
        <ul style="padding-left:0;list-style:none;margin:0;font-size:11px;">${incomingHtml}</ul>
      </div>

      <div>
        <h4 style="font-weight:bold;color:#f8d299;margin:0 0 6px 0;font-size:11.5px;">Relaciones Salientes (Hijas):</h4>
        <ul style="padding-left:0;list-style:none;margin:0;font-size:11px;">${outgoingHtml}</ul>
      </div>
    `;

    document.getElementById('btn-focus-table').onclick = () => centerOnTable(t);

    document.querySelectorAll('.rel-link').forEach(link => {
      link.addEventListener('click', (e) => {
        const targetId = e.currentTarget.getAttribute('data-target');
        const targetTable = tables.find(x => x.id === targetId);
        if (targetTable) {
          centerOnTable(targetTable);
          showTableDetails(targetTable);
        }
      });
    });
  }

  // Cierre del panel lateral
  document.getElementById('close-panel').addEventListener('click', () => {
    detailPanel.classList.remove('open');
    resetHighlight();
  });

  // Eventos de Paneo y Zoom en el lienzo
  container.addEventListener('mousedown', e => {
    if (e.target.closest('.table-card') || e.target.closest('#detail-panel') || e.target.closest('header')) return;
    isPanning = true;
    hasMoved = false;
    startX = e.clientX - panX;
    startY = e.clientY - panY;
    container.style.cursor = 'grabbing';
  });

  window.addEventListener('mousemove', e => {
    if (!isPanning) return;
    hasMoved = true;
    panX = e.clientX - startX;
    panY = e.clientY - startY;
    updateTransform();
  });

  window.addEventListener('mouseup', (e) => {
    if (isPanning && !hasMoved) {
      if (!e.target.closest('.table-card') && !e.target.closest('#detail-panel')) {
        detailPanel.classList.remove('open');
        resetHighlight();
      }
    }
    isPanning = false;
    container.style.cursor = 'grab';
  });

  container.addEventListener('wheel', e => {
    e.preventDefault();
    const zoomFactor = e.deltaY < 0 ? 1.08 : 0.92;
    const rect = container.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;

    const newScale = Math.min(Math.max(0.2, scale * zoomFactor), 2.2);
    panX = mouseX - (mouseX - panX) * (newScale / scale);
    panY = mouseY - (mouseY - panY) * (newScale / scale);
    scale = newScale;
    updateTransform();
  }, { passive: false });

  document.getElementById('zoom-in').onclick = () => {
    scale = Math.min(scale * 1.2, 2.2);
    updateTransform();
  };
  document.getElementById('zoom-out').onclick = () => {
    scale = Math.max(scale / 1.2, 0.2);
    updateTransform();
  };
  document.getElementById('zoom-reset').onclick = () => {
    scale = 1.0;
    panX = 40;
    panY = 20;
    updateTransform();
  };
  document.getElementById('zoom-fit').onclick = () => {
    scale = 0.58;
    panX = 20;
    panY = 10;
    updateTransform();
  };

  document.getElementById('search-input').addEventListener('input', e => {
    const val = e.target.value.toLowerCase().trim();
    if (!val) {
      resetHighlight();
      return;
    }

    let firstMatch = null;
    tables.forEach(t => {
      const matchName = t.name.toLowerCase().includes(val);
      const matchCol = t.columns.some(c => c.name.toLowerCase().includes(val));
      const card = document.getElementById('table-' + t.id);

      if (matchName || matchCol) {
        card.classList.remove('dimmed');
        card.classList.add('highlighted');
        if (!firstMatch) firstMatch = t;
      } else {
        card.classList.add('dimmed');
        card.classList.remove('highlighted');
      }
    });

    if (firstMatch && val.length > 2) {
      centerOnTable(firstMatch);
    }
  });

  document.querySelectorAll('#module-filters button').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('#module-filters button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const mod = btn.getAttribute('data-mod');
      if (mod === 'all') {
        resetHighlight();
        return;
      }

      tables.forEach(t => {
        const card = document.getElementById('table-' + t.id);
        if (t.module === mod) {
          card.classList.remove('dimmed');
          card.classList.add('highlighted');
        } else {
          card.classList.add('dimmed');
          card.classList.remove('highlighted');
        }
      });

      document.querySelectorAll('.rel-line').forEach(line => {
        const from = line.getAttribute('data-from');
        const to = line.getAttribute('data-to');
        const t1 = tables.find(x => x.id === from);
        const t2 = tables.find(x => x.id === to);
        if (t1?.module === mod || t2?.module === mod) {
          line.classList.add('highlighted');
          line.classList.remove('dimmed');
        } else {
          line.classList.add('dimmed');
          line.classList.remove('highlighted');
        }
      });
    });
  });

  renderTables();
  renderReferences();
  updateTransform();

})();
