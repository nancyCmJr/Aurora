-- =============================================================
-- AURORA | Cuentas de demostración para el esquema NUEVO.
-- Compatible con usuarios(codigo,nombre_usuario,rol,correo,password,
--                         numero_control,id_docente,estado).
-- No modifica estructura ni elimina registros existentes.
-- Ejecutar una sola vez (es seguro repetirlo si no hay conflictos).
-- =============================================================
USE aurora;
START TRANSACTION;

-- 1. Primero crear los registros académicos que requieren las FK.
INSERT INTO alumnos (numero_control, nombre, apellidos, semestre, estado)
SELECT 'TEST20260001', 'Alicia', 'García Prueba', 3, 'Activo'
WHERE NOT EXISTS (
    SELECT 1 FROM alumnos WHERE numero_control = 'TEST20260001'
);

INSERT INTO docentes (codigo, nombre, apellidos, titulo_academico, estado)
SELECT 'DOC-DEMO-01', 'Carlos', 'López Prueba', 'Ingeniería', 'Activo'
WHERE NOT EXISTS (
    SELECT 1 FROM docentes WHERE codigo = 'DOC-DEMO-01'
);

-- 2. Contraseñas bcrypt producidas con PHP password_hash(..., PASSWORD_BCRYPT).
-- Los tres tipos de contraseña se validan con password_verify() en auth/login.php.
-- Admin123! (administradores), Docente123! (docente), Alumno123! (alumno)

-- ADMIN ACTIVO
INSERT INTO usuarios
    (codigo, nombre_usuario, rol, correo, password, numero_control, id_docente, estado)
SELECT
    'ADM-DEMO-01', 'admin.prueba', 'Admin', 'admin.prueba@aurora.test',
    '$2y$12$MqEa0NotaBwc5HTTAOPrQejuwrNiLWOkeh1.HqaMl8OvYWbw4BP/2',
    NULL, NULL, 'Activo'
WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE codigo = 'ADM-DEMO-01' OR nombre_usuario = 'admin.prueba' OR correo = 'admin.prueba@aurora.test');

-- DOCENTE ACTIVO; id_docente se obtiene del registro recién creado, SIN asumir id=1.
INSERT INTO usuarios
    (codigo, nombre_usuario, rol, correo, password, numero_control, id_docente, estado)
SELECT
    'USR-DOC-01', 'docente.prueba', 'Docente', 'docente.prueba@aurora.test',
    '$2y$12$OmKsxbsajYVebw165Crr9Oo4FlYg4B8xq4cHdlSDzNIfH6Bp4fwc6',
    NULL, d.id_docente, 'Activo'
FROM docentes d
WHERE d.codigo = 'DOC-DEMO-01'
  AND NOT EXISTS (SELECT 1 FROM usuarios WHERE codigo = 'USR-DOC-01' OR nombre_usuario = 'docente.prueba' OR correo = 'docente.prueba@aurora.test' OR id_docente = d.id_docente)
LIMIT 1;

-- ALUMNO ACTIVO; numero_control vincula con alumnos.
INSERT INTO usuarios
    (codigo, nombre_usuario, rol, correo, password, numero_control, id_docente, estado)
SELECT
    'USR-ALU-01', 'alumno.prueba', 'Alumno', 'alumno.prueba@aurora.test',
    '$2y$12$H19Ma2kpFq360KHocxpgNeoUvLBVK4EvqKZZ/DqyOj3jGw6Y6siQC',
    a.numero_control, NULL, 'Activo'
FROM alumnos a
WHERE a.numero_control = 'TEST20260001'
  AND NOT EXISTS (SELECT 1 FROM usuarios WHERE codigo = 'USR-ALU-01' OR nombre_usuario = 'alumno.prueba' OR correo = 'alumno.prueba@aurora.test' OR numero_control = a.numero_control)
LIMIT 1;

-- ADMINISTRADORES ADICIONALES: para comprobar el rechazo por estado.
INSERT INTO usuarios
    (codigo, nombre_usuario, rol, correo, password, numero_control, id_docente, estado)
SELECT
    'ADM-BLOQ-01', 'admin.bloqueado', 'Admin', 'bloqueado.prueba@aurora.test',
    '$2y$12$MqEa0NotaBwc5HTTAOPrQejuwrNiLWOkeh1.HqaMl8OvYWbw4BP/2',
    NULL, NULL, 'Bloqueado'
WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE codigo = 'ADM-BLOQ-01' OR nombre_usuario = 'admin.bloqueado' OR correo = 'bloqueado.prueba@aurora.test');

INSERT INTO usuarios
    (codigo, nombre_usuario, rol, correo, password, numero_control, id_docente, estado)
SELECT
    'ADM-INAC-01', 'admin.inactivo', 'Admin', 'inactivo.prueba@aurora.test',
    '$2y$12$MqEa0NotaBwc5HTTAOPrQejuwrNiLWOkeh1.HqaMl8OvYWbw4BP/2',
    NULL, NULL, 'Inactivo'
WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE codigo = 'ADM-INAC-01' OR nombre_usuario = 'admin.inactivo' OR correo = 'inactivo.prueba@aurora.test');

COMMIT;

-- Confirmar el resultado:
SELECT codigo, nombre_usuario, rol, correo, numero_control, id_docente, estado
FROM usuarios
WHERE codigo IN ('ADM-DEMO-01','USR-DOC-01','USR-ALU-01','ADM-BLOQ-01','ADM-INAC-01')
ORDER BY rol, codigo;
