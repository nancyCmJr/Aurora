import { ChangeDetectorRef, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { finalize } from 'rxjs';
import {
  IonContent,
  IonIcon,
  IonSpinner,
} from '@ionic/angular';
import { addIcons } from 'ionicons';
import {
  sparklesOutline,
  schoolOutline,
  personOutline,
  shieldOutline,
  lockClosedOutline,
  eyeOutline,
  eyeOffOutline,
  alertCircleOutline,
  sunnyOutline,
  moonOutline,
  arrowBackOutline,
  arrowForwardOutline,
} from 'ionicons/icons';
import { gsap } from 'gsap';
import { AuthService } from '../services/auth.service';
import { AuroraThemeService } from '../services/aurora-theme.service';

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonIcon,
    IonSpinner,
  ],
})
export class LoginPage {
  readonly themeService = inject(AuroraThemeService);
  private readonly cdr = inject(ChangeDetectorRef);
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  correo = '';
  contra = '';
  showPassword = false;
  recordarSesion = true;
  cargando = false;
  mensajeError = '';
  isLoginFormActive = false;

  constructor() {
    addIcons({
      sparklesOutline,
      schoolOutline,
      personOutline,
      shieldOutline,
      lockClosedOutline,
      eyeOutline,
      eyeOffOutline,
      alertCircleOutline,
      sunnyOutline,
      moonOutline,
      arrowBackOutline,
      arrowForwardOutline,
    });
  }

  toggleTheme(event: Event): void {
    event.stopPropagation();
    this.themeService.toggleDarkMode();
  }

  /**
   * 6.1 Transición de Entrada (enterLoginForm)
   * - Desvanecimiento de Bienvenida: autoAlpha: 0, traslación en X (-25px) y duración de 0.35s con curva power2.out.
   * - Aparición de Tarjeta de Formulario: display: block, autoAlpha: 1, scale: 1 (desde 0.95), duración de 0.45s y enfoque inmediato (focus()) en el campo institucional.
   */
  enterLoginForm(event?: Event): void {
    if (this.isLoginFormActive) return;

    const welcome = document.getElementById('login-welcome-box');
    const formCard = document.getElementById('login-form-card');

    if (!welcome || !formCard) {
      this.isLoginFormActive = true;
      return;
    }

    this.isLoginFormActive = true;

    // Desvanecimiento de Bienvenida
    gsap.to(welcome, {
      autoAlpha: 0,
      x: -25,
      duration: 0.35,
      ease: 'power2.out',
      onComplete: () => {
        gsap.set(welcome, { display: 'none' });
      },
    });

    // Aparición de Tarjeta de Formulario
    gsap.fromTo(
      formCard,
      { autoAlpha: 0, x: 25, scale: 0.95, display: 'block' },
      {
        autoAlpha: 1,
        x: 0,
        scale: 1,
        duration: 0.45,
        ease: 'power2.out',
        onComplete: () => {
          const userInput = document.getElementById('aurora-login-user') as HTMLInputElement;
          if (userInput) userInput.focus();
        },
      }
    );
  }

  /**
   * 6.2 Transición de Retorno (exitLoginForm)
   * - Ocultamiento de Formulario: autoAlpha: 0, traslación en X (20px), escala a 0.96 en 0.28s con curva power2.in.
   * - Restitución de Bienvenida: display: flex, autoAlpha: 1, traslación en X a 0px en 0.35s con curva power2.out.
   */
  exitLoginForm(event?: Event): void {
    if (event) event.stopPropagation();

    const welcome = document.getElementById('login-welcome-box');
    const formCard = document.getElementById('login-form-card');

    if (!welcome || !formCard) {
      this.isLoginFormActive = false;
      return;
    }

    // Ocultamiento de Formulario
    gsap.to(formCard, {
      autoAlpha: 0,
      x: 20,
      scale: 0.96,
      duration: 0.28,
      ease: 'power2.in',
      onComplete: () => {
        gsap.set(formCard, { display: 'none' });
        this.isLoginFormActive = false;
        this.cdr.markForCheck();
      },
    });

    // Restitución de Bienvenida
    gsap.fromTo(
      welcome,
      { x: -20, display: 'flex' },
      {
        autoAlpha: 1,
        x: 0,
        duration: 0.35,
        ease: 'power2.out',
      }
    );
  }

  llenarDemo(rol: 'admin' | 'docente' | 'alumno'): void {
    if (rol === 'admin') {
      this.correo = 'admin.prueba@aurora.test';
      this.contra = 'Admin123!';
    } else if (rol === 'docente') {
      this.correo = 'docente.prueba@aurora.test';
      this.contra = 'Docente123!';
    } else {
      this.correo = 'alumno.prueba@aurora.test';
      this.contra = 'Alumno123!';
    }
    this.mensajeError = '';

    if (!this.isLoginFormActive) {
      this.enterLoginForm();
    }
    this.cdr.markForCheck();
  }

  iniciarSesion(): void {
    if (this.cargando) return;

    this.mensajeError = '';
    let correo = this.correo.trim().toLowerCase();

    if (!correo || !this.contra) {
      this.mensajeError = 'Ingresa tu correo o usuario y contraseña.';
      return;
    }

    // Normalizaciones rápidas de prueba
    if (correo === 'admin' || correo === 'admin.prueba') {
      correo = 'admin.prueba@aurora.test';
    } else if (correo === 'docente' || correo === 'docente.prueba') {
      correo = 'docente.prueba@aurora.test';
    } else if (correo === 'alumno' || correo === 'alumno.prueba' || correo === '21000101') {
      correo = 'alumno.prueba@aurora.test';
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(correo)) {
      this.mensajeError = 'Escribe un correo institucional válido (ej: usuario@aurora.test).';
      return;
    }

    this.cargando = true;
    this.auth.login(correo, this.contra)
      .pipe(finalize(() => {
        this.cargando = false;
        this.cdr.markForCheck();
      }))
      .subscribe({
        next: (respuesta) => {
          this.cdr.markForCheck();
          if (respuesta.success && this.auth.estaAutenticado()) {
            this.contra = '';
            // NAVEGACIÓN ESTRICTA AL PANEL INSTITUCIONAL HOME DE NANCY
            void this.router.navigateByUrl('/home', { replaceUrl: true });
          } else {
            this.mensajeError = respuesta.message || 'Credenciales no válidas.';
          }
        },
        error: (error: HttpErrorResponse) => {
          this.cdr.markForCheck();
          if (error.status === 0) {
            this.mensajeError = 'No se pudo conectar con el servidor (api_aurora). Revisa XAMPP / Apache.';
          } else {
            const mensaje = error.error?.message;
            this.mensajeError = typeof mensaje === 'string'
              ? mensaje
              : 'Error al iniciar sesión. Inténtalo nuevamente.';
          }
        },
      });
  }
}
