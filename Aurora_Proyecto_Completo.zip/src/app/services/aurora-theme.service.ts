import { Injectable, signal, computed, effect } from '@angular/core';

export type LayoutStructure = 'tabs' | 'drawer' | 'floating-island' | 'hero-segments' | 'minimal-fab';
export type DesignStyle = 'glassmorphism' | 'neo-bento' | 'neumorphism' | 'cyber-glow' | 'minimal-flat';
export type ColorPaletteId = 'boreal-classic' | 'golden-twilight' | 'deep-nebula' | 'emerald-aurora' | 'royal-amethyst';
export type DemoScreen = 'alumno' | 'login' | 'calificaciones' | 'docente' | 'componentes';
export type DeviceFrame = 'iphone' | 'android' | 'fullscreen';
export type LogoConcept = 'concept1' | 'concept2' | 'concept3' | 'concept4' | 'concept5' | 'concept6';

export interface ColorPaletteConfig {
  id: ColorPaletteId;
  nombre: string;
  descripcion: string;
  previewColors: string[];
  primary: string;
  primaryShade: string;
  primaryTint: string;
  secondary: string;
  secondaryShade: string;
  accent: string;
  accentGlow: string;
  // Dark mode backgrounds
  darkBg: string;
  darkSurface: string;
  darkSurfaceElevated: string;
  darkBorder: string;
  darkText: string;
  darkTextMuted: string;
  // Light mode backgrounds (Header SIEMPRE oscuro en modo claro)
  lightBg: string;
  lightSurface: string;
  lightSurfaceElevated: string;
  lightBorder: string;
  lightText: string;
  lightTextMuted: string;
  lightHeaderBg: string;
  lightHeaderText: string;
  lightHeaderBorder: string;
}

export interface StructureOption {
  id: LayoutStructure;
  nombre: string;
  descripcion: string;
  icono: string;
}

export interface StyleOption {
  id: DesignStyle;
  nombre: string;
  descripcion: string;
  tag: string;
  icono: string;
}

export interface LogoConceptOption {
  id: LogoConcept;
  nombre: string;
  descripcion: string;
  badge: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuroraThemeService {
  // Paletas oficiales de la identidad visual de Aurora
  readonly paletas: ColorPaletteConfig[] = [
    {
      id: 'boreal-classic',
      nombre: 'Aurora Boreal Clásica',
      descripcion: 'Identidad visual original de Aurora: Púrpura noche profundo y Dorado estelar.',
      previewColors: ['#503070', '#F0C070', '#E879F9', '#0C0A1A'],
      primary: '#503070',
      primaryShade: '#3B2054',
      primaryTint: '#6A4392',
      secondary: '#F0C070',
      secondaryShade: '#D6A450',
      accent: '#E879F9',
      accentGlow: 'rgba(232, 121, 249, 0.45)',
      darkBg: '#0C0A1A',
      darkSurface: '#161329',
      darkSurfaceElevated: '#211C3D',
      darkBorder: 'rgba(240, 192, 112, 0.22)',
      darkText: '#F5F3FF',
      darkTextMuted: '#A7A1C2',
      // MODO CLARO CON HEADER OSCURO Y ALTO CONTRASTE
      lightBg: '#F5F6FC',
      lightSurface: '#FFFFFF',
      lightSurfaceElevated: '#ECEEF8',
      lightBorder: '#D8D6EB',
      lightText: '#160E29',
      lightTextMuted: '#4A445E',
      lightHeaderBg: '#18102E',
      lightHeaderText: '#FFFFFF',
      lightHeaderBorder: 'rgba(240, 192, 112, 0.3)'
    },
    {
      id: 'golden-twilight',
      nombre: 'Golden Twilight (Ocaso)',
      descripcion: 'Dorado ámbar cálido con toques de púrpura imperial.',
      previewColors: ['#F59E0B', '#581C87', '#EA580C', '#130E1B'],
      primary: '#D97706',
      primaryShade: '#B45309',
      primaryTint: '#FBBF24',
      secondary: '#581C87',
      secondaryShade: '#3B0764',
      accent: '#EA580C',
      accentGlow: 'rgba(245, 158, 11, 0.45)',
      darkBg: '#130E1B',
      darkSurface: '#20162B',
      darkSurfaceElevated: '#2C1F3D',
      darkBorder: 'rgba(245, 158, 11, 0.26)',
      darkText: '#FFFBEB',
      darkTextMuted: '#C2B19D',
      lightBg: '#FAF7EE',
      lightSurface: '#FFFFFF',
      lightSurfaceElevated: '#F5EFE0',
      lightBorder: '#E2D9C5',
      lightText: '#221504',
      lightTextMuted: '#5C4A34',
      lightHeaderBg: '#1E1428',
      lightHeaderText: '#FFFBEB',
      lightHeaderBorder: 'rgba(245, 158, 11, 0.35)'
    },
    {
      id: 'deep-nebula',
      nombre: 'Deep Space Nebula',
      descripcion: 'Abismo cósmico azul profundo, magenta estelar y cyan boreal.',
      previewColors: ['#6366F1', '#EC4899', '#06B6D4', '#070614'],
      primary: '#6366F1',
      primaryShade: '#4F46E5',
      primaryTint: '#818CF8',
      secondary: '#EC4899',
      secondaryShade: '#DB2777',
      accent: '#06B6D4',
      accentGlow: 'rgba(6, 182, 212, 0.45)',
      darkBg: '#070614',
      darkSurface: '#101026',
      darkSurfaceElevated: '#1A1A3A',
      darkBorder: 'rgba(99, 102, 241, 0.25)',
      darkText: '#F8FAFC',
      darkTextMuted: '#94A3B8',
      lightBg: '#F1F4FD',
      lightSurface: '#FFFFFF',
      lightSurfaceElevated: '#E5EBFB',
      lightBorder: '#CBD5E1',
      lightText: '#0F172A',
      lightTextMuted: '#334155',
      lightHeaderBg: '#0F0F29',
      lightHeaderText: '#FFFFFF',
      lightHeaderBorder: 'rgba(99, 102, 241, 0.35)'
    },
    {
      id: 'emerald-aurora',
      nombre: 'Emerald Aurora (Luces del Norte)',
      descripcion: 'Efecto Aurora Borealis verde esmeralda y cyan con fondo nocturno polar.',
      previewColors: ['#059669', '#0891B2', '#FACC15', '#041312'],
      primary: '#059669',
      primaryShade: '#047857',
      primaryTint: '#10B981',
      secondary: '#0891B2',
      secondaryShade: '#0E7490',
      accent: '#FACC15',
      accentGlow: 'rgba(16, 185, 129, 0.45)',
      darkBg: '#041312',
      darkSurface: '#08211E',
      darkSurfaceElevated: '#0D312C',
      darkBorder: 'rgba(16, 185, 129, 0.25)',
      darkText: '#ECFDF5',
      darkTextMuted: '#86A89F',
      lightBg: '#F0F9F5',
      lightSurface: '#FFFFFF',
      lightSurfaceElevated: '#E2F3EB',
      lightBorder: '#C6E3D5',
      lightText: '#062E25',
      lightTextMuted: '#245247',
      lightHeaderBg: '#0A1E1B',
      lightHeaderText: '#ECFDF5',
      lightHeaderBorder: 'rgba(16, 185, 129, 0.35)'
    },
    {
      id: 'royal-amethyst',
      nombre: 'Royal Amethyst (Academia Clásica)',
      descripcion: 'Púrpura real majestuoso con acentos corales y contraste institucional.',
      previewColors: ['#7C3AED', '#F43F5E', '#312E81', '#0F0C20'],
      primary: '#7C3AED',
      primaryShade: '#6D28D9',
      primaryTint: '#8B5CF6',
      secondary: '#F43F5E',
      secondaryShade: '#E11D48',
      accent: '#F43F5E',
      accentGlow: 'rgba(244, 63, 94, 0.45)',
      darkBg: '#0F0C20',
      darkSurface: '#1A1535',
      darkSurfaceElevated: '#251E4B',
      darkBorder: 'rgba(124, 58, 237, 0.25)',
      darkText: '#FAF5FF',
      darkTextMuted: '#A99DC9',
      lightBg: '#F7F3FC',
      lightSurface: '#FFFFFF',
      lightSurfaceElevated: '#EDE5F7',
      lightBorder: '#D9CEE8',
      lightText: '#180E2B',
      lightTextMuted: '#473663',
      lightHeaderBg: '#1B1133',
      lightHeaderText: '#FAF5FF',
      lightHeaderBorder: 'rgba(124, 58, 237, 0.35)'
    }
  ];

  // Conceptos de Logotipo basados en la hoja de propuestas subida por el usuario
  readonly logoConcepts: LogoConceptOption[] = [
    {
      id: 'concept1',
      nombre: 'Concepto 01: Engrane & Estrella',
      descripcion: 'Engrane dorado con estrella de cuatro puntas y cintas de aurora borealis.',
      badge: 'University Portal'
    },
    {
      id: 'concept2',
      nombre: 'Concepto 02: Letra A Cinta Dinámica',
      descripcion: 'Cinta geométrica plegada en letra "A" con estrella fugaz dorada.',
      badge: 'Dynamic Brand'
    },
    {
      id: 'concept3',
      nombre: 'Concepto 03: Letra A & Engrane',
      descripcion: 'Letra A entrelazada con rueda de engrane de ingeniería.',
      badge: 'Portal Aurora'
    },
    {
      id: 'concept4',
      nombre: 'Concepto 04: Letra A Cursiva & Estrellas',
      descripcion: 'Trazo caligráfico elegante con constelación de estrellas dobles.',
      badge: 'Campus Identity'
    },
    {
      id: 'concept5',
      nombre: 'Concepto 05: Fluido Orgánico',
      descripcion: 'Gotas de nebulosa cósmica en gradiente dorado y púrpura.',
      badge: 'Modern Organic'
    },
    {
      id: 'concept6',
      nombre: 'Concepto 06: Espiral Cósmica @',
      descripcion: 'Vórtice interactivo en espiral arroba con estrella boreal.',
      badge: 'Software Portal'
    }
  ];

  // Estructuras de navegación disponibles
  readonly estructuras: StructureOption[] = [
    {
      id: 'tabs',
      nombre: 'Bottom Navigation Tabs',
      descripcion: 'Barra de navegación inferior fija estándar con iconos, badges y header limpio.',
      icono: 'phone-portrait-outline'
    },
    {
      id: 'drawer',
      nombre: 'Side Drawer / Menú Lateral',
      descripcion: 'Header con hamburguesa que despliega drawer lateral con perfil de usuario y accesos.',
      icono: 'menu-outline'
    },
    {
      id: 'floating-island',
      nombre: 'Dynamic Floating Island',
      descripcion: 'Cápsula flotante suspendida tipo iOS con blur, efectos táctiles y máxima modernidad.',
      icono: 'radio-button-on-outline'
    },
    {
      id: 'hero-segments',
      nombre: 'Hero Header + Segmentos',
      descripcion: 'Cabecera expandible con fondo Aurora cósmico, bienvenida y barra horizontal de pestañas.',
      icono: 'albums-outline'
    },
    {
      id: 'minimal-fab',
      nombre: 'Minimal Bar + Central FAB',
      descripcion: 'Header súper limpio con botón de acción flotante central radial para accesos clave.',
      icono: 'add-circle-outline'
    }
  ];

  // Estilos de diseño visual disponibles
  readonly estilos: StyleOption[] = [
    {
      id: 'neo-bento',
      nombre: 'Modern Neo-Bento (Duolingo Tactile)',
      descripcion: 'Botones 3D pulsables con borde inferior de profundidad, tarjetas con contornos nítidos de 2px y gamificación.',
      tag: 'Duolingo / Apple',
      icono: 'grid-outline'
    },
    {
      id: 'glassmorphism',
      nombre: 'Aurora Glassmorphism',
      descripcion: 'Tarjetas translúcidas con desenfoque de fondo (backdrop-blur), bordes iluminados y resplandor cósmico.',
      tag: 'Trending UI',
      icono: 'sparkles-outline'
    },
    {
      id: 'neumorphism',
      nombre: 'Soft Neumorphism',
      descripcion: 'Relieve táctil suave con sombras gemelas, sensación de pulsado físico y aspecto amigable.',
      tag: 'Tactile UI',
      icono: 'layers-outline'
    },
    {
      id: 'cyber-glow',
      nombre: 'Cyber Aurora Glow',
      descripcion: 'Acentos de neón brillante, resplandor en badges y bordes con gradientes vivos cósmicos.',
      tag: 'Gamer / Sci-Fi',
      icono: 'flash-outline'
    },
    {
      id: 'minimal-flat',
      nombre: 'Minimal Academic Flat',
      descripcion: 'Superficies planas limpias, máximo contraste, sin sombras pesadas, ideal para lectura y trámites.',
      tag: 'Material 3 Flat',
      icono: 'document-text-outline'
    }
  ];

  // Señales reactivas de estado - Configuración oficial elegida
  activeStructure = signal<LayoutStructure>('floating-island');
  activeStyle = signal<DesignStyle>('cyber-glow');
  activePaletteId = signal<ColorPaletteId>('boreal-classic');
  isDarkMode = signal<boolean>(true); // Modo oscuro por default
  activeScreen = signal<DemoScreen>('alumno');
  deviceFrame = signal<DeviceFrame>('iphone');
  activeLogoConcept = signal<LogoConcept>('concept2'); // Concepto 2 por default (Letra A cinta)

  // Estado del menú drawer en la simulación
  isDrawerOpen = signal<boolean>(false);

  // Paleta actual computada
  currentPalette = computed(() => {
    return this.paletas.find(p => p.id === this.activePaletteId()) || this.paletas[0];
  });

  constructor() {
    const savedStructure = localStorage.getItem('aurora_structure') as LayoutStructure;
    const savedStyle = localStorage.getItem('aurora_style') as DesignStyle;
    const savedPalette = localStorage.getItem('aurora_palette') as ColorPaletteId;
    const savedDarkMode = localStorage.getItem('aurora_darkmode');
    const savedLogo = localStorage.getItem('aurora_logo_concept') as LogoConcept;

    if (savedStructure) this.activeStructure.set(savedStructure);
    if (savedStyle) this.activeStyle.set(savedStyle);
    if (savedPalette) this.activePaletteId.set(savedPalette);
    if (savedDarkMode !== null) this.isDarkMode.set(savedDarkMode === 'true');
    if (savedLogo) this.activeLogoConcept.set(savedLogo);

    // Sincronización Global de Variables CSS y Clases de Tema con el DOM
    effect(() => {
      const isDark = this.isDarkMode();
      const style = this.activeStyle();
      const structure = this.activeStructure();
      const vars = this.getThemeCssVariables();
      const root = document.documentElement;

      for (const [key, value] of Object.entries(vars)) {
        root.style.setProperty(key, value);
      }

      // Clases globales de Modo y Estilo
      document.body.classList.toggle('dark', isDark);
      document.body.classList.toggle('light', !isDark);
      document.body.classList.toggle('theme-dark', isDark);
      document.body.classList.toggle('theme-light', !isDark);

      // Clases de estilo visual y estructura
      document.body.classList.remove('style-neo-bento', 'style-glassmorphism', 'style-neumorphism', 'style-cyber-glow', 'style-minimal-flat');
      document.body.classList.add(`style-${style}`);

      document.body.classList.remove('structure-tabs', 'structure-drawer', 'structure-floating-island', 'structure-hero-segments', 'structure-minimal-fab');
      document.body.classList.add(`structure-${structure}`);
    });
  }

  setStructure(structure: LayoutStructure) {
    this.activeStructure.set(structure);
    localStorage.setItem('aurora_structure', structure);
  }

  setStyle(style: DesignStyle) {
    this.activeStyle.set(style);
    localStorage.setItem('aurora_style', style);
  }

  setPalette(paletteId: ColorPaletteId) {
    this.activePaletteId.set(paletteId);
    localStorage.setItem('aurora_palette', paletteId);
  }

  setLogoConcept(concept: LogoConcept) {
    this.activeLogoConcept.set(concept);
    localStorage.setItem('aurora_logo_concept', concept);
  }

  toggleDarkMode() {
    const newVal = !this.isDarkMode();
    this.isDarkMode.set(newVal);
    localStorage.setItem('aurora_darkmode', String(newVal));
  }

  setDarkMode(isDark: boolean) {
    this.isDarkMode.set(isDark);
    localStorage.setItem('aurora_darkmode', String(isDark));
  }

  setScreen(screen: DemoScreen) {
    this.activeScreen.set(screen);
    this.isDrawerOpen.set(false);
  }

  setDeviceFrame(frame: DeviceFrame) {
    this.deviceFrame.set(frame);
  }

  toggleDrawer() {
    this.isDrawerOpen.update(v => !v);
  }

  // Generación de variables CSS para el contenedor interactivo
  getThemeCssVariables(): Record<string, string> {
    const p = this.currentPalette();
    const isDark = this.isDarkMode();

    return {
      '--aurora-primary': p.primary,
      '--aurora-primary-shade': p.primaryShade,
      '--aurora-primary-tint': p.primaryTint,
      '--aurora-secondary': p.secondary,
      '--aurora-secondary-shade': p.secondaryShade,
      '--aurora-accent': p.accent,
      '--aurora-glow': p.accentGlow,
      '--aurora-cyan': '#38bdf8',
      '--aurora-bg': isDark ? p.darkBg : p.lightBg,
      '--aurora-surface': isDark ? p.darkSurface : p.lightSurface,
      '--aurora-surface-elevated': isDark ? p.darkSurfaceElevated : p.lightSurfaceElevated,
      '--aurora-border': isDark ? p.darkBorder : p.lightBorder,
      '--aurora-text': isDark ? p.darkText : p.lightText,
      '--aurora-text-muted': isDark ? p.darkTextMuted : p.lightTextMuted,
      // HEADER SIEMPRE OSCURO EN MODO CLARO (solicitud explícita del usuario)
      '--aurora-header-bg': isDark ? p.darkSurface : p.lightHeaderBg,
      '--aurora-header-text': isDark ? p.darkText : p.lightHeaderText,
      '--aurora-header-border': isDark ? p.darkBorder : p.lightHeaderBorder,
      // PROFUNDIDAD DE BOTONES 3D ESTILO DUOLINGO
      '--aurora-btn-depth-primary': isDark ? '#2a1440' : '#331a52',
      '--aurora-btn-depth-secondary': isDark ? '#996712' : '#b37714',
      '--aurora-btn-depth-card': isDark ? 'rgba(0,0,0,0.4)' : '#c7c4dd',
      '--aurora-font-title': "'REZ', sans-serif",
      // Mapeo dinámico en Ionic
      '--ion-background-color': isDark ? p.darkBg : p.lightBg,
      '--ion-text-color': isDark ? p.darkText : p.lightText,
      '--ion-card-background': isDark ? p.darkSurface : p.lightSurface,
      '--ion-item-background': isDark ? p.darkSurface : p.lightSurface,
      '--ion-toolbar-background': isDark ? p.darkSurface : p.lightHeaderBg,
      '--ion-toolbar-color': isDark ? p.darkText : p.lightHeaderText
    };
  }

  // Generador de código montable para copiar
  generateExportableCode(): { cssVariables: string; htmlTemplate: string; mountingGuide: string } {
    const p = this.currentPalette();
    const isDark = this.isDarkMode();
    const struct = this.activeStructure();
    const style = this.activeStyle();
    const logo = this.activeLogoConcept();

    const cssVariables = `/* ==========================================================================
   AURORA DESIGN SYSTEM TOKENS - Generado desde el Workbench
   Paleta: ${p.nombre} | Estilo: ${style} | Modo: ${isDark ? 'Oscuro' : 'Claro (Header Oscuro)'}
   Logo Propuesto: ${logo}
   ========================================================================== */

:root {
  /* Paleta Base Aurora */
  --aurora-primary: ${p.primary};
  --aurora-primary-shade: ${p.primaryShade};
  --aurora-primary-tint: ${p.primaryTint};
  --aurora-secondary: ${p.secondary};
  --aurora-secondary-shade: ${p.secondaryShade};
  --aurora-accent: ${p.accent};
  --aurora-accent-glow: ${p.accentGlow};

  /* Superficies (${isDark ? 'Modo Oscuro' : 'Modo Claro'}) */
  --aurora-bg: ${isDark ? p.darkBg : p.lightBg};
  --aurora-surface: ${isDark ? p.darkSurface : p.lightSurface};
  --aurora-surface-elevated: ${isDark ? p.darkSurfaceElevated : p.lightSurfaceElevated};
  --aurora-border: ${isDark ? p.darkBorder : p.lightBorder};
  --aurora-text: ${isDark ? p.darkText : p.lightText};
  --aurora-text-muted: ${isDark ? p.darkTextMuted : p.lightTextMuted};

  /* Header Oscuro (Tanto en Modo Claro como Oscuro para alto contraste) */
  --aurora-header-bg: ${isDark ? p.darkSurface : p.lightHeaderBg};
  --aurora-header-text: ${isDark ? p.darkText : p.lightHeaderText};
  --aurora-header-border: ${isDark ? p.darkBorder : p.lightHeaderBorder};

  /* Botones Táctiles 3D (Inspiración Duolingo) */
  --aurora-btn-depth-primary: ${isDark ? '#2a1440' : '#331a52'};
  --aurora-btn-depth-secondary: ${isDark ? '#996712' : '#b37714'};
  --aurora-btn-depth-card: ${isDark ? 'rgba(0,0,0,0.4)' : '#c7c4dd'};

  /* Tipografía */
  --aurora-font-brand: 'REZ', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;

  /* Mapeo Oficial en Ionic Framework */
  --ion-color-primary: ${p.primary};
  --ion-color-primary-rgb: ${this.hexToRgb(p.primary)};
  --ion-color-primary-contrast: #ffffff;
  --ion-color-secondary: ${p.secondary};
  --ion-color-secondary-rgb: ${this.hexToRgb(p.secondary)};
  --ion-color-secondary-contrast: #1a1030;

  --ion-background-color: var(--aurora-bg);
  --ion-text-color: var(--aurora-text);
  --ion-card-background: var(--aurora-surface);
  --ion-item-background: var(--aurora-surface);
}`;

    const htmlTemplate = `<!-- ==========================================================================
     PLANTILLA MONTABLE DE ESTRUCTURA: ${struct.toUpperCase()}
     Estilo: ${style.toUpperCase()} | Modo: ${isDark ? 'Oscuro' : 'Claro'}
     ========================================================================== -->

<ion-app class="aurora-app style-${style} theme-${isDark ? 'dark' : 'light'}">
  <!-- Header Oscuro de Alto Contraste (Siempre Oscuro) -->
  <ion-header class="aurora-header" style="background: var(--aurora-header-bg); color: var(--aurora-header-text);">
    <ion-toolbar style="--background: var(--aurora-header-bg); --color: var(--aurora-header-text);">
      ${struct === 'drawer' ? `
      <ion-buttons slot="start">
        <ion-menu-button style="color: var(--aurora-secondary);"></ion-menu-button>
      </ion-buttons>` : ''}
      <ion-title class="aurora-brand-title font-rez" style="color: var(--aurora-secondary);">
        AURORA
      </ion-title>
      <ion-buttons slot="end">
        <ion-button style="color: #ffffff;">
          <ion-icon name="notifications-outline"></ion-icon>
        </ion-button>
      </ion-buttons>
    </ion-toolbar>
  </ion-header>

  <!-- Botón 3D Estilo Duolingo -->
  <button class="btn-duo-primary">
    <span>Iniciar Trámite</span>
  </button>
</ion-app>`;

    const mountingGuide = `/* ==========================================================================
   GUÍA RÁPIDA DE MONTAJE (CON ESTILO DUOLINGO Y HEADER OSCURO)
   ==========================================================================
   1. Copia las variables en 'src/theme/variables.scss'.
   2. Asegura que el Header móvil use:
      background: var(--aurora-header-bg) !important;
      color: var(--aurora-header-text) !important;
      Esto garantiza que en modo claro el header permanezca elegante y oscuro.
   3. Usa las clases táctiles .btn-duo-primary y .btn-duo-secondary para los botones
      con borde inferior de 4px que dan el efecto 3D presionable de Duolingo.
   ========================================================================== */`;

    return { cssVariables, htmlTemplate, mountingGuide };
  }

  private hexToRgb(hex: string): string {
    const cleanHex = hex.replace('#', '');
    const num = parseInt(cleanHex, 16);
    const r = (num >> 16) & 255;
    const g = (num >> 8) & 255;
    const b = num & 255;
    return `${r}, ${g}, ${b}`;
  }
}
