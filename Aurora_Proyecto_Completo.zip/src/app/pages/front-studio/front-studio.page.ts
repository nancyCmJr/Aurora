import { Component, inject, signal, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { IonIcon, IonToast } from '@ionic/angular';
import { addIcons } from 'ionicons';
import { gsap } from 'gsap';
import {
  phonePortraitOutline,
  desktopOutline,
  menuOutline,
  closeOutline,
  sparklesOutline,
  colorPaletteOutline,
  moonOutline,
  sunnyOutline,
  codeSlashOutline,
  copyOutline,
  checkmarkCircleOutline,
  downloadOutline,
  refreshOutline,
  homeOutline,
  calendarOutline,
  newspaperOutline,
  schoolOutline,
  personOutline,
  notificationsOutline,
  logOutOutline,
  chevronForwardOutline,
  chevronBackOutline,
  timeOutline,
  locationOutline,
  checkmarkOutline,
  searchOutline,
  optionsOutline,
  addCircleOutline,
  flashOutline,
  gridOutline,
  layersOutline,
  settingsOutline,
  bookOutline,
  fingerPrintOutline,
  mailOutline,
  lockClosedOutline,
  eyeOutline,
  eyeOffOutline,
  shareSocialOutline,
  albumsOutline,
  radioOutline,
  chevronDownOutline,
  documentTextOutline,
  radioButtonOnOutline
} from 'ionicons/icons';
import {
  AuroraThemeService,
  LayoutStructure,
  DesignStyle,
  ColorPaletteId,
  DemoScreen,
  DeviceFrame,
  LogoConcept
} from '../../services/aurora-theme.service';

@Component({
  selector: 'app-front-studio',
  templateUrl: './front-studio.page.html',
  styleUrls: ['./front-studio.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonIcon,
    IonToast
  ]
})
export class FrontStudioPage implements AfterViewInit {
  readonly themeService = inject(AuroraThemeService);
  private readonly router = inject(Router);

  // Estados de modales y menús interactivos
  activeMenu = signal<'structure' | 'style' | 'palette' | 'screen' | 'icons' | 'export' | null>(null);
  toastMessage = signal<string | null>(null);
  showToast = signal<boolean>(false);
  activeExportTab = signal<'css' | 'html' | 'guide'>('css');

  // Gamificación con Iconografía Propia de Aurora (Sin emojis)
  dailyQuestCompleted = signal<boolean>(false);
  streakDays = signal<number>(14);
  heartsLeft = signal<number>(5);

  // Estado del Formulario de Login Adaptado al MD de referencia
  isLoginFormActive = signal<boolean>(false);

  // Datos interactivos para las vistas de demostración
  alumnoData = {
    nombre: 'Valeria Montserrat Gómez',
    noControl: '21000101',
    carrera: 'Ing. en Sistemas Computacionales',
    semestre: '7mo Semestre',
    promedio: 94.2,
    creditosAprobados: 198,
    creditosTotales: 260,
    materiasHoy: [
      {
        nombre: 'Programación Móvil (Ionic)',
        docente: 'Dra. María Elena Ramos',
        horario: '07:00 - 09:00',
        aula: 'Laboratorio L-4',
        estado: 'En curso',
        color: 'primary'
      },
      {
        nombre: 'Arquitectura de Software',
        docente: 'Mtro. Carlos Sandoval',
        horario: '09:00 - 11:00',
        aula: 'Edificio B - Aula 12',
        estado: 'Próxima',
        color: 'secondary'
      },
      {
        nombre: 'Inteligencia Artificial',
        docente: 'Dr. Roberto Mendoza',
        horario: '11:00 - 13:00',
        aula: 'Laboratorio L-1',
        estado: 'Pendiente',
        color: 'tertiary'
      }
    ],
    calificaciones: [
      { materia: 'Programación Móvil', u1: 95, u2: 90, u3: 98, u4: '-', prom: 94.3, estado: 'Acreditando' },
      { materia: 'Arquitectura de Software', u1: 88, u2: 92, u3: 90, u4: 95, prom: 91.2, estado: 'Acreditada' },
      { materia: 'Inteligencia Artificial', u1: 96, u2: 100, u3: 94, u4: '-', prom: 96.6, estado: 'Acreditando' },
      { materia: 'Gestión de Proyectos', u1: 90, u2: 85, u3: 90, u4: 92, prom: 89.2, estado: 'Acreditada' },
      { materia: 'Desarrollo Web Fullstack', u1: 100, u2: 98, u3: 95, u4: 98, prom: 97.7, estado: 'Acreditada' }
    ]
  };

  docenteData = {
    nombre: 'Ing. Alejandro Morales H.',
    departamento: 'Sistemas y Computación',
    gruposActivos: 4,
    alumnosTotales: 128,
    alumnosAsistencia: [
      { nombre: 'Gómez Hernández Valeria', control: '21000101', presente: true },
      { nombre: 'Hernández Pérez Luis Ángel', control: '21000102', presente: true },
      { nombre: 'López Morales Samantha', control: '21000103', presente: false },
      { nombre: 'Martínez Soto Diego', control: '21000104', presente: true },
      { nombre: 'Ramírez Díaz Mariana', control: '21000105', presente: true }
    ]
  };

  loginInputUser = signal('21000101');
  loginInputPass = signal('••••••••');
  showPassword = signal(false);

  // Pestaña activa en la simulación móvil de Tabs
  simulatedActiveTab = signal<string>('inicio');

  constructor() {
    addIcons({
      phonePortraitOutline,
      desktopOutline,
      menuOutline,
      closeOutline,
      sparklesOutline,
      colorPaletteOutline,
      moonOutline,
      sunnyOutline,
      codeSlashOutline,
      copyOutline,
      checkmarkCircleOutline,
      downloadOutline,
      refreshOutline,
      homeOutline,
      calendarOutline,
      newspaperOutline,
      schoolOutline,
      personOutline,
      notificationsOutline,
      logOutOutline,
      chevronForwardOutline,
      chevronBackOutline,
      timeOutline,
      locationOutline,
      checkmarkOutline,
      searchOutline,
      optionsOutline,
      addCircleOutline,
      flashOutline,
      gridOutline,
      layersOutline,
      settingsOutline,
      bookOutline,
      fingerPrintOutline,
      mailOutline,
      lockClosedOutline,
      eyeOutline,
      eyeOffOutline,
      shareSocialOutline,
      albumsOutline,
      radioOutline,
      chevronDownOutline,
      documentTextOutline,
      radioButtonOnOutline
    });
  }

  ngAfterViewInit() {
    // Si la pantalla inicial es login, asegurar el estado inicial de GSAP
    if (this.themeService.activeScreen() === 'login') {
      this.initLoginGsapState();
    }
  }

  // Modales interactivos
  openMenu(menu: 'structure' | 'style' | 'palette' | 'screen' | 'icons' | 'export') {
    this.activeMenu.set(this.activeMenu() === menu ? null : menu);
  }

  closeMenu() {
    this.activeMenu.set(null);
  }

  selectStructure(struct: LayoutStructure) {
    this.themeService.setStructure(struct);
    this.showQuickToast(`Estructura cambiada a: ${struct}`);
    this.closeMenu();
  }

  selectStyle(style: DesignStyle) {
    this.themeService.setStyle(style);
    this.showQuickToast(`Estilo visual cambiado a: ${style}`);
    this.closeMenu();
  }

  selectPalette(paletteId: ColorPaletteId) {
    this.themeService.setPalette(paletteId);
    this.showQuickToast(`Paleta aplicada: ${this.themeService.currentPalette().nombre}`);
    this.closeMenu();
  }

  toggleDarkMode() {
    this.themeService.toggleDarkMode();
    const mode = this.themeService.isDarkMode() ? 'Modo Oscuro' : 'Modo Claro (Header Oscuro)';
    this.showQuickToast(`${mode} activado`);
  }

  selectScreen(screen: DemoScreen) {
    this.themeService.setScreen(screen);
    this.closeMenu();

    if (screen === 'login') {
      setTimeout(() => this.initLoginGsapState(), 50);
    }
  }

  selectDevice(frame: DeviceFrame) {
    this.themeService.setDeviceFrame(frame);
  }

  // =========================================================================
  // MOTOR DE TRANSICIONES Y ANIMACIÓN GSAP PARA EL LOGIN (SEGÚN SECCIÓN 6 MD)
  // =========================================================================
  private initLoginGsapState() {
    const welcome = document.getElementById('login-welcome-box');
    const formCard = document.getElementById('login-form-card');

    if (welcome && formCard) {
      if (this.isLoginFormActive()) {
        gsap.set(welcome, { autoAlpha: 0, x: -25, display: 'none' });
        gsap.set(formCard, { autoAlpha: 1, x: 0, scale: 1, display: 'block' });
      } else {
        gsap.set(welcome, { autoAlpha: 1, x: 0, display: 'flex' });
        gsap.set(formCard, { autoAlpha: 0, x: 20, scale: 0.95, display: 'none' });
      }
    }
  }

  /**
   * 6.1 Transición de Entrada (enterLoginForm)
   * - Desvanecimiento de Bienvenida: autoAlpha: 0, traslación en X (-25px), 0.35s con curva power2.out
   * - Aparición de Tarjeta de Formulario: display: block, autoAlpha: 1, scale: 1 (desde 0.95), 0.45s y focus()
   */
  enterLoginForm(event?: Event) {
    if (this.isLoginFormActive()) return;

    const welcome = document.getElementById('login-welcome-box');
    const formCard = document.getElementById('login-form-card');

    if (!welcome || !formCard) {
      this.isLoginFormActive.set(true);
      return;
    }

    this.isLoginFormActive.set(true);

    // Animación de salida de la bienvenida
    gsap.to(welcome, {
      autoAlpha: 0,
      x: -25,
      duration: 0.35,
      ease: 'power2.out',
      onComplete: () => {
        gsap.set(welcome, { display: 'none' });
      }
    });

    // Animación de entrada de la tarjeta de login
    gsap.fromTo(formCard,
      { autoAlpha: 0, x: 20, scale: 0.95, display: 'block' },
      {
        autoAlpha: 1,
        x: 0,
        scale: 1,
        duration: 0.45,
        ease: 'power2.out',
        onComplete: () => {
          const input = document.getElementById('aurora-login-user') as HTMLInputElement;
          if (input) input.focus();
        }
      }
    );
  }

  /**
   * 6.2 Transición de Retorno (exitLoginForm)
   * - Ocultamiento de Formulario: autoAlpha: 0, traslación en X (20px), escala a 0.96 en 0.28s
   * - Restitución de Bienvenida: display: flex, autoAlpha: 1, traslación en X a 0px en 0.35s
   */
  exitLoginForm(event?: Event) {
    if (event) {
      event.stopPropagation();
    }

    const welcome = document.getElementById('login-welcome-box');
    const formCard = document.getElementById('login-form-card');

    if (!welcome || !formCard) {
      this.isLoginFormActive.set(false);
      return;
    }

    this.isLoginFormActive.set(false);

    // Ocultamiento del formulario
    gsap.to(formCard, {
      autoAlpha: 0,
      x: 20,
      scale: 0.96,
      duration: 0.28,
      ease: 'power2.in',
      onComplete: () => {
        gsap.set(formCard, { display: 'none' });
      }
    });

    // Restitución de bienvenida
    gsap.fromTo(welcome,
      { autoAlpha: 0, x: -20, display: 'flex' },
      {
        autoAlpha: 1,
        x: 0,
        duration: 0.35,
        ease: 'power2.out'
      }
    );
  }

  // Gamificación Duolingo: Completar reto diario
  toggleDailyQuest() {
    const nextState = !this.dailyQuestCompleted();
    this.dailyQuestCompleted.set(nextState);
    if (nextState) {
      this.streakDays.update(s => s + 1);
      this.showQuickToast('Misión completada: +50 XP y racha protegida');
    } else {
      this.streakDays.update(s => s - 1);
    }
  }

  // Acción para copiar código exportable
  async copyExportCode() {
    const code = this.themeService.generateExportableCode();
    let textToCopy = '';

    if (this.activeExportTab() === 'css') {
      textToCopy = code.cssVariables;
    } else if (this.activeExportTab() === 'html') {
      textToCopy = code.htmlTemplate;
    } else {
      textToCopy = code.mountingGuide;
    }

    try {
      await navigator.clipboard.writeText(textToCopy);
      this.showQuickToast('Código copiado al portapapeles');
    } catch {
      this.showQuickToast('No se pudo copiar automáticamente. Puedes seleccionarlo manualmente.');
    }
  }

  // Aplicar tema en toda la app de Ionic
  applyThemeGlobally() {
    const cssVars = this.themeService.getThemeCssVariables();
    const root = document.documentElement;

    for (const [key, val] of Object.entries(cssVars)) {
      root.style.setProperty(key, val);
    }

    if (this.themeService.isDarkMode()) {
      document.body.classList.add('dark');
      document.body.classList.remove('light');
    } else {
      document.body.classList.remove('dark');
      document.body.classList.add('light');
    }

    this.showQuickToast('Tema y tokens aplicados globalmente al proyecto');
  }

  goToRealApp() {
    this.router.navigate(['/login']);
  }

  showQuickToast(msg: string) {
    this.toastMessage.set(msg);
    this.showToast.set(true);
  }

  toggleAttendance(index: number) {
    this.docenteData.alumnosAsistencia[index].presente = !this.docenteData.alumnosAsistencia[index].presente;
  }
}
