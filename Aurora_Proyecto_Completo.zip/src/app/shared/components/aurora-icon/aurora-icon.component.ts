import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'aurora-icon',
  standalone: true,
  imports: [CommonModule],
  template: `
    <svg
      [attr.width]="size"
      [attr.height]="size"
      [attr.viewBox]="'0 0 24 24'"
      class="aurora-svg-icon"
      [ngClass]="customClass"
      aria-hidden="true"
    >
      <use [attr.href]="'assets/brand/icons/aurora-icons.svg#' + name"></use>
    </svg>
  `,
  styles: [`
    :host {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      line-height: 0;
      vertical-align: middle;
    }
    .aurora-svg-icon {
      display: inline-block;
      vertical-align: middle;
      transition: transform 0.2s ease, filter 0.2s ease;
    }
  `]
})
export class AuroraIconComponent {
  @Input() name = 'aurora-star';
  @Input() size: number | string = 24;
  @Input() customClass = '';
}
