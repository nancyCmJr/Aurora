import { Component } from '@angular/core';
import { IonApp, IonRouterOutlet } from '@ionic/angular';
import { AuroraStarCursorComponent } from './components/aurora-star-cursor/aurora-star-cursor.component';
import { addIcons } from 'ionicons';
import {
  addOutline,
  arrowBackOutline,
  chevronBackOutline,
  schoolOutline,
  shieldCheckmarkOutline,
  shieldOutline,
  peopleOutline,
  personOutline,
  bookOutline,
  ribbonOutline,
  layersOutline,
  calendarOutline,
  businessOutline,
  documentTextOutline,
  gitNetworkOutline,
  createOutline,
  saveOutline,
  trashOutline,
  closeOutline,
  refreshOutline,
  searchOutline,
  filterOutline,
} from 'ionicons/icons';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  imports: [IonApp, IonRouterOutlet, AuroraStarCursorComponent],
})
export class AppComponent {
  constructor() {
    addIcons({
      addOutline,
      arrowBackOutline,
      chevronBackOutline,
      schoolOutline,
      shieldCheckmarkOutline,
      shieldOutline,
      peopleOutline,
      personOutline,
      bookOutline,
      ribbonOutline,
      layersOutline,
      calendarOutline,
      businessOutline,
      documentTextOutline,
      gitNetworkOutline,
      createOutline,
      saveOutline,
      trashOutline,
      closeOutline,
      refreshOutline,
      searchOutline,
      filterOutline,
    });
  }
}
