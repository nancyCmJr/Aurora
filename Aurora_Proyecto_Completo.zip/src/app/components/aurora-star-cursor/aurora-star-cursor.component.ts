import { Component, ElementRef, HostListener, NgZone, OnDestroy, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

interface StardustParticle {
  id: number;
  x: number;
  y: number;
  size: number;
  alpha: number;
  rotation: number;
  vx: number;
  vy: number;
}

@Component({
  selector: 'aurora-star-cursor',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="cursor-root" [class.is-hovering]="isHovering" [class.is-pressed]="isPressed" [class.is-hidden]="isHidden">
      <!-- Resplandor áurico detrás de la estrella -->
      <div
        class="star-glow-aura"
        [style.transform]="'translate3d(' + currentX + 'px, ' + currentY + 'px, 0)'"
      ></div>

      <!-- Estrella principal de cuatro puntas (Identidad oficial Aurora) -->
      <div
        class="star-pointer"
        [style.transform]="'translate3d(' + currentX + 'px, ' + currentY + 'px, 0) scale(' + currentScale + ') rotate(' + currentRotation + 'deg)'"
      >
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" class="aurora-star-svg">
          <defs>
            <linearGradient id="cursorStarGold" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#FEF08A"/>
              <stop offset="45%" stop-color="#F59E0B"/>
              <stop offset="100%" stop-color="#B45309"/>
            </linearGradient>
            <filter id="cursorStarGlow" x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="1" result="glow"/>
              <feComposite in="SourceGraphic" in2="glow" operator="over"/>
            </filter>
          </defs>
          <!-- Estrella de 4 puntas geométrica idéntica al logo Aurora -->
          <path d="M12 2 Q12 12 2 12 Q12 12 12 22 Q12 12 22 12 Q12 12 12 2 Z" fill="url(#cursorStarGold)" filter="url(#cursorStarGlow)"/>
          <!-- Estrellita satélite acompañante -->
          <path d="M19 4 Q19 7 16 7 Q19 7 19 10 Q19 7 22 7 Q19 7 19 4 Z" fill="#FDE68A" opacity="0.9"/>
          <!-- Núcleo brillante de starlight -->
          <circle cx="12" cy="12" r="2" fill="#FFFFFF"/>
        </svg>
      </div>

      <!-- Partículas de polvo estelar flotantes (Stardust trail) -->
      <div
        *ngFor="let p of particles; trackBy: trackById"
        class="stardust-particle"
        [style.transform]="'translate3d(' + p.x + 'px, ' + p.y + 'px, 0) rotate(' + p.rotation + 'deg)'"
        [style.width.px]="p.size"
        [style.height.px]="p.size"
        [style.opacity]="p.alpha"
      >
        <svg viewBox="0 0 12 12" width="100%" height="100%">
          <path d="M6 1 Q6 6 1 6 Q6 6 6 11 Q6 6 11 6 Q6 6 6 1 Z" fill="#FDE68A"/>
        </svg>
      </div>
    </div>
  `,
  styles: [`
    :host {
      display: block;
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 999999;
      overflow: hidden;
    }

    .cursor-root {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      pointer-events: none;
      transition: opacity 0.2s ease;

      &.is-hidden {
        opacity: 0;
      }
    }

    /* Ocultar en dispositivos táctiles */
    @media (hover: none) and (pointer: coarse) {
      :host {
        display: none !important;
      }
    }

    /* Aura de resplandor áurico / boreal detrás del cursor */
    .star-glow-aura {
      position: absolute;
      top: -24px;
      left: -24px;
      width: 48px;
      height: 48px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(245, 158, 11, 0.45) 0%, rgba(124, 58, 237, 0.2) 50%, transparent 70%);
      pointer-events: none;
      will-change: transform;
      transition: width 0.2s ease, height 0.2s ease, top 0.2s ease, left 0.2s ease;
    }

    /* Elemento de la estrella con animación suave */
    .star-pointer {
      position: absolute;
      top: -14px;
      left: -14px;
      width: 28px;
      height: 28px;
      pointer-events: none;
      will-change: transform;
      filter: drop-shadow(0 2px 8px rgba(0, 0, 0, 0.45));
    }

    .aurora-star-svg {
      width: 100%;
      height: 100%;
      display: block;
    }

    /* Estados de interacción táctil Emil Kowalski */
    .is-hovering {
      .star-glow-aura {
        width: 64px;
        height: 64px;
        top: -32px;
        left: -32px;
        background: radial-gradient(circle, rgba(254, 240, 138, 0.6) 0%, rgba(245, 158, 11, 0.4) 40%, rgba(124, 58, 237, 0.25) 70%, transparent 80%);
      }
    }

    .is-pressed {
      .star-pointer {
        filter: drop-shadow(0 0 12px #f59e0b);
      }
    }

    /* Partículas de Polvo Estelar */
    .stardust-particle {
      position: absolute;
      pointer-events: none;
      will-change: transform, opacity;
      filter: drop-shadow(0 0 4px #f59e0b);
    }
  `]
})
export class AuroraStarCursorComponent implements OnInit, OnDestroy {
  private readonly ngZone = inject(NgZone);

  targetX = -100;
  targetY = -100;
  currentX = -100;
  currentY = -100;
  currentScale = 1;
  currentRotation = 0;

  isHovering = false;
  isPressed = false;
  isHidden = true;

  particles: StardustParticle[] = [];
  private particleIdCounter = 0;
  private animFrameId: number | null = null;
  private lastSpawnTime = 0;
  private lastDistX = 0;
  private lastDistY = 0;

  ngOnInit(): void {
    if (typeof window === 'undefined') return;

    // Ejecutar loop de animación fuera de Angular Zone para 60fps sin sobrecarga de ChangeDetection
    this.ngZone.runOutsideAngular(() => {
      window.addEventListener('pointermove', this.onPointerMove, { passive: true });
      window.addEventListener('pointerdown', this.onPointerDown, { passive: true });
      window.addEventListener('pointerup', this.onPointerUp, { passive: true });
      window.addEventListener('pointerleave', this.onPointerLeave, { passive: true });
      window.addEventListener('pointerenter', this.onPointerEnter, { passive: true });

      this.renderLoop();
    });
  }

  ngOnDestroy(): void {
    if (typeof window === 'undefined') return;
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
    window.removeEventListener('pointermove', this.onPointerMove);
    window.removeEventListener('pointerdown', this.onPointerDown);
    window.removeEventListener('pointerup', this.onPointerUp);
    window.removeEventListener('pointerleave', this.onPointerLeave);
    window.removeEventListener('pointerenter', this.onPointerEnter);
  }

  private onPointerMove = (e: PointerEvent): void => {
    this.targetX = e.clientX;
    this.targetY = e.clientY;
    this.isHidden = false;

    // Detectar si el elemento bajo el cursor es interactivo
    const target = e.target as HTMLElement | null;
    if (target) {
      const isInteractive = !!target.closest(
        'button, a, input, select, textarea, [role="button"], ion-button, ion-item, .clickable, .module-bento-card, .dimension-white-pill-cta, .dimension-theme-toggle-pill, .dimension-ghost-btn'
      );
      if (this.isHovering !== isInteractive) {
        this.isHovering = isInteractive;
      }
    }

    // Calcular velocidad para emitir partículas de polvo estelar
    const dx = this.targetX - this.currentX;
    const dy = this.targetY - this.currentY;
    const speed = Math.sqrt(dx * dx + dy * dy);
    const now = performance.now();

    if (speed > 8 && now - this.lastSpawnTime > 45 && this.particles.length < 18) {
      this.lastSpawnTime = now;
      this.spawnParticle(this.targetX, this.targetY);
    }
  };

  private onPointerDown = (): void => {
    this.isPressed = true;
    // Ráfaga estelar al hacer clic
    for (let i = 0; i < 4; i++) {
      this.spawnParticle(this.targetX, this.targetY, true);
    }
  };

  private onPointerUp = (): void => {
    this.isPressed = false;
  };

  private onPointerLeave = (): void => {
    this.isHidden = true;
  };

  private onPointerEnter = (): void => {
    this.isHidden = false;
  };

  private spawnParticle(x: number, y: number, burst = false): void {
    const angle = burst ? Math.random() * Math.PI * 2 : Math.random() * Math.PI * 2;
    const speed = burst ? Math.random() * 2.5 + 1.2 : Math.random() * 1.2 + 0.3;

    this.particles.push({
      id: ++this.particleIdCounter,
      x: x + (Math.random() - 0.5) * 8,
      y: y + (Math.random() - 0.5) * 8,
      size: burst ? Math.random() * 8 + 6 : Math.random() * 6 + 4,
      alpha: 1,
      rotation: Math.random() * 360,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed,
    });
  }

  private renderLoop = (): void => {
    // Física de resorte (Spring lerp) según Emil Kowalski: suave y reactiva
    const lerpFactor = 0.28;
    this.currentX += (this.targetX - this.currentX) * lerpFactor;
    this.currentY += (this.targetY - this.currentY) * lerpFactor;

    // Escala y rotación dependiente de estado
    const targetScale = this.isPressed ? 0.82 : this.isHovering ? 1.28 : 1;
    this.currentScale += (targetScale - this.currentScale) * 0.22;

    const targetRot = this.isHovering ? 45 : 0;
    this.currentRotation += (targetRot - this.currentRotation) * 0.18;

    // Actualizar partículas
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i];
      p.x += p.vx;
      p.y += p.vy;
      p.alpha -= 0.045; // Desvanecimiento gradual
      p.rotation += 3;
      p.size = Math.max(0, p.size - 0.12);

      if (p.alpha <= 0 || p.size <= 0) {
        this.particles.splice(i, 1);
      }
    }

    this.animFrameId = requestAnimationFrame(this.renderLoop);
  };

  trackById(index: number, item: StardustParticle): number {
    return item.id;
  }
}
