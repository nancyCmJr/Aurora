export const environment = {
  production: true,
  apiUrl: 'http://localhost/api_aurora'
};
